package com.thanosmod.config;

/**
 * ═══════════════════════════════════════════════════════════
 *  ThanosConfig — All mod settings in one serialisable POJO.
 *
 *  Each field maps directly to a Cloth Config entry (or a
 *  plain JSON key if Cloth Config is absent).  Defaults are
 *  tuned for a "Balanced" experience on mid-range hardware.
 * ═══════════════════════════════════════════════════════════
 */
public class ThanosConfig {

    // ── Reality Stone ─────────────────────────────────────────────────────
    /** Render distance in chunks (overrides vanilla slider). */
    public int     renderDistance        = 10;
    /** Simulation / server-side tick distance. */
    public int     simulationDistance    = 8;
    /** Run lighting updates off the main thread when possible. */
    public boolean asyncLighting         = true;
    /** Use enhanced vanilla chunk scheduler (pre-loads neighbors). */
    public boolean enhancedChunkLoading  = true;

    // ── Power Stone ───────────────────────────────────────────────────────
    /** Radius (blocks) within which mobs receive full AI ticks. */
    public int     entityTickDistance    = 32;
    /** Hard cap on entities per dimension. -1 = unlimited. */
    public int     entityCap             = 200;
    /** Skip pathfinding entirely for mobs beyond entityTickDistance. */
    public boolean skipDistantAI         = true;

    // ── Space Stone ───────────────────────────────────────────────────────
    /** Defer block-entity (tile entity) initialisation until accessed. */
    public boolean lazyTileEntities      = true;
    /** Run certain block updates asynchronously. */
    public boolean asyncBlockUpdates     = false;  // experimental — off by default
    /** Seconds between forced GC + cache eviction cycles. 0 = disabled. */
    public int     memoryCleanupInterval = 60;

    // ── Time Stone ────────────────────────────────────────────────────────
    /** Skip redstone evaluations beyond this radius (blocks). */
    public boolean skipDistantRedstone   = true;
    public int     redstoneCutoffDist    = 48;
    /** Batch scheduled ticks into larger groups when behind. */
    public boolean scheduledTaskBatching = true;
    /** Throttle particle spawning when FPS is below target. */
    public boolean particleThrottle      = true;
    /** 0–100 %. Applied on top of any shader-based reduction. */
    public int     particleDensity       = 80;

    // ── Mind Stone ────────────────────────────────────────────────────────
    /** Let the mod auto-adjust settings based on live FPS. */
    public boolean autoTuneEnabled       = true;
    /**
     * Active performance profile.
     * Values: "low_end" | "balanced" | "ultra" | "custom"
     */
    public String  performanceMode       = "balanced";
    /** FPS the auto-tuner aims to maintain. */
    public int     targetFPS             = 60;
    /** How aggressively to cut settings when FPS drops (1–10). */
    public int     autoTuneAggressiveness = 5;

    // ── Soul Stone ────────────────────────────────────────────────────────
    /** Render a lightweight FPS counter HUD. */
    public boolean showHUD               = true;
    /**
     * HUD corner: "TOP_LEFT" | "TOP_RIGHT" | "BOTTOM_LEFT" | "BOTTOM_RIGHT"
     */
    public String  hudPosition           = "TOP_LEFT";
    /** Flash a red warning when FPS drops below threshold. */
    public boolean fpsWarning            = true;
    public int     fpsWarningThreshold   = 30;

    // ── Chaos Stone ───────────────────────────────────────────────────────
    /** Show extended debug overlay (FPS + entity count + mode). */
    public boolean debugMode             = false;
    /** Hide all particles — "dream mode" visual style. */
    public boolean dreamMode             = false;
    /** Log verbose stone activity to the game log. */
    public boolean verboseLogging        = false;
}
