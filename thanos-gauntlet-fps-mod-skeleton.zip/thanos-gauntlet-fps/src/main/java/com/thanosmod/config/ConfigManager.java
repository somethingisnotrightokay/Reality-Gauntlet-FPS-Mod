package com.thanosmod.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.thanosmod.ThanosGauntletFPS;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

/**
 * ═══════════════════════════════════════════════════════════
 *  ConfigManager — Reads & writes ThanosConfig to/from JSON.
 *
 *  File location: <config dir>/thanos-gauntlet-fps.json
 *  Gson is already on the classpath via Minecraft itself.
 * ═══════════════════════════════════════════════════════════
 */
public class ConfigManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final Path configPath;
    private ThanosConfig config = new ThanosConfig();   // initialise with defaults

    public ConfigManager() {
        // FabricLoader.getInstance() is safe to call this early
        this.configPath = FabricLoader.getInstance()
                .getConfigDir()
                .resolve("thanos-gauntlet-fps.json");
    }

    // ── Public API ────────────────────────────────────────────────────────

    /** Load config from disk; falls back to defaults on any error. */
    public void load() {
        File file = configPath.toFile();
        if (!file.exists()) {
            ThanosGauntletFPS.LOGGER.info("[Thanos] No config found — writing defaults.");
            save();   // persist the fresh defaults immediately
            return;
        }
        try (Reader reader = new InputStreamReader(
                new FileInputStream(file), StandardCharsets.UTF_8)) {

            ThanosConfig loaded = GSON.fromJson(reader, ThanosConfig.class);
            if (loaded != null) {
                config = loaded;
                ThanosGauntletFPS.LOGGER.info("[Thanos] Config loaded from disk.");
            }
        } catch (IOException e) {
            ThanosGauntletFPS.LOGGER.error("[Thanos] Failed to read config: {}", e.getMessage());
        }
    }

    /** Persist current config to disk. Safe to call from any thread. */
    public void save() {
        try {
            File file = configPath.toFile();
            //noinspection ResultOfMethodCallIgnored
            file.getParentFile().mkdirs();
            try (Writer writer = new OutputStreamWriter(
                    new FileOutputStream(file), StandardCharsets.UTF_8)) {
                GSON.toJson(config, writer);
            }
            ThanosGauntletFPS.LOGGER.debug("[Thanos] Config saved.");
        } catch (IOException e) {
            ThanosGauntletFPS.LOGGER.error("[Thanos] Failed to save config: {}", e.getMessage());
        }
    }

    /**
     * Apply a preset profile, then save.
     *
     * @param mode "low_end" | "balanced" | "ultra"
     */
    public void applyPreset(String mode) {
        switch (mode.toLowerCase()) {

            case "low_end" -> {
                config.performanceMode       = "low_end";
                config.renderDistance        = 6;
                config.simulationDistance    = 5;
                config.entityTickDistance    = 16;
                config.entityCap             = 100;
                config.skipDistantAI         = true;
                config.redstoneCutoffDist    = 24;
                config.skipDistantRedstone   = true;
                config.particleDensity       = 30;
                config.particleThrottle      = true;
                config.asyncLighting         = true;
                config.lazyTileEntities      = true;
                config.dreamMode             = false;
                config.targetFPS             = 60;
            }

            case "balanced" -> {
                config.performanceMode       = "balanced";
                config.renderDistance        = 10;
                config.simulationDistance    = 8;
                config.entityTickDistance    = 32;
                config.entityCap             = 200;
                config.skipDistantAI         = true;
                config.redstoneCutoffDist    = 48;
                config.skipDistantRedstone   = true;
                config.particleDensity       = 70;
                config.particleThrottle      = true;
                config.asyncLighting         = true;
                config.lazyTileEntities      = true;
                config.dreamMode             = false;
                config.targetFPS             = 60;
            }

            case "ultra" -> {
                config.performanceMode       = "ultra";
                config.renderDistance        = 16;
                config.simulationDistance    = 12;
                config.entityTickDistance    = 64;
                config.entityCap             = 500;
                config.skipDistantAI         = false;
                config.redstoneCutoffDist    = 128;
                config.skipDistantRedstone   = false;
                config.particleDensity       = 100;
                config.particleThrottle      = false;
                config.asyncLighting         = true;
                config.lazyTileEntities      = false;
                config.dreamMode             = false;
                config.targetFPS             = 144;
            }

            default -> ThanosGauntletFPS.LOGGER.warn("[Thanos] Unknown preset: {}", mode);
        }
        save();
    }

    public ThanosConfig getConfig() { return config; }
}
