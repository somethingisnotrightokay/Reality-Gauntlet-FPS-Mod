package com.thanosmod;

import com.thanosmod.autotune.AutoTuner;
import com.thanosmod.autotune.SystemDetector;
import com.thanosmod.config.ConfigManager;
import com.thanosmod.modules.ChaosStone;
import com.thanosmod.modules.MindStone;
import com.thanosmod.modules.RealityStone;
import com.thanosmod.modules.SoulStone;
import com.thanosmod.shader.ShaderDetector;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * ═══════════════════════════════════════════════════════════
 *  Thanos Gauntlet FPS — Client Entrypoint
 *  All client-side boot logic: rendering stones, HUD,
 *  auto-tune, shader detection, keybind registration.
 * ═══════════════════════════════════════════════════════════
 */
@Environment(EnvType.CLIENT)
public class ThanosGauntletFPSClient implements ClientModInitializer {

    private static ThanosGauntletFPSClient instance;

    // ── Client-only stone modules ──────────────────────────────────────────
    private RealityStone  realityStone;
    private MindStone     mindStone;
    private SoulStone     soulStone;
    private ChaosStone    chaosStone;
    private AutoTuner     autoTuner;
    private ShaderDetector shaderDetector;

    /** Keybind: cycle through performance modes (default: K) */
    public static KeyBinding cycleModeKey;

    /** Tracks client tick count for scheduled tasks */
    private int tickCounter = 0;
    /** Re-evaluate auto-tune every N ticks (100 ticks ≈ 5 seconds at 20 TPS) */
    private static final int AUTO_TUNE_INTERVAL_TICKS = 100;

    @Override
    public void onInitializeClient() {
        instance = this;
        ConfigManager cfg = ThanosGauntletFPS.getConfigManager();

        // ── Detect hardware & shaders ──────────────────────────────────────
        shaderDetector = new ShaderDetector();
        SystemDetector.detect();                 // CPU / RAM / GPU

        // ── Boot client stones ─────────────────────────────────────────────
        realityStone = new RealityStone();
        realityStone.init(cfg.getConfig());

        mindStone  = new MindStone(shaderDetector);
        soulStone  = new SoulStone();
        soulStone.init(cfg.getConfig());

        chaosStone = new ChaosStone();
        chaosStone.init(cfg.getConfig());

        autoTuner  = new AutoTuner(mindStone, shaderDetector);

        // ── Register keybind: Cycle Mode ──────────────────────────────────
        cycleModeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "thanos.config.hotkeySwitchMode",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_K,
            "Thanos Gauntlet FPS"
        ));

        // ── World-load hook: run benchmark + auto-tune ─────────────────────
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            ThanosGauntletFPS.LOGGER.info("[Thanos] Client started. System: {}", SystemDetector.getSummary());
        });

        // ── Per-tick client hook ───────────────────────────────────────────
        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);

        ThanosGauntletFPS.LOGGER.info("[Thanos] Client modules online. Stones assembled. 🤙");
    }

    /**
     * Called every client tick.
     * Handles: keybind input, periodic auto-tune, HUD updates.
     */
    private void onClientTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;

        // ── Check hotkey press ────────────────────────────────────────────
        while (cycleModeKey.wasPressed()) {
            String newMode = mindStone.cycleMode();
            client.player.sendMessage(
                Text.translatable("thanos.notify.mode_switched", newMode), true
            );
        }

        // ── Periodic auto-tune ────────────────────────────────────────────
        if (++tickCounter >= AUTO_TUNE_INTERVAL_TICKS) {
            tickCounter = 0;
            if (ThanosGauntletFPS.getConfigManager().getConfig().autoTuneEnabled) {
                autoTuner.evaluate(client);
            }
        }

        // ── Soul Stone HUD / warning tick ─────────────────────────────────
        soulStone.tick(client);

        // ── Chaos Stone debug overlay tick ────────────────────────────────
        chaosStone.tick(client);
    }

    // ── Static accessors ──────────────────────────────────────────────────

    public static ThanosGauntletFPSClient getInstance()   { return instance;       }
    public static RealityStone  getRealityStone()  { return instance.realityStone;  }
    public static MindStone     getMindStone()     { return instance.mindStone;     }
    public static SoulStone     getSoulStone()     { return instance.soulStone;     }
    public static ChaosStone    getChaosStone()    { return instance.chaosStone;    }
    public static AutoTuner     getAutoTuner()     { return instance.autoTuner;     }
    public static ShaderDetector getShaderDetector(){ return instance.shaderDetector; }
}
