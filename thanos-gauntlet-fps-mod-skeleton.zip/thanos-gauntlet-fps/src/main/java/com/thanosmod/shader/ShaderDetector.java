package com.thanosmod.shader;

import com.thanosmod.ThanosGauntletFPS;
import net.fabricmc.loader.api.FabricLoader;

/**
 * ═══════════════════════════════════════════════════════════
 *  ShaderDetector — Sodium & Iris Integration
 *
 *  Detection strategy:
 *  1. Use FabricLoader to check if "sodium" / "iris" mods are
 *     loaded in the mod list (no hard compile-time dependency).
 *  2. For Iris: also check the IrisApi class via reflection to
 *     determine whether a shader pack is actually ACTIVE right now.
 *
 *  This mod never embeds Sodium or Iris; it only DETECTS them.
 * ═══════════════════════════════════════════════════════════
 */
public class ShaderDetector {

    private final boolean sodiumPresent;
    private final boolean irisPresent;

    public ShaderDetector() {
        FabricLoader loader = FabricLoader.getInstance();
        sodiumPresent = loader.isModLoaded("sodium");
        irisPresent   = loader.isModLoaded("iris");

        ThanosGauntletFPS.LOGGER.info(
            "[Thanos:ShaderDetector] Sodium={} | Iris={}",
            sodiumPresent, irisPresent
        );
    }

    // ── Public query methods ──────────────────────────────────────────────

    /** True if Sodium is present in the mod list. */
    public boolean isSodiumPresent() { return sodiumPresent; }

    /** True if Iris is present in the mod list. */
    public boolean isIrisPresent()   { return irisPresent;   }

    /**
     * True if Iris is present AND a shader pack is currently active.
     * Uses reflection so we have no hard dependency on Iris at compile time.
     */
    public boolean isShadersEnabled() {
        if (!irisPresent) return false;
        try {
            // net.irisshaders.iris.api.v0.IrisApi.getInstance().isShaderPackInUse()
            Class<?> apiClass = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            Object   instance = apiClass.getMethod("getInstance").invoke(null);
            return (boolean) apiClass.getMethod("isShaderPackInUse").invoke(instance);
        } catch (Exception e) {
            // Iris present but API call failed — assume shaders active to be safe
            ThanosGauntletFPS.LOGGER.debug(
                "[Thanos:ShaderDetector] Iris shader check failed ({}), assuming active.",
                e.getClass().getSimpleName()
            );
            return true;
        }
    }

    /**
     * Return a human-readable summary of the detected render stack,
     * used by the HUD and auto-tuner logging.
     */
    public String getRenderStackSummary() {
        if (irisPresent && isShadersEnabled())
            return "Sodium + Iris (Shaders ACTIVE)";
        if (irisPresent)
            return "Sodium + Iris (no shader pack)";
        if (sodiumPresent)
            return "Sodium (no Iris)";
        return "Vanilla renderer";
    }
}
