package com.thanosmod.autotune;

import com.thanosmod.ThanosGauntletFPS;
import org.lwjgl.opengl.GL11;

import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;

/**
 * ═══════════════════════════════════════════════════════════
 *  SystemDetector — Hardware Fingerprinting
 *
 *  Gathers:
 *    • CPU core count  (ManagementFactory)
 *    • Total JVM heap  (Runtime)
 *    • OS-level physical RAM (OperatingSystemMXBean cast)
 *    • GPU renderer string (GL11 via LWJGL — client-only call)
 *
 *  Results are stored statically so any stone can query them
 *  without re-running expensive native calls.
 * ═══════════════════════════════════════════════════════════
 */
public final class SystemDetector {

    // ── Detected values (populated by detect()) ───────────────────────────
    private static int    cpuCores       = 4;
    private static long   totalRamMB     = 4096;
    private static long   jvmMaxHeapMB   = 2048;
    private static String gpuRenderer    = "Unknown GPU";
    private static String gpuVendor      = "Unknown";
    private static Tier   detectedTier   = Tier.MID;

    /** Hardware performance tier, used by AutoTuner. */
    public enum Tier { LOW, MID, HIGH }

    private SystemDetector() {}

    // ── Public entry-point ────────────────────────────────────────────────

    /**
     * Run hardware detection.  Must be called AFTER OpenGL is initialised
     * (i.e. from ClientModInitializer, not the common initializer).
     */
    public static void detect() {
        detectCPUAndRAM();
        detectGPU();
        classifyTier();

        ThanosGauntletFPS.LOGGER.info("[Thanos:SystemDetector] {}", getSummary());
    }

    // ── Internal detection helpers ────────────────────────────────────────

    private static void detectCPUAndRAM() {
        // CPU cores
        cpuCores = Runtime.getRuntime().availableProcessors();

        // JVM max heap
        jvmMaxHeapMB = Runtime.getRuntime().maxMemory() / (1024 * 1024);

        // Physical RAM via OperatingSystemMXBean (Sun extension)
        try {
            OperatingSystemMXBean osBean = ManagementFactory.getOperatingSystemMXBean();
            if (osBean instanceof com.sun.management.OperatingSystemMXBean sunBean) {
                totalRamMB = sunBean.getTotalMemorySize() / (1024 * 1024);
            } else {
                // Fallback: use JVM heap as proxy
                totalRamMB = jvmMaxHeapMB;
            }
        } catch (Exception e) {
            ThanosGauntletFPS.LOGGER.warn("[Thanos:SystemDetector] RAM detection failed: {}", e.getMessage());
            totalRamMB = jvmMaxHeapMB;
        }
    }

    private static void detectGPU() {
        try {
            // GL11.glGetString must be called on the render thread.
            // By the time ClientModInitializer runs, the GL context exists.
            String renderer = GL11.glGetString(GL11.GL_RENDERER);
            String vendor   = GL11.glGetString(GL11.GL_VENDOR);
            if (renderer != null) gpuRenderer = renderer;
            if (vendor   != null) gpuVendor   = vendor;
        } catch (Exception e) {
            ThanosGauntletFPS.LOGGER.warn("[Thanos:SystemDetector] GPU detection failed: {}", e.getMessage());
        }
    }

    /**
     * Classify hardware into LOW / MID / HIGH tiers based on CPU cores,
     * available RAM, and GPU name heuristics.
     *
     * This is intentionally simple — the AutoTuner refines the assessment
     * with live FPS data during the mini-benchmark.
     */
    private static void classifyTier() {
        int score = 0;

        // CPU score
        if (cpuCores >= 8) score += 3;
        else if (cpuCores >= 4) score += 2;
        else score += 1;

        // RAM score
        if (totalRamMB >= 16384) score += 3;
        else if (totalRamMB >= 8192) score += 2;
        else score += 1;

        // GPU score (string-match heuristic)
        String gpu = gpuRenderer.toLowerCase();
        if (gpu.contains("rtx") || gpu.contains("rx 6") || gpu.contains("rx 7")
                || gpu.contains("arc") || gpu.contains("radeon rx")) {
            score += 3;
        } else if (gpu.contains("gtx") || gpu.contains("rx 5") || gpu.contains("vega")
                || gpu.contains("1060") || gpu.contains("1070") || gpu.contains("1080")) {
            score += 2;
        } else {
            score += 1;   // integrated / unknown
        }

        if      (score >= 8) detectedTier = Tier.HIGH;
        else if (score >= 5) detectedTier = Tier.MID;
        else                 detectedTier = Tier.LOW;
    }

    // ── Accessors ─────────────────────────────────────────────────────────

    public static int    getCpuCores()     { return cpuCores;       }
    public static long   getTotalRamMB()   { return totalRamMB;     }
    public static long   getJvmHeapMB()    { return jvmMaxHeapMB;   }
    public static String getGpuRenderer()  { return gpuRenderer;    }
    public static String getGpuVendor()    { return gpuVendor;      }
    public static Tier   getDetectedTier() { return detectedTier;   }

    public static String getSummary() {
        return String.format(
            "CPU cores=%d | RAM=%d MB | JVM heap=%d MB | GPU=%s (%s) | Tier=%s",
            cpuCores, totalRamMB, jvmMaxHeapMB, gpuRenderer, gpuVendor, detectedTier
        );
    }

    /**
     * Map detected tier to a suggested performance mode string.
     * AutoTuner uses this as the starting point.
     */
    public static String suggestMode() {
        return switch (detectedTier) {
            case LOW  -> "low_end";
            case MID  -> "balanced";
            case HIGH -> "ultra";
        };
    }
}
