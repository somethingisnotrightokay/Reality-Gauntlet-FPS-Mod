package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import net.minecraft.block.RedstoneWireBlock;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * RedstoneMixin — skips redstone wire updates beyond cutoff distance.
 * Target: RedstoneWireBlock.update(World, BlockPos, BlockState, BlockPos, Block, boolean)
 */
@Mixin(RedstoneWireBlock.class)
public class RedstoneMixin {

    @Inject(
        method      = "neighborUpdate",
        at          = @At("HEAD"),
        cancellable = true,
        require     = 0
    )
    private void thanos$maybeSkipRedstoneUpdate(
            net.minecraft.block.BlockState state,
            World world,
            BlockPos pos,
            net.minecraft.block.Block sourceBlock,
            BlockPos sourcePos,
            boolean notify,
            CallbackInfo ci) {

        if (world.isClient()) return;
        if (!(world instanceof ServerWorld sw)) return;

        // getClosestPlayer(x, y, z, maxDistance, ignoreCreativePlayers)
        var nearestPlayer = sw.getClosestPlayer(
            pos.getX(), pos.getY(), pos.getZ(),
            -1.0,
            false
        );

        if (nearestPlayer == null) { ci.cancel(); return; }

        if (!ThanosGauntletFPS.getTimeStone().shouldEvaluateRedstone(
                world, pos, nearestPlayer.getX(), nearestPlayer.getZ())) {
            ci.cancel();
        }
    }
}
