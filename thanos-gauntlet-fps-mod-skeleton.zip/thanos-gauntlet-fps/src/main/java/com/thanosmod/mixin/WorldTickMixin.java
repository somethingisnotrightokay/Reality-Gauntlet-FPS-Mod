package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.modules.PowerStone;
import com.thanosmod.modules.SpaceStone;
import com.thanosmod.modules.TimeStone;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ═══════════════════════════════════════════════════════════
 *  WorldTickMixin (Time Stone + Space Stone + Power Stone)
 *
 *  Target: ServerWorld.tick(BooleanSupplier shouldKeepTicking)
 *  — the main server-world tick gate, called once per game tick.
 *
 *  We inject at the TAIL to:
 *    • Flush TimeStone's deferred block-update batch.
 *    • Prune PowerStone's entity tick-time cache.
 *
 *  SpaceStone's lazy tile entity flag is read by the Minecraft
 *  block-entity tick iterator — see notes in SpaceStone.java.
 * ═══════════════════════════════════════════════════════════
 */
@Mixin(ServerWorld.class)
public class WorldTickMixin {

    /** Prune interval: once every 200 server ticks (~10 seconds). */
    private int thanos$pruneCounter = 0;

    @Inject(
        method = "tick",
        at     = @At("TAIL")
    )
    private void thanos$onTickEnd(CallbackInfo ci) {
        ServerWorld world = (ServerWorld)(Object) this;

        // ── Time Stone: flush deferred block updates ───────────────────
        ThanosGauntletFPS.getTimeStone().flushBatch();

        // ── Power Stone: periodically evict stale AI-skip entries ──────
        if (++thanos$pruneCounter >= 200) {
            thanos$pruneCounter = 0;
            ThanosGauntletFPS.getPowerStone().pruneTickCache(world.getTime());
        }
    }
}
