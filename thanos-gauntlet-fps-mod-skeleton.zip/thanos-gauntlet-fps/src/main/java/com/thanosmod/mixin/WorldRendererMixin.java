package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.WorldRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * WorldRendererMixin — hooks the world render call for frame-time debug logging.
 * RenderTickCounter is imported explicitly to prevent compile error.
 */
@Environment(EnvType.CLIENT)
@Mixin(WorldRenderer.class)
public class WorldRendererMixin {

    private long thanos$lastRenderNs = 0;

    @Inject(method = "render", at = @At("HEAD"))
    private void thanos$onRenderBegin(
            RenderTickCounter tickCounter,
            boolean renderBlockOutline,
            Camera camera,
            GameRenderer gameRenderer,
            LightmapTextureManager lightmapTextureManager,
            Matrix4f matrix4f,
            Matrix4f matrix4f2,
            CallbackInfo ci) {

        if (!ThanosGauntletFPS.getConfigManager().getConfig().verboseLogging) return;

        long now     = System.nanoTime();
        long elapsed = now - thanos$lastRenderNs;
        if (thanos$lastRenderNs != 0 && elapsed > 50_000_000L) {
            ThanosGauntletFPS.LOGGER.debug(
                "[Reality Stone] Frame time spike: {}ms", elapsed / 1_000_000
            );
        }
        thanos$lastRenderNs = now;
    }
}
