package com.thanosmod.mixin;

import com.thanosmod.modules.RealityStone;
import net.minecraft.server.world.ServerChunkManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ═══════════════════════════════════════════════════════════
 *  ServerChunkManagerMixin (Reality Stone)
 *
 *  Target: ServerChunkManager.tick(BooleanSupplier, boolean)
 *
 *  The chunk manager orchestrates lighting recalculations.
 *  We inject at HEAD to apply enhanced chunk loading
 *  pre-queuing when RealityStone.isEnhancedChunkLoadingEnabled().
 *
 *  Full async lighting requires patching the
 *  ServerLightingProvider's thread executor — that is an
 *  advanced mixin beyond this skeleton.  The flag gate here
 *  is the correct extension point to add it.
 * ═══════════════════════════════════════════════════════════
 */
@Mixin(ServerChunkManager.class)
public class ServerChunkManagerMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void thanos$onChunkManagerTick(CallbackInfo ci) {
        // Gate for future async lighting implementation.
        // When RealityStone.isAsyncLightingEnabled() is true,
        // lighting tasks should be routed to an off-thread executor.
        // boolean asyncLight = RealityStone.isAsyncLightingEnabled();
        // boolean enhancedLoad = RealityStone.isEnhancedChunkLoadingEnabled();
        // → hook into this.lightingProvider.setMaxBatchSize() or equivalent
    }
}
