package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.modules.PowerStone;
import net.minecraft.entity.Entity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.entity.EntityLike;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * EntityTickMixin — skips AI ticks for distant mobs.
 * Target: ServerWorld.tickEntity(Entity)
 */
@Mixin(ServerWorld.class)
public class EntityTickMixin {

    @Inject(
        method      = "tickEntity",
        at          = @At("HEAD"),
        cancellable = true
    )
    private void thanos$maybeSkipEntityTick(Entity entity, CallbackInfo ci) {
        ServerWorld world = (ServerWorld)(Object) this;
        PowerStone  ps    = ThanosGauntletFPS.getPowerStone();

        // getClosestPlayer(x, y, z, maxDistance, ignoreCreativePlayers)
        var nearestPlayer = world.getClosestPlayer(
            entity.getX(), entity.getY(), entity.getZ(),
            ps.getEntityTickDistance() * 2.0,
            false
        );

        double playerX, playerZ;
        if (nearestPlayer == null) {
            // Push fictitiously far so shouldTickEntityAI returns false
            playerX = entity.getX() + ps.getEntityTickDistance() + 1;
            playerZ = entity.getZ();
        } else {
            playerX = nearestPlayer.getX();
            playerZ = nearestPlayer.getZ();
        }

        long gameTime = world.getTime();
        if (!ps.shouldTickEntityAI(entity, playerX, playerZ, gameTime)) {
            ci.cancel();
        }
    }
}
