package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPSClient;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ClientTickMixin — re-applies RealityStone render distance each tick.
 * @Environment ensures this never loads on a dedicated server.
 */
@Environment(EnvType.CLIENT)
@Mixin(MinecraftClient.class)
public class ClientTickMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void thanos$onClientTickEnd(CallbackInfo ci) {
        ThanosGauntletFPSClient.getRealityStone().apply();
    }
}
