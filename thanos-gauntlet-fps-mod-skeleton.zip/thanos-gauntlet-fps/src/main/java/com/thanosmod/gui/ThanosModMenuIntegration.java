package com.thanosmod.gui;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import com.thanosmod.gui.ThanosConfigScreen;

/**
 * Registers ThanosConfigScreen as the Mod Menu config screen.
 * Requires ModMenu to be installed — optional but recommended.
 */
public class ThanosModMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return ThanosConfigScreen::build;
    }
}
