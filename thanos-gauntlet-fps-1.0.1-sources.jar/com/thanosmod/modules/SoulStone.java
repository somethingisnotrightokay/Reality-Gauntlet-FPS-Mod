package com.thanosmod.modules;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.ThanosGauntletFPSClient;
import com.thanosmod.config.ThanosConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Soul Stone — Player Comfort Features (HUD, warnings)
 */
@Environment(EnvType.CLIENT)
public class SoulStone {

    private ThanosConfig config;
    private int     warningBlinkTick = 0;
    private boolean warningVisible   = false;

    public void init(ThanosConfig config) {
        this.config = config;
        ThanosGauntletFPS.LOGGER.info("[Soul Stone] Init — HUD={} position={} warning={}",
            config.showHUD, config.hudPosition, config.fpsWarning);

        net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback.EVENT.register(
            (drawContext, tickCounter) -> renderHUD(drawContext, class_310.method_1551())
        );
    }

    public void tick(class_310 client) {
        if (!config.fpsWarning) { warningVisible = false; return; }
        int fps = client.method_47599();
        if (fps < config.fpsWarningThreshold) {
            warningBlinkTick = (warningBlinkTick + 1) % 20;
            warningVisible   = warningBlinkTick < 10;
        } else {
            warningVisible   = false;
            warningBlinkTick = 0;
        }
    }

    public void renderHUD(class_332 context, class_310 client) {
        if (!config.showHUD) return;
        // debugEnabled was renamed to showDebugHud in 1.21.x Yarn mappings
        if (client.method_53526().method_53536()) return;

        int fps  = client.method_47599();
        String mode = ThanosGauntletFPSClient.getMindStone().getCurrentModeDisplayName();

        int fpsColour;
        if (fps >= config.targetFPS)                fpsColour = 0x55FF55;
        else if (fps >= config.fpsWarningThreshold) fpsColour = 0xFFFF55;
        else                                        fpsColour = 0xFF5555;

        int screenW = client.method_22683().method_4486();
        int screenH = client.method_22683().method_4502();

        int x, y;
        switch (config.hudPosition) {
            case "TOP_RIGHT"    -> { x = screenW - 80; y = 4; }
            case "BOTTOM_LEFT"  -> { x = 4;            y = screenH - 24; }
            case "BOTTOM_RIGHT" -> { x = screenW - 80; y = screenH - 24; }
            default             -> { x = 4;            y = 4; }
        }

        context.method_51433(client.field_1772, String.format("FPS: %d", fps), x, y, fpsColour, true);
        context.method_51433(client.field_1772, "\u00a77" + mode, x, y + 10, 0xAAAAAA, true);

        if (warningVisible) {
            int cx = screenW / 2 - 30;
            context.method_51433(client.field_1772, "\u00a7cFPS Critical!", cx, 40, 0xFF5555, true);
        }

        if (config.debugMode) {
            renderDebugLines(context, client, x, y + 20);
        }
    }

    private void renderDebugLines(class_332 context, class_310 client, int x, int y) {
        if (client.field_1687 == null) return;

        // Count entities by iterating — getEntityCount() doesn't exist on ClientWorld
        int entityCount = 0;
        for (var ignored : client.field_1687.method_18112()) entityCount++;

        long memMB = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1_048_576;

        context.method_51433(client.field_1772,
            String.format("\u00a77Entities: %d", entityCount), x, y, 0xAAAAAA, true);
        context.method_51433(client.field_1772,
            String.format("\u00a77Mem: %d MB", memMB), x, y + 10, 0xAAAAAA, true);
    }

    public void reloadConfig(ThanosConfig newConfig) {
        this.config = newConfig;
    }
}
