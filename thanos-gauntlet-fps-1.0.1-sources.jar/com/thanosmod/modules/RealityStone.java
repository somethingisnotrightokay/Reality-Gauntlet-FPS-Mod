package com.thanosmod.modules;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.config.ThanosConfig;
import net.minecraft.class_310;

/**
 * ═══════════════════════════════════════════════════════════
 *  ⬡ Reality Stone — Chunk & Render Optimisation
 *
 *  Responsibilities:
 *  • Apply render distance from config to Minecraft options.
 *  • Apply simulation distance from config.
 *  • Toggle enhanced chunk loading (pre-queues neighbour chunks).
 *  • Async lighting is handled in the ServerChunkManagerMixin;
 *    this module just gates the flag.
 *
 *  The actual per-frame chunk render loop is intercepted in
 *  WorldRendererMixin.  This class is the coordinator.
 * ═══════════════════════════════════════════════════════════
 */
public class RealityStone {

    private ThanosConfig config;
    private boolean initialised = false;

    // ── Lifecycle ─────────────────────────────────────────────────────────

    public void init(ThanosConfig config) {
        this.config = config;
        ThanosGauntletFPS.LOGGER.info("[Reality Stone] Init — renderDist={} simDist={} asyncLight={}",
            config.renderDistance, config.simulationDistance, config.asyncLighting);
    }

    /**
     * Apply settings to the live Minecraft client.
     * Safe to call after the client is fully booted.
     */
    public void apply() {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1690 == null) return;

        // Push render distance into the game option
        client.field_1690.method_42503().method_41748(config.renderDistance);
        // Push simulation distance
        client.field_1690.method_42510().method_41748(config.simulationDistance);

        if (!initialised) {
            ThanosGauntletFPS.LOGGER.info(
                "[Reality Stone] Applied: render={} sim={} asyncLight={} enhancedChunks={}",
                config.renderDistance, config.simulationDistance,
                config.asyncLighting, config.enhancedChunkLoading
            );
            initialised = true;
        }
    }

    // ── Mixin helpers (called from WorldRendererMixin) ────────────────────

    /**
     * Should async lighting updates be permitted?
     * Queried by ServerChunkManagerMixin.
     */
    public static boolean isAsyncLightingEnabled() {
        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
        return cfg.asyncLighting;
    }

    /**
     * Should we pre-queue neighbour chunks when a chunk loads?
     * Queried by the chunk scheduler mixin.
     */
    public static boolean isEnhancedChunkLoadingEnabled() {
        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
        return cfg.enhancedChunkLoading;
    }

    // ── Config hot-reload ─────────────────────────────────────────────────

    public void reloadConfig(ThanosConfig newConfig) {
        this.config = newConfig;
        this.initialised = false;  // trigger fresh apply log on next apply()
        apply();
    }
}
