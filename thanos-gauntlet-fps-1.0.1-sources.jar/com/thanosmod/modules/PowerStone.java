package com.thanosmod.modules;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.config.ThanosConfig;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_3218;

/**
 * Power Stone — Entity & Mob Tick Control
 */
public class PowerStone {

    private ThanosConfig config;
    private final Map<UUID, Long> lastTickedMap = new HashMap<>();

    public void init(ThanosConfig config) {
        this.config = config;
        ThanosGauntletFPS.LOGGER.info(
            "[Power Stone] Init — entityTickDist={} entityCap={} skipAI={}",
            config.entityTickDistance, config.entityCap, config.skipDistantAI
        );
    }

    public boolean shouldTickEntityAI(class_1297 entity, double playerX, double playerZ, long gameTime) {
        if (!config.skipDistantAI) return true;
        if (!(entity instanceof class_1308)) return true;

        double dx = entity.method_23317() - playerX;
        double dz = entity.method_23321() - playerZ;
        double distSq  = dx * dx + dz * dz;
        double cutoffSq = (double) config.entityTickDistance * config.entityTickDistance;

        if (distSq <= cutoffSq) return true;

        UUID id = entity.method_5667();
        long lastTick = lastTickedMap.getOrDefault(id, 0L);
        if (gameTime - lastTick >= 4) {
            lastTickedMap.put(id, gameTime);
            return true;
        }
        return false;
    }

    public void pruneTickCache(long currentGameTime) {
        lastTickedMap.entrySet().removeIf(e -> currentGameTime - e.getValue() > 200);
    }

    /**
     * Returns true if another mob can be spawned in the given world.
     * Uses a simple iteration count — avoids the broken spliterator chain.
     */
    public boolean canSpawnMore(class_3218 world) {
        if (config.entityCap <= 0) return true;
        int count = 0;
        for (class_1297 ignored : world.method_27909()) {
            count++;
            if (count >= config.entityCap) return false;
        }
        return true;
    }

    public void reloadConfig(ThanosConfig newConfig) {
        this.config = newConfig;
        lastTickedMap.clear();
    }

    public int getEntityTickDistance() { return config.entityTickDistance; }
    public int getEntityCap()          { return config.entityCap;          }
}
