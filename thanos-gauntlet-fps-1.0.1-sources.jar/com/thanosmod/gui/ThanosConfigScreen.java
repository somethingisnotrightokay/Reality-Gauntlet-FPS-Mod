package com.thanosmod.gui;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.ThanosGauntletFPSClient;
import com.thanosmod.autotune.SystemDetector;
import com.thanosmod.config.ConfigManager;
import com.thanosmod.config.ThanosConfig;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import java.util.List;

/**
 * ThanosConfigScreen — Cloth Config 2 in-game GUI.
 * Fixed for Cloth Config 15.x API (no startStringDropdownEntry / startTextDescription).
 */
public class ThanosConfigScreen {

    public static class_437 build(class_437 parent) {
        ConfigManager mgr = ThanosGauntletFPS.getConfigManager();
        ThanosConfig  cfg = mgr.getConfig();

        ConfigBuilder builder = ConfigBuilder.create()
            .setParentScreen(parent)
            .setTitle(class_2561.method_43471("thanos.config.title"))
            .setSavingRunnable(() -> {
                mgr.save();
                ThanosGauntletFPSClient.getRealityStone().reloadConfig(cfg);
                ThanosGauntletFPSClient.getSoulStone().reloadConfig(cfg);
                ThanosGauntletFPSClient.getChaosStone().reloadConfig(cfg);
                ThanosGauntletFPS.getPowerStone().reloadConfig(cfg);
                ThanosGauntletFPS.getTimeStone().reloadConfig(cfg);
                ThanosGauntletFPS.getSpaceStone().reloadConfig(cfg);
            });

        ConfigEntryBuilder eb = builder.entryBuilder();

        // ══ REALITY STONE ════════════════════════════════════════════
        ConfigCategory reality = builder.getOrCreateCategory(
            class_2561.method_43471("thanos.config.category.reality"));

        reality.addEntry(eb.startIntSlider(
                class_2561.method_43471("thanos.config.renderDistance"), cfg.renderDistance, 2, 32)
            .setDefaultValue(10).setSaveConsumer(v -> cfg.renderDistance = v).build());

        reality.addEntry(eb.startIntSlider(
                class_2561.method_43471("thanos.config.simulationDistance"), cfg.simulationDistance, 2, 32)
            .setDefaultValue(8).setSaveConsumer(v -> cfg.simulationDistance = v).build());

        reality.addEntry(eb.startBooleanToggle(
                class_2561.method_43471("thanos.config.asyncLighting"), cfg.asyncLighting)
            .setDefaultValue(true).setSaveConsumer(v -> cfg.asyncLighting = v).build());

        // ══ POWER STONE ══════════════════════════════════════════════
        ConfigCategory power = builder.getOrCreateCategory(
            class_2561.method_43471("thanos.config.category.power"));

        power.addEntry(eb.startIntSlider(
                class_2561.method_43471("thanos.config.entityTickDistance"), cfg.entityTickDistance, 8, 128)
            .setDefaultValue(32).setSaveConsumer(v -> cfg.entityTickDistance = v).build());

        power.addEntry(eb.startIntSlider(
                class_2561.method_43471("thanos.config.entityCap"), cfg.entityCap, 10, 1000)
            .setDefaultValue(200).setSaveConsumer(v -> cfg.entityCap = v).build());

        power.addEntry(eb.startBooleanToggle(
                class_2561.method_43471("thanos.config.skipDistantRedstone"), cfg.skipDistantAI)
            .setDefaultValue(true).setSaveConsumer(v -> cfg.skipDistantAI = v).build());

        // ══ SPACE STONE ══════════════════════════════════════════════
        ConfigCategory space = builder.getOrCreateCategory(
            class_2561.method_43471("thanos.config.category.space"));

        space.addEntry(eb.startBooleanToggle(
                class_2561.method_43471("thanos.config.lazyTileEntities"), cfg.lazyTileEntities)
            .setDefaultValue(true).setSaveConsumer(v -> cfg.lazyTileEntities = v).build());

        space.addEntry(eb.startBooleanToggle(
                class_2561.method_43471("thanos.config.asyncBlockUpdates"), cfg.asyncBlockUpdates)
            .setDefaultValue(false).setSaveConsumer(v -> cfg.asyncBlockUpdates = v).build());

        space.addEntry(eb.startIntSlider(
                class_2561.method_43471("thanos.config.memoryCleanupInterval"), cfg.memoryCleanupInterval, 0, 300)
            .setDefaultValue(60).setSaveConsumer(v -> cfg.memoryCleanupInterval = v).build());

        // ══ TIME STONE ═══════════════════════════════════════════════
        ConfigCategory time = builder.getOrCreateCategory(
            class_2561.method_43471("thanos.config.category.time"));

        time.addEntry(eb.startBooleanToggle(
                class_2561.method_43471("thanos.config.skipDistantRedstone"), cfg.skipDistantRedstone)
            .setDefaultValue(true).setSaveConsumer(v -> cfg.skipDistantRedstone = v).build());

        time.addEntry(eb.startIntSlider(
                class_2561.method_43471("thanos.config.redstoneCutoffDist"), cfg.redstoneCutoffDist, 16, 128)
            .setDefaultValue(48).setSaveConsumer(v -> cfg.redstoneCutoffDist = v).build());

        time.addEntry(eb.startBooleanToggle(
                class_2561.method_43471("thanos.config.particleThrottle"), cfg.particleThrottle)
            .setDefaultValue(true).setSaveConsumer(v -> cfg.particleThrottle = v).build());

        time.addEntry(eb.startIntSlider(
                class_2561.method_43471("thanos.config.particleDensity"), cfg.particleDensity, 0, 100)
            .setDefaultValue(80).setSaveConsumer(v -> cfg.particleDensity = v).build());

        // ══ MIND STONE ═══════════════════════════════════════════════
        ConfigCategory mind = builder.getOrCreateCategory(
            class_2561.method_43471("thanos.config.category.mind"));

        mind.addEntry(eb.startBooleanToggle(
                class_2561.method_43471("thanos.config.autoTuneEnabled"), cfg.autoTuneEnabled)
            .setDefaultValue(true).setSaveConsumer(v -> cfg.autoTuneEnabled = v).build());

        // Use enum selector for performance mode (Cloth Config 15.x compatible)
        // Represented as index into a fixed list via int slider 0-3
        final List<String> modes = List.of("low_end", "balanced", "ultra", "custom");
        int currentModeIdx = Math.max(0, modes.indexOf(cfg.performanceMode));
        mind.addEntry(eb.startIntSlider(
                class_2561.method_43470("Performance Mode (0=Low 1=Balanced 2=Ultra 3=Custom)"),
                currentModeIdx, 0, 3)
            .setDefaultValue(1)
            .setSaveConsumer(v -> {
                String mode = modes.get(Math.min(v, modes.size() - 1));
                cfg.performanceMode = mode;
                if (!mode.equals("custom")) mgr.applyPreset(mode);
            }).build());

        mind.addEntry(eb.startIntSlider(
                class_2561.method_43471("thanos.config.targetFPS"), cfg.targetFPS, 15, 240)
            .setDefaultValue(60).setSaveConsumer(v -> cfg.targetFPS = v).build());

        // ══ SOUL STONE ═══════════════════════════════════════════════
        ConfigCategory soul = builder.getOrCreateCategory(
            class_2561.method_43471("thanos.config.category.soul"));

        soul.addEntry(eb.startBooleanToggle(
                class_2561.method_43471("thanos.config.showHUD"), cfg.showHUD)
            .setDefaultValue(true).setSaveConsumer(v -> cfg.showHUD = v).build());

        soul.addEntry(eb.startBooleanToggle(
                class_2561.method_43471("thanos.config.fpsWarning"), cfg.fpsWarning)
            .setDefaultValue(true).setSaveConsumer(v -> cfg.fpsWarning = v).build());

        soul.addEntry(eb.startIntSlider(
                class_2561.method_43471("thanos.config.fpsWarningThreshold"), cfg.fpsWarningThreshold, 10, 120)
            .setDefaultValue(30).setSaveConsumer(v -> cfg.fpsWarningThreshold = v).build());

        // ══ CHAOS STONE ══════════════════════════════════════════════
        ConfigCategory chaos = builder.getOrCreateCategory(
            class_2561.method_43471("thanos.config.category.chaos"));

        chaos.addEntry(eb.startBooleanToggle(
                class_2561.method_43471("thanos.config.debugMode"), cfg.debugMode)
            .setDefaultValue(false).setSaveConsumer(v -> cfg.debugMode = v).build());

        chaos.addEntry(eb.startBooleanToggle(
                class_2561.method_43471("thanos.config.dreamMode"), cfg.dreamMode)
            .setDefaultValue(false).setSaveConsumer(v -> cfg.dreamMode = v).build());

        chaos.addEntry(eb.startBooleanToggle(
                class_2561.method_43470("Verbose Logging"), cfg.verboseLogging)
            .setDefaultValue(false).setSaveConsumer(v -> cfg.verboseLogging = v).build());

        // System info as a read-only string field
        chaos.addEntry(eb.startTextField(
                class_2561.method_43470("System Info"), SystemDetector.getSummary())
            .setDefaultValue(SystemDetector.getSummary())
            .setSaveConsumer(v -> { /* read-only, ignore saves */ })
            .build());

        return builder.build();
    }
}
