package com.thanosmod.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;

/**
 * ParticleManagerMixin — server-side stub.
 * @Environment ensures it never loads on dedicated server.
 *
 * Note: This targets ServerWorld as a placeholder. Actual client
 * particle interception is in ParticleClientMixin.
 */
@Environment(EnvType.CLIENT)
@Mixin(class_3218.class)
public class ParticleManagerMixin {
    // Future: intercept sendParticles() to suppress distant particle packets.
}
