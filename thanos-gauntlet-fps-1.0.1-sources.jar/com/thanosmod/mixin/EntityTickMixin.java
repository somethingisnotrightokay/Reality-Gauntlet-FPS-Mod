package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.modules.PowerStone;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * EntityTickMixin — skips AI ticks for distant mobs.
 * Target: ServerWorld.tickEntity(Entity)
 */
@Mixin(class_3218.class)
public class EntityTickMixin {

    @Inject(
        method      = "tickEntity",
        at          = @At("HEAD"),
        cancellable = true
    )
    private void thanos$maybeSkipEntityTick(class_1297 entity, CallbackInfo ci) {
        class_3218 world = (class_3218)(Object) this;
        PowerStone  ps    = ThanosGauntletFPS.getPowerStone();

        // getClosestPlayer(x, y, z, maxDistance, ignoreCreativePlayers)
        var nearestPlayer = world.method_18459(
            entity.method_23317(), entity.method_23318(), entity.method_23321(),
            ps.getEntityTickDistance() * 2.0,
            false
        );

        double playerX, playerZ;
        if (nearestPlayer == null) {
            // Push fictitiously far so shouldTickEntityAI returns false
            playerX = entity.method_23317() + ps.getEntityTickDistance() + 1;
            playerZ = entity.method_23321();
        } else {
            playerX = nearestPlayer.method_23317();
            playerZ = nearestPlayer.method_23321();
        }

        long gameTime = world.method_8510();
        if (!ps.shouldTickEntityAI(entity, playerX, playerZ, gameTime)) {
            ci.cancel();
        }
    }
}
