package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4184;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * WorldRendererMixin — hooks the world render call for frame-time debug logging.
 * RenderTickCounter is imported explicitly to prevent compile error.
 */
@Environment(EnvType.CLIENT)
@Mixin(class_761.class)
public class WorldRendererMixin {

    private long thanos$lastRenderNs = 0;

    @Inject(method = "render", at = @At("HEAD"))
    private void thanos$onRenderBegin(
            class_9779 tickCounter,
            boolean renderBlockOutline,
            class_4184 camera,
            class_757 gameRenderer,
            class_765 lightmapTextureManager,
            Matrix4f matrix4f,
            Matrix4f matrix4f2,
            CallbackInfo ci) {

        if (!ThanosGauntletFPS.getConfigManager().getConfig().verboseLogging) return;

        long now     = System.nanoTime();
        long elapsed = now - thanos$lastRenderNs;
        if (thanos$lastRenderNs != 0 && elapsed > 50_000_000L) {
            ThanosGauntletFPS.LOGGER.debug(
                "[Reality Stone] Frame time spike: {}ms", elapsed / 1_000_000
            );
        }
        thanos$lastRenderNs = now;
    }
}
