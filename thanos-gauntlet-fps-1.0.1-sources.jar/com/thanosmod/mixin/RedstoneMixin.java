package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2457;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * RedstoneMixin — skips redstone wire updates beyond cutoff distance.
 * Target: RedstoneWireBlock.update(World, BlockPos, BlockState, BlockPos, Block, boolean)
 */
@Mixin(class_2457.class)
public class RedstoneMixin {

    @Inject(
        method      = "neighborUpdate",
        at          = @At("HEAD"),
        cancellable = true,
        require     = 0
    )
    private void thanos$maybeSkipRedstoneUpdate(
            net.minecraft.class_2680 state,
            class_1937 world,
            class_2338 pos,
            net.minecraft.class_2248 sourceBlock,
            class_2338 sourcePos,
            boolean notify,
            CallbackInfo ci) {

        if (world.method_8608()) return;
        if (!(world instanceof class_3218 sw)) return;

        // getClosestPlayer(x, y, z, maxDistance, ignoreCreativePlayers)
        var nearestPlayer = sw.method_18459(
            pos.method_10263(), pos.method_10264(), pos.method_10260(),
            -1.0,
            false
        );

        if (nearestPlayer == null) { ci.cancel(); return; }

        if (!ThanosGauntletFPS.getTimeStone().shouldEvaluateRedstone(
                world, pos, nearestPlayer.method_23317(), nearestPlayer.method_23321())) {
            ci.cancel();
        }
    }
}
