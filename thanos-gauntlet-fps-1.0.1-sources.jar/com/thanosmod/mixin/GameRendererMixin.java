package com.thanosmod.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;

/**
 * GameRendererMixin — extension point for render budget profiling.
 * @Environment prevents server crashes.
 */
@Environment(EnvType.CLIENT)
@Mixin(class_757.class)
public class GameRendererMixin {
    // Future: frame-time profiling → AutoTuner.recordFrameTime(long nanos)
}
