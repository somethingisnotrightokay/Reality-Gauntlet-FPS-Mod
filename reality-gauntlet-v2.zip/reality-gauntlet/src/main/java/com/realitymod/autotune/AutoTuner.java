package com.realitymod.autotune;

import com.realitymod.RealityGauntlet;
import com.realitymod.config.ConfigManager;
import com.realitymod.config.GauntletConfig;
import com.realitymod.modules.FluxCrystal;
import com.realitymod.shader.ShaderDetector;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * AutoTuner — Mind Stone Runtime Engine
 * Monitors FPS via rolling average and adjusts settings dynamically.
 */
public class AutoTuner {

    private static final float LOW_RATIO   = 0.80f;
    private static final float HIGH_RATIO  = 1.20f;
    private static final int   FPS_WINDOW  = 5;

    private static final int MIN_RENDER_DIST      = 4;
    private static final int MAX_RENDER_DIST      = 32;
    private static final int MIN_ENTITY_TICK_DIST = 8;
    private static final int MAX_ENTITY_TICK_DIST = 128;
    private static final int MIN_PARTICLE_DENSITY = 0;
    private static final int MAX_PARTICLE_DENSITY = 100;

    private static final int RENDER_DIST_STEP  = 1;
    private static final int ENTITY_DIST_STEP  = 8;
    private static final int PARTICLE_STEP     = 10;

    private final FluxCrystal      mindStone;
    private final ShaderDetector shaderDetector;
    private final Deque<Integer> fpsSamples = new ArrayDeque<>(FPS_WINDOW);

    private boolean initialised = false;

    public AutoTuner(FluxCrystal mindStone, ShaderDetector shaderDetector) {
        this.mindStone     = mindStone;
        this.shaderDetector = shaderDetector;
    }

    public void evaluate(MinecraftClient client) {
        int fps = client.getCurrentFps();
        recordSample(fps);

        if (fpsSamples.size() < FPS_WINDOW) return;

        float avgFPS = averageFPS();
        GauntletConfig cfg = RealityGauntlet.getConfigManager().getConfig();

        if (!initialised) {
            initialised = true;
            if (cfg.performanceMode.equals("custom")) return;
            String suggested = SystemDetector.suggestMode();
            if (!suggested.equals(cfg.performanceMode)) {
                RealityGauntlet.LOGGER.info(
                    "[Thanos:AutoTuner] Hardware suggests '{}', current mode is '{}'. Applying.",
                    suggested, cfg.performanceMode
                );
                RealityGauntlet.getConfigManager().applyPreset(suggested);
                applyShaderAdjustments(cfg);
            }
            return;
        }

        if (cfg.performanceMode.equals("custom")) return;

        float target = cfg.targetFPS;

        if (avgFPS < target * LOW_RATIO) {
            degradeOneStep(cfg, avgFPS, target);
        } else if (avgFPS > target * HIGH_RATIO) {
            restoreOneStep(cfg, avgFPS, target);
        }
    }

    private void degradeOneStep(GauntletConfig cfg, float avg, float target) {
        ConfigManager mgr = RealityGauntlet.getConfigManager();

        if (cfg.particleDensity > MIN_PARTICLE_DENSITY) {
            cfg.particleDensity = Math.max(MIN_PARTICLE_DENSITY,
                    cfg.particleDensity - PARTICLE_STEP);
            RealityGauntlet.LOGGER.debug(
                "[Thanos:AutoTuner] FPS={}/{} — reducing particles to {}%",
                (int) avg, (int) target, cfg.particleDensity
            );
        } else if (cfg.entityTickDistance > MIN_ENTITY_TICK_DIST) {
            cfg.entityTickDistance = Math.max(MIN_ENTITY_TICK_DIST,
                    cfg.entityTickDistance - ENTITY_DIST_STEP);
            RealityGauntlet.LOGGER.debug(
                "[Thanos:AutoTuner] FPS={}/{} — reducing entity AI dist to {}",
                (int) avg, (int) target, cfg.entityTickDistance
            );
        } else if (cfg.renderDistance > MIN_RENDER_DIST) {
            cfg.renderDistance = Math.max(MIN_RENDER_DIST,
                    cfg.renderDistance - RENDER_DIST_STEP);
            applyRenderDistanceToClient(cfg.renderDistance);
            RealityGauntlet.LOGGER.debug(
                "[Thanos:AutoTuner] FPS={}/{} — reducing render dist to {}",
                (int) avg, (int) target, cfg.renderDistance
            );
        }

        mgr.save();
    }

    private void restoreOneStep(GauntletConfig cfg, float avg, float target) {
        ConfigManager mgr    = RealityGauntlet.getConfigManager();
        GauntletConfig  preset = presetDefaults(cfg.performanceMode);

        if (cfg.renderDistance < preset.renderDistance && cfg.renderDistance < MAX_RENDER_DIST) {
            cfg.renderDistance++;
            applyRenderDistanceToClient(cfg.renderDistance);
        } else if (cfg.entityTickDistance < preset.entityTickDistance
                && cfg.entityTickDistance < MAX_ENTITY_TICK_DIST) {
            cfg.entityTickDistance = Math.min(preset.entityTickDistance,
                    cfg.entityTickDistance + ENTITY_DIST_STEP);
        } else if (cfg.particleDensity < preset.particleDensity
                && cfg.particleDensity < MAX_PARTICLE_DENSITY) {
            cfg.particleDensity = Math.min(preset.particleDensity,
                    cfg.particleDensity + PARTICLE_STEP);
        }

        mgr.save();
    }

    public void applyShaderAdjustments(GauntletConfig cfg) {
        if (!shaderDetector.isIrisPresent()) return;
        if (!shaderDetector.isShadersEnabled()) return;

        RealityGauntlet.LOGGER.info("[Thanos:AutoTuner] Iris shaders detected — applying shader budget.");
        cfg.renderDistance     = Math.max(MIN_RENDER_DIST, cfg.renderDistance - 2);
        cfg.particleDensity    = Math.max(20, cfg.particleDensity - 30);
        cfg.entityTickDistance = Math.max(MIN_ENTITY_TICK_DIST, cfg.entityTickDistance - 8);
        applyRenderDistanceToClient(cfg.renderDistance);
        RealityGauntlet.getConfigManager().save();
    }

    private void recordSample(int fps) {
        if (fpsSamples.size() >= FPS_WINDOW) fpsSamples.poll();
        fpsSamples.offer(fps);
    }

    private float averageFPS() {
        int sum = 0;
        for (int s : fpsSamples) sum += s;
        return (float) sum / fpsSamples.size();
    }

    private void applyRenderDistanceToClient(int dist) {
        // Update config first, then let ChronoCrystal.apply() handle the actual
        // setValue() call. ChronoCrystal tracks the last-applied value and only
        // calls setValue() when it changes, preventing the chunk-reload loop.
        RealityGauntlet.getConfigManager().getConfig().renderDistance = dist;
        // ClientTickMixin calls ChronoCrystal.apply() every tick, which will
        // pick up the new renderDistance on the next client tick.
    }

    private GauntletConfig presetDefaults(String mode) {
        GauntletConfig tmp = new GauntletConfig();
        switch (mode) {
            case "low_end" -> { tmp.renderDistance = 6;  tmp.entityTickDistance = 16; tmp.particleDensity = 30; }
            case "ultra"   -> { tmp.renderDistance = 16; tmp.entityTickDistance = 64; tmp.particleDensity = 100; }
            default        -> { tmp.renderDistance = 10; tmp.entityTickDistance = 32; tmp.particleDensity = 70; }
        }
        return tmp;
    }

    public float getAverageFPS() {
        return fpsSamples.isEmpty() ? 0 : averageFPS();
    }
}
