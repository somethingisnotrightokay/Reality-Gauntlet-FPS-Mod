package com.realitymod.shader;

import com.realitymod.RealityGauntlet;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Properties;

/**
 * ShaderDetector — Sodium & Iris Integration
 *
 * Detects Sodium/Iris presence via FabricLoader, queries whether a
 * shader pack is active via reflection, and retrieves the active
 * pack name via Iris API reflection + iris.properties fallback.
 */
public class ShaderDetector {

    private final boolean sodiumPresent;
    private final boolean irisPresent;

    public ShaderDetector() {
        FabricLoader loader = FabricLoader.getInstance();
        sodiumPresent = loader.isModLoaded("sodium");
        irisPresent   = loader.isModLoaded("iris");

        RealityGauntlet.LOGGER.info(
            "[Thanos:ShaderDetector] Sodium={} | Iris={}",
            sodiumPresent, irisPresent
        );
    }

    public boolean isSodiumPresent() { return sodiumPresent; }
    public boolean isIrisPresent()   { return irisPresent;   }

    public boolean isShadersEnabled() {
        if (!irisPresent) return false;
        try {
            Class<?> apiClass = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            Object   instance = apiClass.getMethod("getInstance").invoke(null);
            return (boolean) apiClass.getMethod("isShaderPackInUse").invoke(instance);
        } catch (Exception e) {
            RealityGauntlet.LOGGER.debug(
                "[Thanos:ShaderDetector] Iris shader-active check failed ({}), assuming active.",
                e.getClass().getSimpleName()
            );
            return true;
        }
    }

    /**
     * Returns the name of the currently active shader pack, or "" if none.
     * Tries Iris API reflection first, then reads iris.properties as fallback.
     */
    public String getActiveShaderPackName() {
        if (!irisPresent || !isShadersEnabled()) return "";

        String fromApi = getPackNameViaReflection();
        if (fromApi != null && !fromApi.isBlank()) return fromApi;

        return getPackNameFromIrisConfig();
    }

    private String getPackNameViaReflection() {
        try {
            Class<?> apiClass = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            Object   instance = apiClass.getMethod("getInstance").invoke(null);

            // Iris 1.7+: getCurrentPack() -> Optional<ShaderPackInfo>
            try {
                Object optional = apiClass.getMethod("getCurrentPack").invoke(instance);
                if (optional instanceof java.util.Optional<?> opt && opt.isPresent()) {
                    Object packInfo = opt.get();
                    try { return (String) packInfo.getClass().getMethod("getName").invoke(packInfo); }
                    catch (Exception ignored) {}
                    try { return (String) packInfo.getClass().getMethod("getTitle").invoke(packInfo); }
                    catch (Exception ignored) {}
                    String str = packInfo.toString();
                    if (!str.isBlank() && !str.startsWith("Optional")) return str;
                }
            } catch (NoSuchMethodException ignored) {}

            // Older Iris: getActiveShaderPackProfile()
            try {
                Object result = apiClass.getMethod("getActiveShaderPackProfile").invoke(instance);
                if (result != null) {
                    String name = result.toString();
                    if (!name.isBlank()) return name;
                }
            } catch (NoSuchMethodException ignored) {}

        } catch (Exception e) {
            RealityGauntlet.LOGGER.debug("[Thanos:ShaderDetector] Reflection pack lookup failed: {}",
                e.getClass().getSimpleName());
        }
        return null;
    }

    private String getPackNameFromIrisConfig() {
        try {
            Path irisProps = FabricLoader.getInstance().getConfigDir().resolve("iris.properties");
            if (!irisProps.toFile().exists()) return "";

            Properties props = new Properties();
            try (Reader r = new InputStreamReader(new FileInputStream(irisProps.toFile()), StandardCharsets.UTF_8)) {
                props.load(r);
            }
            // Iris 1.5+: "shaderPack"; older: "shaderpack"
            String name = props.getProperty("shaderPack", props.getProperty("shaderpack", "")).trim();
            if (!name.isBlank()) {
                RealityGauntlet.LOGGER.debug("[Thanos:ShaderDetector] Pack from iris.properties: '{}'", name);
            }
            return name;
        } catch (Exception e) {
            RealityGauntlet.LOGGER.debug("[Thanos:ShaderDetector] Could not read iris.properties: {}", e.getMessage());
            return "";
        }
    }

    public String getRenderStackSummary() {
        if (irisPresent && isShadersEnabled()) {
            String pack = getActiveShaderPackName();
            return pack.isBlank() ? "Sodium + Iris (Shaders ACTIVE)" : "Sodium + Iris [" + pack + "]";
        }
        if (irisPresent)   return "Sodium + Iris (no shader pack)";
        if (sodiumPresent) return "Sodium (no Iris)";
        return "Vanilla renderer";
    }
}
