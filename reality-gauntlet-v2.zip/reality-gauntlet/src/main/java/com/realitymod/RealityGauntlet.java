package com.realitymod;

import com.realitymod.config.ConfigManager;
import com.realitymod.modules.VoidCrystal;
import com.realitymod.modules.CoreCrystal;
import com.realitymod.modules.AetherCrystal;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Reality Gauntlet — Common Entrypoint
 * Runs on both client and server (shared logic only).
 * Client-only rendering/shader logic lives in RealityGauntletClient.
 *
 * Seven Reality Crystals:
 *   Chrono  — chunk & render optimization
 *   Void    — entity AI throttling
 *   Core    — memory management
 *   Aether  — particles & redstone
 *   Flux    — auto-tune intelligence
 *   Prisma  — player HUD & comfort
 *   Echo    — debug tools & dream mode
 */
public class RealityGauntlet implements ModInitializer {

    public static final String MOD_ID = "reality-gauntlet";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static RealityGauntlet instance;

    private final ConfigManager configManager = new ConfigManager();
    private final VoidCrystal   voidCrystal   = new VoidCrystal();
    private final CoreCrystal   coreCrystal   = new CoreCrystal();
    private final AetherCrystal aetherCrystal = new AetherCrystal();

    @Override
    public void onInitialize() {
        instance = this;
        LOGGER.info("╔══════════════════════════════════════════════╗");
        LOGGER.info("║   Reality Gauntlet v1 — Initializing         ║");
        LOGGER.info("║   Seven Crystals. One Gauntlet. Infinite FPS.║");
        LOGGER.info("║   v1: Fully audited for MC 1.21.1 Fabric.    ║");
        LOGGER.info("╚══════════════════════════════════════════════╝");

        configManager.load();
        voidCrystal.init(configManager.getConfig());
        coreCrystal.init(configManager.getConfig());
        aetherCrystal.init(configManager.getConfig());

        LOGGER.info("[Reality] Common crystals online. Awaiting client boot...");
    }

    public static RealityGauntlet getInstance()      { return instance;                   }
    public static ConfigManager   getConfigManager() { return instance.configManager;     }
    public static VoidCrystal     getVoidCrystal()   { return instance.voidCrystal;       }
    public static CoreCrystal     getCoreCrystal()   { return instance.coreCrystal;       }
    public static AetherCrystal   getAetherCrystal() { return instance.aetherCrystal;     }
}
