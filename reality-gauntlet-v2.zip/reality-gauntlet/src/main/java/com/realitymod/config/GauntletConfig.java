package com.realitymod.config;

/**
 * GauntletConfig — All mod settings in one serializable POJO.
 *
 * Feature groups mirror the mods we draw inspiration from:
 *   Reality Stone  → Render distance / chunk loading
 *   Power Stone    → Entity AI throttling / cap
 *   Space Stone    → Memory management / GC
 *   Time Stone     → Particles / redstone
 *   Mind Stone     → Auto-tune / mode
 *   Soul Stone     → HUD / warnings
 *   Chaos Stone    → Debug / extras
 *   + Entity culling  (MoreCulling)
 *   + Dynamic FPS     (Dynamic FPS mod)
 *   + Stutter fixes   (StutterFix + SmoothBoot)
 *   + Fast math       (SuperFastMath)
 *   + GPU leak fix    (GpuTape)
 *   + DH compat       (DistantHorizons)
 *   + Shader presets  (Iris)
 */
public class GauntletConfig {

    // ── Reality Stone ─────────────────────────────────────────────────────
    public int     renderDistance           = 10;
    public int     simulationDistance       = 8;
    public boolean asyncLighting            = true;
    public boolean enhancedChunkLoading     = true;

    // ── Power Stone ───────────────────────────────────────────────────────
    public int     entityTickDistance       = 32;
    public int     entityCap                = 200;
    public boolean skipDistantAI            = true;

    // ── Space Stone ───────────────────────────────────────────────────────
    public boolean lazyTileEntities         = true;
    public boolean asyncBlockUpdates        = false;
    public int     memoryCleanupInterval    = 60;

    // ── Time Stone ────────────────────────────────────────────────────────
    public boolean skipDistantRedstone      = true;
    public int     redstoneCutoffDist       = 48;
    public boolean scheduledTaskBatching    = true;
    public boolean particleThrottle         = true;
    public int     particleDensity          = 80;

    // ── Mind Stone ────────────────────────────────────────────────────────
    public boolean autoTuneEnabled          = true;
    public String  performanceMode          = "balanced";
    public int     targetFPS                = 60;
    public int     autoTuneAggressiveness   = 5;

    // ── Soul Stone (HUD) ──────────────────────────────────────────────────
    public boolean showHUD                  = true;
    public String  hudPosition              = "TOP_LEFT";
    public boolean fpsWarning               = true;
    public int     fpsWarningThreshold      = 30;

    // ── Chaos Stone ───────────────────────────────────────────────────────
    public boolean debugMode                = false;
    public boolean dreamMode                = false;
    public boolean verboseLogging           = false;

    // ── Entity Culling (MoreCulling-inspired) ─────────────────────────────
    /** Back-frustum angular cull for entity rendering. */
    public boolean entityCulling            = true;
    /** Skip rendering block entities beyond this distance. */
    public boolean blockEntityCulling       = true;
    public int     blockEntityCullDist      = 64;
    /** Skip rendering leaf block faces between same-type leaf blocks. */
    public boolean leafCulling              = true;

    // ── Dynamic FPS (DynamicFPS-inspired) ─────────────────────────────────
    public boolean dynamicFpsEnabled        = true;
    public int     unfocusedFpsCap          = 15;
    public boolean reduceVolumeWhenUnfocused = true;
    public int     unfocusedVolumePct       = 30;
    public boolean pauseWhenMinimized       = false;

    // ── Stutter Fixes (StutterFix + SmoothBoot-inspired) ──────────────────
    /** Remove Thread.yield() from render loop (eliminates micro-stutters). */
    public boolean stutterFixEnabled        = true;
    /** Raise render thread to MAX priority (StutterFix ThreadPriority). */
    public boolean renderThreadBoost        = true;
    /** Limit chunk generation threads to avoid starving the render thread. */
    public boolean limitChunkGenThreads     = true;
    /** Max threads to use for chunk generation (0 = auto: cores-2, min 1). */
    public int     maxChunkGenThreads       = 0;
    /** Throttle ForkJoin worker priority at startup (SmoothBoot). */
    public boolean smoothBootEnabled        = true;

    // ── Fast Math (SuperFastMath-inspired) ────────────────────────────────
    /** Use an extended 65536-entry sin/cos lookup table for trig operations. */
    public boolean fastMathEnabled          = true;

    // ── GPU Memory (GpuTape-inspired) ────────────────────────────────────
    /** Register Cleaner on Framebuffer objects to prevent VRAM leaks. */
    public boolean gpuLeakFixEnabled        = true;
    /** Avoid redundant framebuffer bind/unbind during GUI rendering. */
    public boolean avoidRedundantFbSwitch   = true;

    // ── Memory Leak Fixes (FerriteCore / ModernFix-inspired) ──────────────
    /** Clear caches and hint GC on world disconnect. */
    public boolean enableMemoryLeakFixes    = true;
    /** Deduplicate block state neighbor tables to reduce heap usage. */
    public boolean blockStateDeduplication  = true;

    // ── Distant Horizons Compat ───────────────────────────────────────────
    public boolean dhCompatEnabled          = true;
    public int     dhVanillaRenderDist      = 6;

    // ── Shader Preset System (Iris) ───────────────────────────────────────
    public boolean shaderAutoPreset         = true;
    public String  lastDetectedShaderPack   = "";
}
