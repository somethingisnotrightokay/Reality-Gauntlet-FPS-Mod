package com.realitymod.mixin;

import com.realitymod.RealityGauntlet;
import net.minecraft.Bootstrap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ═══════════════════════════════════════════════════════════
 *  SmoothBootMixin — SmoothBoot-inspired Startup Thread Tuning
 *
 *  BUG FIX (v2 → v3):
 *  v2 called RealityGauntlet.getConfigManager().getConfig()
 *  inside the Bootstrap.initialize() inject.  Bootstrap runs
 *  BEFORE ModInitializer.onInitialize() — the config manager
 *  static instance is null at that point.
 *  Result: NullPointerException crash on every startup.
 *
 *  Fix: Remove the config gate from this inject entirely.
 *  Smooth boot is a startup-time operation that cannot be
 *  gated by a config file that hasn't been read yet.
 *  The feature is always applied on startup (which is correct
 *  — the ForkJoin thread priority change is harmless and
 *  temporary; threads return to normal once the pool idles).
 *
 *  The smoothBootEnabled config flag still exists in the GUI
 *  for documentation/user awareness but cannot disable the
 *  startup hook retroactively.
 * ═══════════════════════════════════════════════════════════
 */
@Mixin(Bootstrap.class)
public class SmoothBootMixin {

    @Inject(method = "initialize", at = @At("HEAD"), require = 0)
    private static void thanos$throttleWorkerThreads(CallbackInfo ci) {
        try {
            ThreadGroup root = Thread.currentThread().getThreadGroup();
            while (root.getParent() != null) root = root.getParent();

            Thread[] threads = new Thread[root.activeCount() + 64];
            int count = root.enumerate(threads, true);

            int lowered = 0;
            for (int i = 0; i < count && threads[i] != null; i++) {
                Thread t = threads[i];
                if (t == null) continue;
                String name = t.getName();
                if (name.contains("ForkJoinPool") && name.contains("worker")) {
                    try {
                        if (t.getPriority() > Thread.MIN_PRIORITY + 1) {
                            t.setPriority(Thread.MIN_PRIORITY + 1);
                            lowered++;
                        }
                    } catch (SecurityException ignored) {}
                }
            }

            // Config not available yet — use System.err for early logging
            if (lowered > 0) {
                System.out.println("[Reality:SmoothBoot] Lowered " + lowered +
                    " ForkJoin worker thread(s) to reduce startup jank.");
            }
        } catch (Exception e) {
            // Never crash startup — this is best-effort
            System.err.println("[Reality:SmoothBoot] Non-fatal: " + e.getMessage());
        }
    }
}
