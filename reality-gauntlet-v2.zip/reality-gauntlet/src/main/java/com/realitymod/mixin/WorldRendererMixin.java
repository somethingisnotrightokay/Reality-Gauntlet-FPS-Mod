package com.realitymod.mixin;

import com.realitymod.RealityGauntlet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.WorldRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * WorldRendererMixin — frame-time spike logging for verbose debug mode.
 *
 * BUG FIX (v2 → v3):
 * Added @Unique to the injected field thanos$lastRenderNs to prevent
 * MixinApplyError when another mixin (e.g. Sodium) also injects a
 * field into WorldRenderer.
 */
@Environment(EnvType.CLIENT)
@Mixin(WorldRenderer.class)
public class WorldRendererMixin {

    @Unique
    private long thanos$lastRenderNs = 0;

    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void thanos$onRenderBegin(
            RenderTickCounter tickCounter,
            boolean renderBlockOutline,
            Camera camera,
            GameRenderer gameRenderer,
            LightmapTextureManager lightmapTextureManager,
            Matrix4f matrix4f,
            Matrix4f matrix4f2,
            CallbackInfo ci) {

        if (!RealityGauntlet.getConfigManager().getConfig().verboseLogging) return;

        long now     = System.nanoTime();
        long elapsed = now - thanos$lastRenderNs;
        if (thanos$lastRenderNs != 0 && elapsed > 50_000_000L) {
            RealityGauntlet.LOGGER.debug(
                "[Chrono Crystal] Frame time spike: {}ms", elapsed / 1_000_000
            );
        }
        thanos$lastRenderNs = now;
    }
}
