package com.realitymod.mixin;

import com.realitymod.RealityGauntlet;
import com.realitymod.config.GauntletConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ═══════════════════════════════════════════════════════════
 *  BlockEntityCullMixin — MoreCulling-style BE Culling
 *
 *  Block entities (chests, signs, beacons, spawners, etc.)
 *  each submit geometry to the renderer every frame.  In a
 *  world with many block entities this adds significant CPU
 *  overhead for submitting draw calls that will never be
 *  visible at distance.
 *
 *  We inject at the start of BlockEntityRenderDispatcher.render()
 *  and cancel the call when:
 *    1. blockEntityCulling is enabled, AND
 *    2. the block entity is further than blockEntityCullDist blocks
 *       from the camera.
 *
 *  Close-distance guard: block entities within MIN_DIST blocks
 *  are NEVER culled to prevent pop-in when the player turns.
 *
 *  This is a simplified version of MoreCulling's
 *  BeaconRenderer_frustumMixin, SignRenderer_textMixin, and
 *  BlockEntityRenderer distance checks, combined into one
 *  entry point.
 * ═══════════════════════════════════════════════════════════
 */
@Environment(EnvType.CLIENT)
@Mixin(BlockEntityRenderDispatcher.class)
public class BlockEntityCullMixin {

    /** Block entities within this distance are never culled (prevents pop-in). */
    private static final double MIN_DIST    = 8.0;
    private static final double MIN_DIST_SQ = MIN_DIST * MIN_DIST;

    @Inject(
        method      = "render(Lnet/minecraft/block/entity/BlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;II)V",
        at          = @At("HEAD"),
        cancellable = true,
        require     = 0   // signature mismatch = warning, not crash
    )
    private <E extends BlockEntity> void thanos$cullDistantBlockEntity(
            E blockEntity,
            float tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            int overlay,
            CallbackInfo ci) {

        GauntletConfig cfg = RealityGauntlet.getConfigManager().getConfig();
        if (!cfg.blockEntityCulling) return;

        // Get current camera position from the shared render state
        net.minecraft.client.MinecraftClient client = net.minecraft.client.MinecraftClient.getInstance();
        if (client.gameRenderer == null) return;

        Vec3d camPos = client.gameRenderer.getCamera().getPos();
        BlockPos pos = blockEntity.getPos();

        double dx = pos.getX() + 0.5 - camPos.x;
        double dy = pos.getY() + 0.5 - camPos.y;
        double dz = pos.getZ() + 0.5 - camPos.z;
        double distSq = dx * dx + dy * dy + dz * dz;

        // Close-distance: always render
        if (distSq < MIN_DIST_SQ) return;

        double cutoff = cfg.blockEntityCullDist;
        if (distSq > cutoff * cutoff) {
            ci.cancel();
        }
    }
}
