package com.realitymod.mixin;

import com.realitymod.RealityGauntlet;
import com.realitymod.config.GauntletConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.SimpleFramebuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.ref.Cleaner;

/**
 * FramebufferLeakMixin — GpuTape-inspired VRAM leak detection.
 *
 * FIX: Framebuffer is an abstract class with no (int,int,boolean) constructor.
 * In Yarn 1.21.1, the concrete subclass used by Minecraft for all standard
 * framebuffers is SimpleFramebuffer(int width, int height, boolean useDepth, boolean getError).
 * We target SimpleFramebuffer instead — this covers the vast majority of
 * framebuffer allocations. WindowFramebuffer (the main screen FB) is excluded
 * intentionally as it must never be GC'd.
 */
@Environment(EnvType.CLIENT)
@Mixin(SimpleFramebuffer.class)
public class FramebufferLeakMixin {

    private static final Cleaner CLEANER = Cleaner.create();

    /**
     * Target: SimpleFramebuffer(int width, int height, boolean useDepth, boolean getError)
     * Descriptor: (IIZZ)V
     */
    @Inject(method = "<init>(IIZZ)V", at = @At("TAIL"), require = 0)
    private void thanos$registerGpuCleanup(
            int width, int height, boolean useDepth, boolean getError,
            CallbackInfo ci) {

        GauntletConfig cfg = RealityGauntlet.getConfigManager().getConfig();
        if (!cfg.gpuLeakFixEnabled) return;

        // Read GL ids via reflection now — before this object might be collected.
        // ids[] is a local int[] — the lambda captures ids, NOT 'this'.
        // Capturing 'this' would keep the Framebuffer alive forever (Cleaner anti-pattern).
        final int[] ids = readGlIds();
        final int w = width;
        final int h = height;

        CLEANER.register(this, () -> {
            // Runs on Cleaner daemon thread. GL calls are NOT safe here.
            if (ids[0] != -1 && ids[0] != 0) {
                RealityGauntlet.LOGGER.warn(
                    "[Reality:GpuTape] SimpleFramebuffer GC'd without delete() " +
                    "(fboId={}, {}x{}) — potential VRAM leak.",
                    ids[0], w, h
                );
            }
        });
    }

    /** Read fbo/colorAttachment/depthAttachment via reflection. Falls back to -1. */
    private int[] readGlIds() {
        int[] out = {-1, -1, -1};
        Class<?> cls = this.getClass();
        // Walk up the class hierarchy (SimpleFramebuffer -> Framebuffer)
        while (cls != null && cls != Object.class) {
            tryRead(cls, out, 0, "fbo", "framebufferObject");
            tryRead(cls, out, 1, "colorAttachment", "colorAttachmentId");
            tryRead(cls, out, 2, "depthAttachment", "depthAttachmentId");
            cls = cls.getSuperclass();
        }
        return out;
    }

    private void tryRead(Class<?> cls, int[] out, int idx, String... names) {
        for (String name : names) {
            if (out[idx] != -1) return; // already found
            try {
                java.lang.reflect.Field f = cls.getDeclaredField(name);
                f.setAccessible(true);
                out[idx] = f.getInt(this);
                return;
            } catch (Exception ignored) {}
        }
    }
}
