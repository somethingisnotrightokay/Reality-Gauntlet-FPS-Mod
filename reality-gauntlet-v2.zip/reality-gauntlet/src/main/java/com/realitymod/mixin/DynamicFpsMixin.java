package com.realitymod.mixin;

import com.realitymod.RealityGauntlet;
import com.realitymod.config.GauntletConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ═══════════════════════════════════════════════════════════
 *  DynamicFpsMixin — StutterFix yield removal + DynamicFPS throttle
 *
 *  BUG FIX (v2 → v3):
 *  1. Removed unused import of RealityGauntletClient — caused
 *     a compilation warning that became an error with -Xlint:all.
 *
 *  2. The @Inject target `method = "render"` was ambiguous.
 *     MinecraftClient in 1.21.1 has two render methods:
 *       • render(boolean)          — legacy tick-driven path
 *       • render(RenderTickCounter) — new 1.21 frame path
 *     Without a descriptor, Mixin selects one non-deterministically.
 *     Fixed: use the boolean overload descriptor `(Z)V` which is the
 *     one containing Thread.yield() and the frame timing logic.
 *
 *  3. Added @Unique to the instance field thanos$lastRenderMs to
 *     comply with Mixin field naming conventions and avoid shadow
 *     conflicts with other mixins targeting MinecraftClient.
 * ═══════════════════════════════════════════════════════════
 */
@Environment(EnvType.CLIENT)
@Mixin(MinecraftClient.class)
public class DynamicFpsMixin {

    /** Timestamp (ms) of the last render frame start, used for FPS cap sleep. */
    @Unique
    private long thanos$lastRenderMs = 0L;

    // ── Feature 1: Remove Thread.yield() from render loop ─────────────────

    /**
     * Redirect Thread.yield() inside render(boolean) to nothing.
     * Eliminates OS-scheduling micro-stutters (1–15 ms) caused by yield.
     * Descriptor (Z)V ensures we target the boolean overload only.
     * require=0: if Mojang removes the yield in a patch, log warning, no crash.
     */
    @Redirect(
        method  = "render(Z)V",
        at      = @At(value = "INVOKE", target = "Ljava/lang/Thread;yield()V"),
        require = 0
    )
    private void thanos$removeRenderYield() {
        GauntletConfig cfg = RealityGauntlet.getConfigManager().getConfig();
        if (!cfg.stutterFixEnabled) {
            Thread.yield();  // pass-through when user opts out
        }
        // else: swallow — no yield, no micro-stutter
    }

    // ── Feature 2: Reduce FPS when window is unfocused ────────────────────

    /**
     * At the start of each render(boolean) call, sleep to cap FPS
     * when the window is not in focus.  Uses elapsed time to be
     * accurate even if a single frame took longer than the target.
     * Descriptor (Z)V matches the boolean overload.
     */
    @Inject(method = "render(Z)V", at = @At("HEAD"), require = 0)
    private void thanos$dynamicFpsThrottle(boolean renderTick, CallbackInfo ci) {
        MinecraftClient client = (MinecraftClient)(Object) this;
        GauntletConfig cfg = RealityGauntlet.getConfigManager().getConfig();

        if (!cfg.dynamicFpsEnabled) { thanos$lastRenderMs = 0; return; }
        if (client.isWindowFocused()) { thanos$lastRenderMs = 0; return; }

        int fpsCap = cfg.pauseWhenMinimized ? 1 : cfg.unfocusedFpsCap;
        if (fpsCap <= 0 || fpsCap >= 255) { thanos$lastRenderMs = 0; return; }

        long targetMs = 1000L / fpsCap;
        long now      = System.currentTimeMillis();

        if (thanos$lastRenderMs > 0L) {
            long elapsed = now - thanos$lastRenderMs;
            long sleepMs = targetMs - elapsed;
            if (sleepMs > 1L && sleepMs <= targetMs) {
                try {
                    Thread.sleep(sleepMs);
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                }
            }
        }

        thanos$lastRenderMs = System.currentTimeMillis();
    }
}
