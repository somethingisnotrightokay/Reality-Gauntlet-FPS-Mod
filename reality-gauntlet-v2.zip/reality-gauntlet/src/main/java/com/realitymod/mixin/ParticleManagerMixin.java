package com.realitymod.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;

/**
 * ParticleManagerMixin — server-side stub.
 * @Environment ensures it never loads on dedicated server.
 *
 * Note: This targets ServerWorld as a placeholder. Actual client
 * particle interception is in ParticleClientMixin.
 */
@Environment(EnvType.CLIENT)
@Mixin(ServerWorld.class)
public class ParticleManagerMixin {
    // Future: intercept sendParticles() to suppress distant particle packets.
}
