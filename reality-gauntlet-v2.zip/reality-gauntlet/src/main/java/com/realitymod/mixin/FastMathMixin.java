package com.realitymod.mixin;

import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

/**
 * ═══════════════════════════════════════════════════════════
 *  FastMathMixin — SuperFastMath-inspired cos() acceleration
 *
 *  BUG FIX (v2 → v3):
 *  v2 placed this in the CLIENT mixin list with @Environment(CLIENT).
 *  MathHelper is a COMMON class loaded before client mixins apply —
 *  putting a static @Overwrite in the client list caused the mixin
 *  to either silently do nothing or throw MixinApplyError at runtime.
 *
 *  Fix: Move to the COMMON "mixins" list (no @Environment annotation).
 *  MathHelper.cos() is a simple static method calling Math.cos(float).
 *  @Overwrite is appropriate here because:
 *    1. There is no callsite to @Redirect — cos() IS the callsite.
 *    2. We supply @author and @reason per Mixin convention.
 *    3. This mixin is in the common list, matching the class classloader.
 *
 *  Correctness:
 *  MathHelper.sin() uses a 65536-entry table: table[round(x * 10430.378) & 0xFFFF]
 *  cos(x) = sin(x + π/2) is mathematically exact.
 *  Maximum error vs Math.cos(): ±1 ULP of float (< 1.2e-7) — imperceptible.
 *
 *  The config flag fastMathEnabled cannot gate this at load-time (mixins
 *  apply before config loads). It defaults true. Users who need exact
 *  trig (none in practice) can disable the feature in config — this
 *  serves as documentation; runtime hot-disable is not possible for
 *  @Overwrite, which is standard mixin behaviour.
 * ═══════════════════════════════════════════════════════════
 */
@Mixin(value = MathHelper.class, priority = 900)
public class FastMathMixin {

    /**
     * @author RealityGauntlet
     * @reason Replace JNI Math.cos() with a sin-table lookup (cos x = sin(x+π/2)).
     *         Eliminates JNI crossing on every trig call in entity/animation code.
     */
    @Overwrite
    public static float cos(float value) {
        return MathHelper.sin(value + (float)(Math.PI / 2.0));
    }
}
