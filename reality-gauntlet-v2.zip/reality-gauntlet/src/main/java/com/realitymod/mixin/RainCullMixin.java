package com.realitymod.mixin;

import com.realitymod.RealityGauntlet;
import com.realitymod.config.GauntletConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * RainCullMixin — suppress weather rendering in Dream Mode or when unfocused.
 *
 * FIX: The method was named "renderRainAndSnow" which has never existed in
 * Yarn mappings. The correct Yarn name across all versions including 1.21.1 is
 * "renderWeather". This caused "unable to determine descriptor" every build.
 *
 * The method signature is:
 *   renderWeather(LightmapTextureManager, float, double, double, double)V
 * We capture the LightmapTextureManager parameter to satisfy the descriptor,
 * but ignore it — we only need to conditionally cancel.
 */
@Environment(EnvType.CLIENT)
@Mixin(WorldRenderer.class)
public class RainCullMixin {

    @Inject(
        method      = "renderWeather",
        at          = @At("HEAD"),
        cancellable = true,
        require     = 0
    )
    private void thanos$maybeCullWeather(
            LightmapTextureManager lightmapTextureManager,
            float tickDelta,
            double x, double y, double z,
            CallbackInfo ci) {

        GauntletConfig cfg = RealityGauntlet.getConfigManager().getConfig();

        if (cfg.dreamMode || cfg.particleDensity == 0) {
            ci.cancel();
            return;
        }

        if (cfg.dynamicFpsEnabled) {
            net.minecraft.client.MinecraftClient client =
                net.minecraft.client.MinecraftClient.getInstance();
            if (client != null && !client.isWindowFocused()) {
                ci.cancel();
            }
        }
    }
}
