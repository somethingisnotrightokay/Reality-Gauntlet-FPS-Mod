package com.realitymod.mixin;

import com.realitymod.RealityGauntlet;
import com.realitymod.config.GauntletConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeavesBlock;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.block.BlockModelRenderer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockRenderView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * LeafCullMixin — skip rendering fully-interior leaf blocks.
 *
 * FIX v5: renderSmooth and renderFlat both return void in Yarn 1.21.1.
 * Using CallbackInfoReturnable<Boolean> caused a descriptor mismatch crash
 * at startup. Corrected to CallbackInfo + ci.cancel().
 *
 * FIX v3: RandomSource → net.minecraft.util.math.random.Random.
 */
@Environment(EnvType.CLIENT)
@Mixin(BlockModelRenderer.class)
public class LeafCullMixin {

    @Inject(method = "renderSmooth", at = @At("HEAD"), cancellable = true, require = 0)
    private void thanos$cullLeafSmooth(
            BlockRenderView world,
            BakedModel model,
            BlockState state,
            BlockPos pos,
            MatrixStack matrices,
            VertexConsumer vertexConsumer,
            boolean cull,
            Random random,
            long seed,
            int overlay,
            CallbackInfo ci) {
        if (shouldCullLeaf(world, state, pos)) ci.cancel();
    }

    @Inject(method = "renderFlat", at = @At("HEAD"), cancellable = true, require = 0)
    private void thanos$cullLeafFlat(
            BlockRenderView world,
            BakedModel model,
            BlockState state,
            BlockPos pos,
            MatrixStack matrices,
            VertexConsumer vertexConsumer,
            boolean cull,
            Random random,
            long seed,
            int overlay,
            CallbackInfo ci) {
        if (shouldCullLeaf(world, state, pos)) ci.cancel();
    }

    private boolean shouldCullLeaf(BlockRenderView world, BlockState state, BlockPos pos) {
        GauntletConfig cfg = RealityGauntlet.getConfigManager().getConfig();
        if (!cfg.leafCulling) return false;
        if (!(state.getBlock() instanceof LeavesBlock)) return false;
        for (Direction dir : Direction.values()) {
            if (world.getBlockState(pos.offset(dir)).getBlock() != state.getBlock()) return false;
        }
        return true;
    }
}
