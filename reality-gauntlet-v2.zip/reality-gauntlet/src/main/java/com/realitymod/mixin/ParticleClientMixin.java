package com.realitymod.mixin;

import com.realitymod.RealityGauntlet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * ParticleClientMixin — throttles client-side particle spawning.
 *
 * FIX: In all Yarn 1.21.x versions, ParticleManager.addParticle has exactly
 * ONE public overload: addParticle(ParticleEffect, double, double, double, double, double, double)
 * returning @Nullable Particle.
 *
 * The 7-arg boolean overload (ZDDDDDD) never existed in Yarn mappings.
 * The old descriptor (DDDDDD)V was also wrong — the method returns Particle, not void.
 * Correct descriptor: (Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;
 *
 * We use CallbackInfoReturnable<Particle> and setReturnValue(null) to cancel
 * (returning null from addParticle is the documented "no particle spawned" signal).
 */
@Environment(EnvType.CLIENT)
@Mixin(value = ParticleManager.class, priority = 900)
public class ParticleClientMixin {

    @Inject(
        method  = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
        at      = @At("HEAD"),
        cancellable = true,
        require = 0
    )
    private void thanos$throttleParticle(
            ParticleEffect parameters,
            double x, double y, double z,
            double velocityX, double velocityY, double velocityZ,
            CallbackInfoReturnable<net.minecraft.client.particle.Particle> cir) {

        if (!RealityGauntlet.getAetherCrystal().shouldSpawnParticle()) {
            cir.setReturnValue(null);
        }
    }
}
