package com.realitymod.mixin;

import com.realitymod.modules.ChronoCrystal;
import net.minecraft.server.world.ServerChunkManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ServerChunkManagerMixin — extension point for async lighting (Reality Stone).
 *
 * BUG FIX (v2 → v3):
 * Added require=0 to the inject (was missing, defaultRequire was 1 globally
 * in v2's mixins.json — meaning a method rename would crash the game).
 * Now defaultRequire is 0 globally and this is a stub that logs nothing —
 * safe to leave as an extension point for future implementation.
 */
@Mixin(ServerChunkManager.class)
public class ServerChunkManagerMixin {

    /**
     * FIX v6: In Yarn 1.21.1, ServerChunkManager.tick() has signature:
     *   tick(BooleanSupplier shouldKeepTicking, boolean tickChunks)
     * The previous version was missing the boolean parameter, causing a
     * descriptor mismatch crash when entering a world (server tick loop).
     * Added boolean tickChunks as the second parameter.
     */
    @Inject(method = "tick", at = @At("HEAD"), require = 0)
    private void thanos$onChunkManagerTick(
            java.util.function.BooleanSupplier shouldKeepTicking,
            boolean tickChunks,
            CallbackInfo ci) {
        // Extension point: async lighting / enhanced chunk loading
        // ChronoCrystal.isAsyncLightingEnabled() — implementation deferred
    }
}
