package com.realitymod.mixin;

import com.realitymod.RealityGauntletClient;
import com.realitymod.modules.ChronoCrystal;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Applies render/sim distance once on world join only.
 * NEVER polls every tick — that was causing chunk reloads.
 */
@Environment(EnvType.CLIENT)
@Mixin(MinecraftClient.class)
public class ClientTickMixin {

    @Unique private boolean reality$worldApplied = false;

    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void reality$onTick(CallbackInfo ci) {
        MinecraftClient mc = (MinecraftClient)(Object)this;
        if (mc.world == null) {
            reality$worldApplied = false;
            return;
        }
        if (!reality$worldApplied) {
            RealityGauntletClient client = RealityGauntletClient.getInstance();
            if (client != null) {
                ChronoCrystal cc = RealityGauntletClient.getChronoCrystal();
                if (cc != null) cc.apply();
            }
            reality$worldApplied = true;
        }
    }
}
