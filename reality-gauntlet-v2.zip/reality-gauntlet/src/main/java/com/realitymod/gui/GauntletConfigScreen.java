package com.realitymod.gui;

import com.realitymod.RealityGauntlet;
import com.realitymod.RealityGauntletClient;
import com.realitymod.autotune.SystemDetector;
import com.realitymod.config.ConfigManager;
import com.realitymod.config.GauntletConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.*;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

/**
 * GauntletConfigScreen v8
 *
 * BLUR FIX: Zero use of EntryListWidget / scissor. Every text label is a
 * TextWidget added directly via addDrawableChild(). Rows beyond what fits
 * use simple prev/next sub-page buttons — no scrolling widget, no scissor.
 *
 * CHUNK RELOAD FIX: close() no longer calls reloadConfig() on ChronoCrystal.
 * Only the render-distance and sim-distance sliders call it, and only when
 * their value actually changes.
 */
public class GauntletConfigScreen extends Screen {

    // ── Colours ──────────────────────────────────────────────
    private static final int BG        = 0xD0050510;
    private static final int PANEL     = 0xFF0E0B1C;
    private static final int BORDER    = 0xFF3A2070;
    private static final int HEADER_BG = 0xFF160D2E;
    private static final int GLOW      = 0xFF5C20A8;
    private static final int NAV_BG    = 0xFF100B22;
    private static final int NAV_SEL   = 0xFF2A1550;
    private static final int NAV_MARK  = 0xFF7030D0;
    private static final int CONTENT   = 0xFF090614;
    private static final int SECT_BG   = 0x40A060FF;
    private static final int SECT_LINE = 0xFF5C20A8;
    private static final int SEP       = 0x60604080;
    private static final int FOOTER_BG = 0xFF0A0818;

    // ── Layout constants ─────────────────────────────────────
    private static final int HEADER_H = 26;
    private static final int PRESET_H = 22;
    private static final int FOOTER_H = 26;
    private static final int NAV_W    = 112;
    private static final int PAD      = 6;
    private static final int ROW_H    = 22;

    // ── Panel bounds (computed in init) ──────────────────────
    private int px, py, panelW, panelH;
    private int navX, navY, navH;
    private int contentX, contentY, contentW, contentH;

    // ── State ─────────────────────────────────────────────────
    private int activePage  = 0;
    private int subPage     = 0;   // pagination within a tab

    private static final String[] TABS = {
        "Overview","Rendering","Entities","Memory",
        "Performance","Dynamic FPS","Stutter","Compat","HUD/Debug"
    };

    private final Screen parent;

    // Row data built per page (no widgets here — just descriptors)
    private final List<RowDef> rows = new ArrayList<>();

    public GauntletConfigScreen(Screen parent) {
        super(Text.literal("Reality Gauntlet"));
        this.parent = parent;
    }

    // =========================================================
    //  Screen init — called on open and after every tab switch
    // =========================================================

    @Override
    protected void init() {
        super.init();

        int margin = 6;
        panelW = MathHelper.clamp(this.width  - margin * 2, 320, 680);
        panelH = MathHelper.clamp(this.height - margin * 2, 220, 440);
        px = (this.width  - panelW) / 2;
        py = (this.height - panelH) / 2;

        navX = px + 1;
        navY = py + HEADER_H + PRESET_H + 1;
        navH = panelH - HEADER_H - PRESET_H - FOOTER_H - 3;

        contentX = px + NAV_W + 3;
        contentY = navY;
        contentW = panelW - NAV_W - 5;
        contentH = navH;

        buildNav();
        buildPresets();
        buildContent();
        buildFooter();
    }

    // ── Nav ───────────────────────────────────────────────────

    private void buildNav() {
        int btnH = Math.max(14, Math.min(20, (navH - TABS.length) / TABS.length));
        int totalH = TABS.length * (btnH + 1) - 1;
        int startY = navY + Math.max(0, (navH - totalH) / 2);

        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            addDrawableChild(ButtonWidget.builder(Text.literal(TABS[i]), b -> {
                activePage = idx;
                subPage    = 0;
                clearAndInit();
            }).dimensions(navX + 2, startY + i * (btnH + 1), NAV_W - 4, btnH).build());
        }
    }

    // ── Preset bar ────────────────────────────────────────────

    private void buildPresets() {
        int y  = py + HEADER_H + (PRESET_H - 16) / 2;
        int x0 = px + NAV_W + PAD;
        int avail = panelW - NAV_W - PAD * 2;
        int bw = Math.max(46, (avail - 9) / 4);
        ConfigManager mgr = RealityGauntlet.getConfigManager();

        addDrawableChild(ButtonWidget.builder(Text.literal("Low"), b -> {
            mgr.applyPreset("low_end"); subPage = 0; clearAndInit();
        }).dimensions(x0, y, bw, 16).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Balanced"), b -> {
            mgr.applyPreset("balanced"); subPage = 0; clearAndInit();
        }).dimensions(x0 + bw + 3, y, bw, 16).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Ultra"), b -> {
            mgr.applyPreset("ultra"); subPage = 0; clearAndInit();
        }).dimensions(x0 + (bw + 3) * 2, y, bw, 16).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Cycle Mode"), b -> {
            String m = RealityGauntletClient.getFluxCrystal().cycleMode();
            if (client != null && client.player != null)
                client.player.sendMessage(Text.literal("[Reality] Mode: " + m), true);
        }).dimensions(x0 + (bw + 3) * 3, y, bw, 16).build());
    }

    // ── Footer ────────────────────────────────────────────────

    private void buildFooter() {
        int y = py + panelH - FOOTER_H + (FOOTER_H - 18) / 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
            .dimensions(px + panelW - PAD - 76, y, 76, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset Page"), b -> {
            subPage = 0; clearAndInit();
        }).dimensions(px + panelW - PAD - 76 - 84, y, 82, 18).build());
    }

    // =========================================================
    //  Content — build row descriptors then place widgets
    // =========================================================

    private void buildContent() {
        rows.clear();
        GauntletConfig cfg = RealityGauntlet.getConfigManager().getConfig();
        switch (activePage) {
            case 0 -> pageOverview(cfg);
            case 1 -> pageRendering(cfg);
            case 2 -> pageEntities(cfg);
            case 3 -> pageMemory(cfg);
            case 4 -> pagePerformance(cfg);
            case 5 -> pageDynamicFps(cfg);
            case 6 -> pageStutter(cfg);
            case 7 -> pageCompat(cfg);
            case 8 -> pageHudDebug(cfg);
        }
        placeRows();
    }

    /**
     * Place the current sub-page of rows as actual widgets.
     * TextWidget for labels — added directly to Screen (NO list widget, NO scissor).
     * Control widgets placed the same way.
     */
    private void placeRows() {
        // How many rows fit in the content area?
        int maxRows = Math.max(1, contentH / ROW_H);
        int totalRows = rows.size();
        int totalPages = Math.max(1, (totalRows + maxRows - 1) / maxRows);
        subPage = MathHelper.clamp(subPage, 0, totalPages - 1);

        int start = subPage * maxRows;
        int end   = Math.min(start + maxRows, totalRows);

        for (int i = start; i < end; i++) {
            RowDef row = rows.get(i);
            int ry = contentY + (i - start) * ROW_H;
            int cy = ry + (ROW_H - 9) / 2; // vertically centre 8px font

            if (row.kind == RowKind.SECTION) {
                // Section: just a TextWidget label, no control
                TextWidget label = new TextWidget(
                    contentX, cy, contentW, 9,
                    Text.literal(row.label),
                    this.textRenderer
                );
                label.alignLeft();
                label.setTextColor(0xFFBB77FF);
                addDrawableChild(label);
            } else if (row.kind == RowKind.INFO) {
                // Info: label left, value right — both TextWidget
                TextWidget lw = new TextWidget(
                    contentX + PAD, cy, contentW / 2 - PAD * 2, 9,
                    Text.literal(row.label), this.textRenderer
                );
                lw.alignLeft();
                lw.setTextColor(0xFFCCCCCC);
                addDrawableChild(lw);

                TextWidget vw = new TextWidget(
                    contentX + contentW / 2, cy, contentW / 2 - PAD, 9,
                    Text.literal(row.value != null ? row.value : ""),
                    this.textRenderer
                );
                vw.alignLeft();
                vw.setTextColor(0xFF55FFFF);
                addDrawableChild(vw);
            } else {
                // TOGGLE / SLIDER / CYCLE — label left, widget right
                int labelMaxW = contentW / 2 - PAD * 2;
                String lbl = row.label;
                if (this.textRenderer.getWidth(lbl) > labelMaxW)
                    lbl = this.textRenderer.trimToWidth(lbl, labelMaxW - 4) + "...";

                TextWidget lw = new TextWidget(
                    contentX + PAD, cy, labelMaxW, 9,
                    Text.literal(lbl), this.textRenderer
                );
                lw.alignLeft();
                lw.setTextColor(0xFFFFFFFF);
                if (row.tooltip != null)
                    lw.setTooltip(Tooltip.of(Text.literal(row.tooltip)));
                addDrawableChild(lw);

                if (row.widget != null) {
                    int ww = row.widget.getWidth();
                    int wx = contentX + contentW - ww - PAD;
                    int wy = ry + (ROW_H - row.widget.getHeight()) / 2;
                    row.widget.setX(wx);
                    row.widget.setY(wy);
                    addDrawableChild(row.widget);
                }
            }
        }

        // Sub-page navigation (only if more than one page)
        if (totalPages > 1) {
            int navY2 = contentY + contentH - 18;
            if (subPage > 0)
                addDrawableChild(ButtonWidget.builder(Text.literal("< Prev"), b -> {
                    subPage--; clearAndInit();
                }).dimensions(contentX + PAD, navY2, 54, 14).build());

            // Page indicator — TextWidget, no blur
            TextWidget pageLabel = new TextWidget(
                contentX + contentW / 2 - 20, navY2 + 3, 40, 9,
                Text.literal((subPage + 1) + " / " + totalPages), this.textRenderer
            );
            pageLabel.setTextColor(0xFF888888);
            addDrawableChild(pageLabel);

            if (subPage < totalPages - 1)
                addDrawableChild(ButtonWidget.builder(Text.literal("Next >"), b -> {
                    subPage++; clearAndInit();
                }).dimensions(contentX + contentW - PAD - 54, navY2, 54, 14).build());
        }
    }

    // =========================================================
    //  Row builder helpers
    // =========================================================

    private enum RowKind { SECTION, INFO, TOGGLE, SLIDER, CYCLE }

    private static class RowDef {
        RowKind kind;
        String label, value, tooltip;
        ClickableWidget widget;
    }

    private void section(String title) {
        RowDef r = new RowDef(); r.kind = RowKind.SECTION; r.label = title;
        rows.add(r);
    }

    private void info(String label, String value) {
        RowDef r = new RowDef(); r.kind = RowKind.INFO;
        r.label = label; r.value = value;
        rows.add(r);
    }

    private void toggle(String label, boolean val, Consumer<Boolean> onChange, String tip) {
        boolean[] cur = {val};
        ButtonWidget btn = ButtonWidget.builder(
            Text.literal(cur[0] ? "ON" : "OFF"),
            b -> {
                cur[0] = !cur[0];
                onChange.accept(cur[0]);
                b.setMessage(Text.literal(cur[0] ? "ON" : "OFF"));
                RealityGauntlet.getConfigManager().save();
            }
        ).dimensions(0, 0, 72, 16).build();
        if (tip != null) btn.setTooltip(Tooltip.of(Text.literal(tip)));

        RowDef r = new RowDef(); r.kind = RowKind.TOGGLE;
        r.label = label; r.tooltip = tip; r.widget = btn;
        rows.add(r);
    }

    private void slider(String label, int val, int min, int max,
                        IntConsumer onChange, String tip) {
        IntSlider s = new IntSlider(0, 0, 120, 16, label, val, min, max, onChange);
        if (tip != null) s.setTooltip(Tooltip.of(Text.literal(tip)));

        RowDef r = new RowDef(); r.kind = RowKind.SLIDER;
        r.label = label; r.tooltip = tip; r.widget = s;
        rows.add(r);
    }

    private void cycle(String label, String cur, String[] vals, String[] names,
                       Consumer<String> onChange, String tip) {
        int[] idx = {findIdx(vals, cur)};
        ButtonWidget btn = ButtonWidget.builder(
            Text.literal(names[idx[0]]),
            b -> {
                idx[0] = (idx[0] + 1) % vals.length;
                onChange.accept(vals[idx[0]]);
                b.setMessage(Text.literal(names[idx[0]]));
                RealityGauntlet.getConfigManager().save();
            }
        ).dimensions(0, 0, 100, 16).build();
        if (tip != null) btn.setTooltip(Tooltip.of(Text.literal(tip)));

        RowDef r = new RowDef(); r.kind = RowKind.CYCLE;
        r.label = label; r.tooltip = tip; r.widget = btn;
        rows.add(r);
    }

    // =========================================================
    //  Page definitions
    // =========================================================

    private void pageOverview(GauntletConfig cfg) {
        section("System");
        info("CPU Cores",  String.valueOf(SystemDetector.getCpuCores()));
        info("System RAM", SystemDetector.getTotalRamMB() + " MB");
        info("JVM Heap",   SystemDetector.getJvmHeapMB() + " MB max");
        info("GPU",        cap(SystemDetector.getGpuRenderer(), 28));
        info("Tier",       SystemDetector.getDetectedTier().name());
        section("Render Stack");
        info("Renderer",   RealityGauntletClient.getShaderDetector().getRenderStackSummary());
        String pack = RealityGauntletClient.getShaderDetector().getActiveShaderPackName();
        info("Shader Pack", pack.isBlank() ? "None" : pack);
        info("Distant Horizons", RealityGauntletClient.getDhCompat().isDhPresent()
            ? "v" + RealityGauntletClient.getDhCompat().getDhVersion() : "Not installed");
        section("Active");
        info("Auto-Tune",      cfg.autoTuneEnabled   ? "ON" : "OFF");
        info("Entity Culling", cfg.entityCulling      ? "ON" : "OFF");
        info("BE Culling",     cfg.blockEntityCulling ? "ON" : "OFF");
        info("Dynamic FPS",    cfg.dynamicFpsEnabled  ? "ON" : "OFF");
        info("Fast Math",      cfg.fastMathEnabled    ? "ON" : "OFF");
    }

    private void pageRendering(GauntletConfig cfg) {
        section("Chunk Rendering");
        slider("Render Distance", cfg.renderDistance, 2, 32,
            v -> { cfg.renderDistance = v;
                   RealityGauntletClient.getChronoCrystal().reloadConfig(cfg); },
            "Full-detail chunk radius. Lower = higher FPS.");
        slider("Simulation Distance", cfg.simulationDistance, 2, 32,
            v -> { cfg.simulationDistance = v;
                   RealityGauntletClient.getChronoCrystal().reloadConfig(cfg); },
            "Server-side tick radius.");
        toggle("Enhanced Chunk Loading", cfg.enhancedChunkLoading,
            v -> cfg.enhancedChunkLoading = v,
            "Pre-queues adjacent chunks to reduce pop-in.");
        toggle("Async Lighting", cfg.asyncLighting,
            v -> cfg.asyncLighting = v,
            "Runs lighting recalculations off the main thread.");
        section("Culling");
        toggle("Leaf Face Culling", cfg.leafCulling,
            v -> cfg.leafCulling = v,
            "Skip hidden leaf faces adjacent to same-type leaves.");
        toggle("Block Entity Culling", cfg.blockEntityCulling,
            v -> cfg.blockEntityCulling = v,
            "Skip rendering distant block entities.");
        slider("BE Cull Distance", cfg.blockEntityCullDist, 16, 256,
            v -> cfg.blockEntityCullDist = v,
            "Block entities beyond this many blocks skip rendering.");
        toggle("Entity Camera Culling", cfg.entityCulling,
            v -> cfg.entityCulling = v,
            "Don't render entities more than 90° behind camera.");
    }

    private void pageEntities(GauntletConfig cfg) {
        section("Entity AI");
        toggle("Skip Distant AI", cfg.skipDistantAI,
            v -> cfg.skipDistantAI = v,
            "Mobs beyond AI distance skip pathfinding ticks.");
        slider("AI Distance (blocks)", cfg.entityTickDistance, 8, 128,
            v -> cfg.entityTickDistance = v,
            "Mobs within this range get full AI.");
        section("Entity Cap");
        slider("Entity Cap (per dim)", cfg.entityCap, 0, 1000,
            v -> cfg.entityCap = v,
            "Hard cap on entities per dimension. 0 = disabled.");
        section("Culling");
        toggle("Entity Camera Culling", cfg.entityCulling,
            v -> cfg.entityCulling = v, null);
        toggle("Block Entity Culling", cfg.blockEntityCulling,
            v -> cfg.blockEntityCulling = v, null);
        slider("BE Cull Distance", cfg.blockEntityCullDist, 16, 256,
            v -> cfg.blockEntityCullDist = v, null);
    }

    private void pageMemory(GauntletConfig cfg) {
        section("GC / Cleanup");
        slider("GC Interval (sec)", cfg.memoryCleanupInterval, 0, 300,
            v -> cfg.memoryCleanupInterval = v,
            "Seconds between GC hint. 0 = disabled.");
        toggle("Memory Leak Fixes", cfg.enableMemoryLeakFixes,
            v -> cfg.enableMemoryLeakFixes = v,
            "Clears entity tick-map on world disconnect.");
        section("Block State");
        toggle("BlockState Deduplication", cfg.blockStateDeduplication,
            v -> cfg.blockStateDeduplication = v,
            "Deduplicate block state tables — saves 200-400 MB.");
        toggle("Lazy Block Entities", cfg.lazyTileEntities,
            v -> cfg.lazyTileEntities = v,
            "Defer block entity init until first access.");
        section("GPU Memory");
        toggle("GPU Leak Fix", cfg.gpuLeakFixEnabled,
            v -> cfg.gpuLeakFixEnabled = v,
            "Register JVM Cleaner on Framebuffer objects.");
        toggle("Avoid Redundant FB Switch", cfg.avoidRedundantFbSwitch,
            v -> cfg.avoidRedundantFbSwitch = v,
            "Skip redundant framebuffer bind/unbind.");
    }

    private void pagePerformance(GauntletConfig cfg) {
        section("Auto-Tune");
        toggle("Auto-Tune Enabled", cfg.autoTuneEnabled,
            v -> cfg.autoTuneEnabled = v,
            "Automatically adjusts settings to maintain target FPS.");
        slider("Target FPS", cfg.targetFPS, 15, 240,
            v -> cfg.targetFPS = v, "FPS the auto-tuner aims for.");
        slider("Aggressiveness (1-10)", cfg.autoTuneAggressiveness, 1, 10,
            v -> cfg.autoTuneAggressiveness = v,
            "How aggressively the auto-tuner reduces settings.");
        section("Particles");
        toggle("Particle Throttle", cfg.particleThrottle,
            v -> cfg.particleThrottle = v,
            "Reduce particle density when FPS drops below target.");
        slider("Particle Density %", cfg.particleDensity, 0, 100,
            v -> cfg.particleDensity = v, "100 = full vanilla density.");
        toggle("Dream Mode", cfg.dreamMode,
            v -> cfg.dreamMode = v,
            "Suppress ALL particles and weather for max performance.");
        section("Redstone");
        toggle("Skip Distant Redstone", cfg.skipDistantRedstone,
            v -> cfg.skipDistantRedstone = v,
            "Skip redstone updates beyond cutoff distance.");
        slider("Redstone Cutoff (blocks)", cfg.redstoneCutoffDist, 16, 128,
            v -> cfg.redstoneCutoffDist = v, null);
        section("Math");
        toggle("Fast Math", cfg.fastMathEnabled,
            v -> cfg.fastMathEnabled = v,
            "Replace Math.cos() with sin-table lookup.");
    }

    private void pageDynamicFps(GauntletConfig cfg) {
        section("Window Focus");
        toggle("Dynamic FPS Enabled", cfg.dynamicFpsEnabled,
            v -> cfg.dynamicFpsEnabled = v,
            "Cap FPS when window is not focused.");
        slider("Unfocused FPS Cap", cfg.unfocusedFpsCap, 1, 60,
            v -> cfg.unfocusedFpsCap = v, "FPS limit when unfocused.");
        toggle("Pause When Minimized", cfg.pauseWhenMinimized,
            v -> cfg.pauseWhenMinimized = v,
            "Drop to 1 FPS when window is minimized.");
        section("Audio");
        toggle("Reduce Volume When Unfocused", cfg.reduceVolumeWhenUnfocused,
            v -> cfg.reduceVolumeWhenUnfocused = v,
            "Lower master volume when window loses focus.");
        slider("Unfocused Volume %", cfg.unfocusedVolumePct, 0, 100,
            v -> cfg.unfocusedVolumePct = v, "0 = muted when unfocused.");
    }

    private void pageStutter(GauntletConfig cfg) {
        section("Render Thread");
        toggle("Remove Thread.yield()", cfg.stutterFixEnabled,
            v -> cfg.stutterFixEnabled = v,
            "Remove Thread.yield() from render loop to fix stutter spikes.");
        toggle("Render Thread Priority Boost", cfg.renderThreadBoost,
            v -> cfg.renderThreadBoost = v,
            "Set render thread to MAX_PRIORITY.");
        section("Chunk Gen Threads");
        toggle("Limit Chunk Gen Threads", cfg.limitChunkGenThreads,
            v -> cfg.limitChunkGenThreads = v,
            "Prevent chunk gen from using all CPU cores.");
        slider("Max Chunk Gen Threads", cfg.maxChunkGenThreads, 0, 16,
            v -> cfg.maxChunkGenThreads = v,
            "0 = auto (cores-2). Recommend 2 on a 4-core CPU.");
        section("Startup");
        toggle("Smooth Boot", cfg.smoothBootEnabled,
            v -> cfg.smoothBootEnabled = v,
            "Lower ForkJoin thread priority during startup.");
    }

    private void pageCompat(GauntletConfig cfg) {
        section("Distant Horizons");
        info("DH Status", RealityGauntletClient.getDhCompat().isDhPresent()
            ? "v" + RealityGauntletClient.getDhCompat().getDhVersion() : "Not installed");
        toggle("DH Compatibility", cfg.dhCompatEnabled,
            v -> cfg.dhCompatEnabled = v,
            "Reduce vanilla render dist when DH is active.");
        slider("DH Vanilla Render Dist", cfg.dhVanillaRenderDist, 2, 12,
            v -> cfg.dhVanillaRenderDist = v,
            "Vanilla chunk radius when DH is active (2-12).");
        section("Iris Shaders");
        info("Iris Present",   RealityGauntletClient.getShaderDetector().isIrisPresent()    ? "Yes" : "No");
        info("Shaders Active", RealityGauntletClient.getShaderDetector().isShadersEnabled() ? "Yes" : "No");
        toggle("Shader Auto Preset", cfg.shaderAutoPreset,
            v -> cfg.shaderAutoPreset = v,
            "Apply a tuned performance preset based on the active Iris pack.");
        section("Companion Mods");
        info("Sodium",       "GPU rendering — install separately");
        info("Lithium",      "Server-side perf — install separately");
        info("FerriteCore",  "Block state RAM — install separately");
    }

    private void pageHudDebug(GauntletConfig cfg) {
        section("HUD");
        toggle("Show FPS HUD", cfg.showHUD,
            v -> cfg.showHUD = v,
            "Display FPS counter and active mode in-game.");
        cycle("HUD Position", cfg.hudPosition,
            new String[]{"TOP_LEFT","TOP_RIGHT","BOTTOM_LEFT","BOTTOM_RIGHT"},
            new String[]{"Top-Left","Top-Right","Bottom-Left","Bottom-Right"},
            v -> cfg.hudPosition = v, "Corner where the HUD is drawn.");
        toggle("FPS Warning Flash", cfg.fpsWarning,
            v -> cfg.fpsWarning = v,
            "Flash red when FPS drops below threshold.");
        slider("Warning Threshold", cfg.fpsWarningThreshold, 10, 120,
            v -> cfg.fpsWarningThreshold = v,
            "FPS level that triggers the red warning flash.");
        section("Debug");
        toggle("Debug Mode", cfg.debugMode,
            v -> cfg.debugMode = v,
            "Show extended overlay: entity count, frame time, memory.");
        toggle("Dream Mode", cfg.dreamMode,
            v -> cfg.dreamMode = v, "Suppress all particles.");
        toggle("Verbose Logging", cfg.verboseLogging,
            v -> cfg.verboseLogging = v,
            "Log per-crystal activity to the game log.");
    }

    // =========================================================
    //  Render — only chrome/backgrounds. All text is widgets.
    // =========================================================

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // Full-screen dim
        ctx.fill(0, 0, this.width, this.height, BG);

        // Panel
        ctx.fill(px, py, px + panelW, py + panelH, PANEL);
        border(ctx, px, py, panelW, panelH, BORDER);

        // Header
        ctx.fill(px, py, px + panelW, py + HEADER_H, HEADER_BG);
        ctx.fill(px, py + HEADER_H - 1, px + panelW, py + HEADER_H, GLOW);

        // FPS in header — header has no scissor so drawText is fine here
        int fps    = MinecraftClient.getInstance().getCurrentFps();
        int target = RealityGauntlet.getConfigManager().getConfig().targetFPS;
        int fpsCol = fps >= target ? 0xFF55FF55 : fps >= target / 2 ? 0xFFFFFF55 : 0xFFFF5555;
        ctx.drawText(textRenderer, "Reality Gauntlet  |  v1.0",
            px + PAD + 2, py + (HEADER_H - 8) / 2, 0xFFFFD700, true);
        ctx.drawText(textRenderer, fps + " FPS",
            px + panelW - textRenderer.getWidth(fps + " FPS") - PAD,
            py + (HEADER_H - 8) / 2, fpsCol, true);

        // Preset strip
        ctx.fill(px, py + HEADER_H, px + panelW, py + HEADER_H + PRESET_H, HEADER_BG);
        ctx.fill(navX, py + HEADER_H, navX + NAV_W, py + HEADER_H + PRESET_H, NAV_BG);
        ctx.fill(navX, py + HEADER_H + PRESET_H - 1,
                 navX + NAV_W, py + HEADER_H + PRESET_H, SEP);
        String mode = RealityGauntlet.getConfigManager().getConfig().performanceMode.toUpperCase();
        ctx.drawText(textRenderer, mode, navX + 4,
            py + HEADER_H + (PRESET_H - 8) / 2, 0xFFAAAAAA, true);

        // Nav background + active highlight
        ctx.fill(navX, navY, navX + NAV_W, navY + navH, NAV_BG);
        ctx.fill(navX + NAV_W, navY, navX + NAV_W + 1, navY + navH, SEP);

        // Active nav button tint (drawn behind the actual button widget)
        int btnH2 = Math.max(14, Math.min(20, (navH - TABS.length) / TABS.length));
        int totalH2 = TABS.length * (btnH2 + 1) - 1;
        int startY2 = navY + Math.max(0, (navH - totalH2) / 2);
        int selY = startY2 + activePage * (btnH2 + 1);
        ctx.fill(navX + 2, selY, navX + NAV_W - 2, selY + btnH2, NAV_SEL);
        ctx.fill(navX + 2, selY, navX + 4,          selY + btnH2, NAV_MARK);

        // Content background + section row highlights are drawn per-section
        ctx.fill(contentX, contentY, contentX + contentW, contentY + contentH, CONTENT);

        // Section rows — draw tinted background for SECTION rows
        int maxRows = Math.max(1, contentH / ROW_H);
        int start   = subPage * maxRows;
        int end     = Math.min(start + maxRows, rows.size());
        for (int i = start; i < end; i++) {
            RowDef row = rows.get(i);
            int ry = contentY + (i - start) * ROW_H;
            if (row.kind == RowKind.SECTION) {
                ctx.fill(contentX, ry, contentX + contentW, ry + ROW_H, SECT_BG);
                ctx.fill(contentX, ry + ROW_H - 1, contentX + contentW, ry + ROW_H, SECT_LINE);
            } else if ((i - start) % 2 == 0) {
                ctx.fill(contentX, ry, contentX + contentW, ry + ROW_H, 0x08FFFFFF);
            }
        }

        // Footer
        int fy = py + panelH - FOOTER_H;
        ctx.fill(px, fy, px + panelW, py + panelH, FOOTER_BG);
        ctx.fill(px, fy, px + panelW, fy + 1, SEP);
        String sys = SystemDetector.getCpuCores() + " cores  " +
            Runtime.getRuntime().maxMemory() / 1024 / 1024 + " MB heap  " +
            cap(SystemDetector.getGpuRenderer(), 20);
        ctx.drawText(textRenderer, sys, px + PAD, fy + (FOOTER_H - 8) / 2, 0xFF777777, true);

        // All child widgets rendered on top (including TextWidget labels)
        super.render(ctx, mx, my, delta);
    }

    // =========================================================
    //  Lifecycle
    // =========================================================

    @Override
    public void close() {
        RealityGauntlet.getConfigManager().forceSave();
        // IMPORTANT: do NOT call ChronoCrystal.reloadConfig() here.
        // That would trigger chunk reloads. Sliders call it directly
        // when the user actually changes render/sim distance.
        GauntletConfig cfg = RealityGauntlet.getConfigManager().getConfig();
        RealityGauntletClient.getPrismaCrystal().reloadConfig(cfg);
        RealityGauntletClient.getEchoCrystal().reloadConfig(cfg);
        RealityGauntlet.getVoidCrystal().reloadConfig(cfg);
        RealityGauntlet.getAetherCrystal().reloadConfig(cfg);
        RealityGauntlet.getCoreCrystal().reloadConfig(cfg);
        this.client.setScreen(parent);
    }

    @Override public boolean shouldCloseOnEsc() { return true;  }
    @Override public boolean shouldPause()       { return false; }

    // =========================================================
    //  Helpers
    // =========================================================

    private void border(DrawContext ctx, int x, int y, int w, int h, int col) {
        ctx.fill(x,       y,       x + w,     y + 1,     col);
        ctx.fill(x,       y + h-1, x + w,     y + h,     col);
        ctx.fill(x,       y,       x + 1,     y + h,     col);
        ctx.fill(x + w-1, y,       x + w,     y + h,     col);
    }

    private static String cap(String s, int max) {
        if (s == null || s.isBlank()) return "Unknown";
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }

    private static int findIdx(String[] arr, String val) {
        for (int i = 0; i < arr.length; i++) if (arr[i].equals(val)) return i;
        return 0;
    }

    // =========================================================
    //  Integer slider widget
    // =========================================================

    static final class IntSlider extends SliderWidget {
        private final String base;
        private final int min, max;
        private final IntConsumer onChange;

        IntSlider(int x, int y, int w, int h, String base,
                  int value, int min, int max, IntConsumer onChange) {
            super(x, y, w, h, Text.empty(), (double)(value - min) / Math.max(1, max - min));
            this.base = base; this.min = min; this.max = max; this.onChange = onChange;
            updateMessage();
        }
        @Override protected void updateMessage() { setMessage(Text.literal(base + ": " + cur())); }
        @Override protected void applyValue()    { onChange.accept(cur()); }
        int cur() { return (int) Math.round(min + value * (max - min)); }
    }
}
