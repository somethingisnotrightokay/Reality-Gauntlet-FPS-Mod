package com.realitymod.gui;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/**
 * Registers GauntletConfigScreen as the ModMenu config screen.
 * ModMenu is optional at runtime — this class is only loaded
 * if ModMenu is present in the mod list.
 */
public class GauntletModMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> new GauntletConfigScreen(parent);
    }
}
