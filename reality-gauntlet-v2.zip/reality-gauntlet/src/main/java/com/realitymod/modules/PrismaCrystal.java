package com.realitymod.modules;

import com.realitymod.RealityGauntlet;
import com.realitymod.RealityGauntletClient;
import com.realitymod.config.GauntletConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/**
 * Soul Stone — Player Comfort Features (HUD, warnings)
 */
@Environment(EnvType.CLIENT)
public class PrismaCrystal {

    private GauntletConfig config;
    private int     warningBlinkTick = 0;
    private boolean warningVisible   = false;

    public void init(GauntletConfig config) {
        this.config = config;
        RealityGauntlet.LOGGER.info("[Soul Stone] Init — HUD={} position={} warning={}",
            config.showHUD, config.hudPosition, config.fpsWarning);

        net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback.EVENT.register(
            (drawContext, tickCounter) -> renderHUD(drawContext, MinecraftClient.getInstance())
        );
    }

    public void tick(MinecraftClient client) {
        if (!config.fpsWarning) { warningVisible = false; return; }
        int fps = client.getCurrentFps();
        if (fps < config.fpsWarningThreshold) {
            warningBlinkTick = (warningBlinkTick + 1) % 20;
            warningVisible   = warningBlinkTick < 10;
        } else {
            warningVisible   = false;
            warningBlinkTick = 0;
        }
    }

    public void renderHUD(DrawContext context, MinecraftClient client) {
        if (!config.showHUD) return;
        // debugEnabled was renamed to showDebugHud in 1.21.x Yarn mappings
        if (client.getDebugHud().shouldShowDebugHud()) return;

        int fps  = client.getCurrentFps();
        String mode = RealityGauntletClient.getFluxCrystal().getCurrentModeDisplayName();

        int fpsColour;
        if (fps >= config.targetFPS)                fpsColour = 0x55FF55;
        else if (fps >= config.fpsWarningThreshold) fpsColour = 0xFFFF55;
        else                                        fpsColour = 0xFF5555;

        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();

        int x, y;
        switch (config.hudPosition) {
            case "TOP_RIGHT"    -> { x = screenW - 80; y = 4; }
            case "BOTTOM_LEFT"  -> { x = 4;            y = screenH - 24; }
            case "BOTTOM_RIGHT" -> { x = screenW - 80; y = screenH - 24; }
            default             -> { x = 4;            y = 4; }
        }

        context.drawText(client.textRenderer, String.format("FPS: %d", fps), x, y, fpsColour, true);
        context.drawText(client.textRenderer, "\u00a77" + mode, x, y + 10, 0xAAAAAA, true);

        if (warningVisible) {
            int cx = screenW / 2 - 30;
            context.drawText(client.textRenderer, "\u00a7cFPS Critical!", cx, 40, 0xFF5555, true);
        }

        if (config.debugMode) {
            renderDebugLines(context, client, x, y + 20);
        }
    }

    private void renderDebugLines(DrawContext context, MinecraftClient client, int x, int y) {
        if (client.world == null) return;

        // Count entities by iterating — getEntityCount() doesn't exist on ClientWorld
        int entityCount = 0;
        for (var ignored : client.world.getEntities()) entityCount++;

        long memMB = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1_048_576;

        context.drawText(client.textRenderer,
            String.format("\u00a77Entities: %d", entityCount), x, y, 0xAAAAAA, true);
        context.drawText(client.textRenderer,
            String.format("\u00a77Mem: %d MB", memMB), x, y + 10, 0xAAAAAA, true);
    }

    public void reloadConfig(GauntletConfig newConfig) {
        this.config = newConfig;
    }
}
