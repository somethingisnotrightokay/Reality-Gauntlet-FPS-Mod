package com.realitymod.modules;

import com.realitymod.RealityGauntlet;
import com.realitymod.config.GauntletConfig;
import net.minecraft.client.MinecraftClient;

public class ChronoCrystal {

    private GauntletConfig config;
    private boolean initialised = false;

    // Only track the values that actually cause chunk reloads when changed
    private int lastAppliedRender = -999;
    private int lastAppliedSim    = -999;

    public void init(GauntletConfig config) {
        this.config = config;
        RealityGauntlet.LOGGER.info("[Chrono Crystal] Init — renderDist={} simDist={}",
            config.renderDistance, config.simulationDistance);
    }

    /**
     * Apply render/sim distance — ONLY if the value actually changed.
     * getViewDistance().setValue() triggers a full chunk reload in 1.21.1
     * even when called with the same value. Never call unless changed.
     */
    public void apply() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.options == null) return;

        if (config.renderDistance != lastAppliedRender) {
            client.options.getViewDistance().setValue(config.renderDistance);
            lastAppliedRender = config.renderDistance;
            RealityGauntlet.LOGGER.info("[Chrono Crystal] Render distance -> {}", config.renderDistance);
        }

        if (config.simulationDistance != lastAppliedSim) {
            client.options.getSimulationDistance().setValue(config.simulationDistance);
            lastAppliedSim = config.simulationDistance;
            RealityGauntlet.LOGGER.info("[Chrono Crystal] Sim distance -> {}", config.simulationDistance);
        }

        initialised = true;
    }

    /**
     * Called when render/sim distance sliders change.
     * ONLY updates config + applies — does NOT reset the cache.
     * Resetting the cache was the bug: it made apply() think the value
     * changed and call setValue() unnecessarily, causing chunk reloads.
     */
    public void reloadConfig(GauntletConfig newConfig) {
        this.config = newConfig;
        if (initialised) {
            apply(); // apply() already guards with the change-check
        }
    }

    public static boolean isAsyncLightingEnabled() {
        return RealityGauntlet.getConfigManager().getConfig().asyncLighting;
    }

    public static boolean isEnhancedChunkLoadingEnabled() {
        return RealityGauntlet.getConfigManager().getConfig().enhancedChunkLoading;
    }
}
