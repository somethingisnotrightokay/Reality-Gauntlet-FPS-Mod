package com.realitymod.modules;

import com.realitymod.RealityGauntlet;
import com.realitymod.config.GauntletConfig;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

/**
 * ═══════════════════════════════════════════════════════════
 *  ⬡ Time Stone — Tick Skipping & Scheduled Updates
 *
 *  Mechanisms:
 *  1. Redstone skip  — skip update evaluation for redstone
 *     components beyond redstoneCutoffDist from any player.
 *     Gated by skipDistantRedstone flag (RedstoneMixin).
 *  2. Task batching  — collect pending scheduled ticks and
 *     flush them in groups to reduce per-tick overhead.
 *  3. Particle throttle — ParticleClientMixin reads
 *     shouldSpawnParticle() before adding each particle.
 *
 *  This class is the logic coordinator; Mixins call in.
 * ═══════════════════════════════════════════════════════════
 */
public class AetherCrystal {

    private GauntletConfig config;

    /** Pending deferred block updates when batching is active. */
    private final List<DeferredBlockUpdate> batchQueue = new ArrayList<>(64);

    // ── Lifecycle ─────────────────────────────────────────────────────────

    public void init(GauntletConfig config) {
        this.config = config;
        RealityGauntlet.LOGGER.info(
            "[Time Stone] Init — skipRedstone={} cutoff={} batching={} particles={}%%",
            config.skipDistantRedstone, config.redstoneCutoffDist,
            config.scheduledTaskBatching, config.particleDensity
        );
    }

    // ── Redstone ──────────────────────────────────────────────────────────

    /**
     * Called from RedstoneMixin before each redstone update evaluation.
     *
     * @param world      The world where the update is occurring.
     * @param pos        Block position of the redstone component.
     * @param playerX    Nearest player X.
     * @param playerZ    Nearest player Z.
     * @return true  → run the update normally.
     *         false → skip this update (return early from mixin).
     */
    public boolean shouldEvaluateRedstone(World world, BlockPos pos,
                                          double playerX, double playerZ) {
        if (!config.skipDistantRedstone) return true;

        double dx = pos.getX() - playerX;
        double dz = pos.getZ() - playerZ;
        double distSq = dx * dx + dz * dz;
        double cutoffSq = (double) config.redstoneCutoffDist * config.redstoneCutoffDist;

        return distSq <= cutoffSq;
    }

    // ── Scheduled task batching ───────────────────────────────────────────

    /**
     * Enqueue a block update for deferred batch execution.
     * Returns true if the update was accepted into the batch,
     * false if batching is disabled (caller should run it now).
     */
    public boolean enqueueBatchUpdate(BlockPos pos, Runnable update) {
        if (!config.scheduledTaskBatching) return false;
        if (batchQueue.size() >= 256) {
            // Safety valve — don't let the queue grow unbounded
            flushBatch();
        }
        batchQueue.add(new DeferredBlockUpdate(pos, update));
        return true;
    }

    /**
     * Execute all batched updates at once.
     * Called at the end of each server tick (WorldTickMixin).
     */
    public void flushBatch() {
        if (batchQueue.isEmpty()) return;
        int count = batchQueue.size();
        for (DeferredBlockUpdate u : batchQueue) {
            try { u.update.run(); }
            catch (Exception e) {
                RealityGauntlet.LOGGER.warn("[Time Stone] Batch update error: {}", e.getMessage());
            }
        }
        batchQueue.clear();
        if (config.verboseLogging) {
            RealityGauntlet.LOGGER.debug("[Time Stone] Flushed {} batched updates.", count);
        }
    }

    // ── Particle throttling ───────────────────────────────────────────────

    /** Rolling counter to implement density-based particle skipping. */
    private int particleCounter = 0;

    /**
     * Called from ParticleClientMixin for every particle spawn attempt.
     *
     * Uses a simple modulo approach: if density is 70%, only 7 out of
     * every 10 spawn attempts are allowed through.
     *
     * @return true → spawn the particle, false → skip it.
     */
    public boolean shouldSpawnParticle() {
        if (config.dreamMode)          return false;   // no particles at all
        if (!config.particleThrottle)  return true;    // throttle disabled
        if (config.particleDensity >= 100) return true;
        if (config.particleDensity <= 0)   return false;

        particleCounter = (particleCounter + 1) % 100;
        return particleCounter < config.particleDensity;
    }

    // ── Config hot-reload ─────────────────────────────────────────────────

    public void reloadConfig(GauntletConfig newConfig) {
        this.config = newConfig;
        batchQueue.clear();
        particleCounter = 0;
    }

    // ── Inner type ────────────────────────────────────────────────────────

    private record DeferredBlockUpdate(BlockPos pos, Runnable update) {}
}
