package com.realitymod.modules;

import com.realitymod.RealityGauntlet;
import com.realitymod.config.GauntletConfig;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Space Stone — World / Memory Management
 */
public class CoreCrystal {

    private GauntletConfig config;
    private ScheduledExecutorService scheduler;

    public void init(GauntletConfig config) {
        this.config = config;
        RealityGauntlet.LOGGER.info(
            "[Space Stone] Init — lazyTE={} asyncBlocks={} cleanupInterval={}s",
            config.lazyTileEntities, config.asyncBlockUpdates, config.memoryCleanupInterval
        );
        startMemoryCleanup();
    }

    private void startMemoryCleanup() {
        stopMemoryCleanup();
        int interval = config.memoryCleanupInterval;
        if (interval <= 0) return;

        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "Reality-CoreCrystal-GC");
            t.setDaemon(true);
            return t;
        });

        scheduler.scheduleAtFixedRate(() -> {
            try {
                performMemoryCleanup();
            } catch (Exception e) {
                RealityGauntlet.LOGGER.warn("[Space Stone] Cleanup error: {}", e.getMessage());
            }
        }, interval, interval, TimeUnit.SECONDS);

        RealityGauntlet.LOGGER.info("[Space Stone] Memory cleanup scheduled every {}s.", interval);
    }

    private void stopMemoryCleanup() {
        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.shutdownNow();
        }
    }

    public void performMemoryCleanup() {
        long before = usedMemoryMB();
        System.gc();
        long after  = usedMemoryMB();
        long freed  = before - after;

        if (config.verboseLogging || freed > 50) {
            RealityGauntlet.LOGGER.info(
                "[Space Stone] GC hint fired — freed ~{} MB ({}→{} MB used).",
                freed, before, after
            );
        }
    }

    private long usedMemoryMB() {
        Runtime rt = Runtime.getRuntime();
        return (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
    }

    public static boolean isLazyTileEntities() {
        return RealityGauntlet.getConfigManager().getConfig().lazyTileEntities;
    }

    public static boolean isAsyncBlockUpdates() {
        return RealityGauntlet.getConfigManager().getConfig().asyncBlockUpdates;
    }

    public void reloadConfig(GauntletConfig newConfig) {
        this.config = newConfig;
        startMemoryCleanup();
    }

    public void shutdown() {
        stopMemoryCleanup();
    }
}
