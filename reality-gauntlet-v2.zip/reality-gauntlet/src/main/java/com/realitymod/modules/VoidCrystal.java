package com.realitymod.modules;

import com.realitymod.RealityGauntlet;
import com.realitymod.config.GauntletConfig;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.world.ServerWorld;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Power Stone — Entity & Mob Tick Control
 */
public class VoidCrystal {

    private GauntletConfig config;
    private final Map<UUID, Long> lastTickedMap = new HashMap<>();

    public void init(GauntletConfig config) {
        this.config = config;
        RealityGauntlet.LOGGER.info(
            "[Power Stone] Init — entityTickDist={} entityCap={} skipAI={}",
            config.entityTickDistance, config.entityCap, config.skipDistantAI
        );
    }

    public boolean shouldSkipDistantAI() {
        return config.skipDistantAI;
    }

    public boolean shouldTickEntityAI(MobEntity entity, double playerX, double playerZ, long gameTime) {
        if (!config.skipDistantAI) return true;
        if (!(entity instanceof MobEntity)) return true;

        double dx = entity.getX() - playerX;
        double dz = entity.getZ() - playerZ;
        double distSq  = dx * dx + dz * dz;
        double cutoffSq = (double) config.entityTickDistance * config.entityTickDistance;

        if (distSq <= cutoffSq) return true;

        UUID id = entity.getUuid();
        long lastTick = lastTickedMap.getOrDefault(id, 0L);
        if (gameTime - lastTick >= 4) {
            lastTickedMap.put(id, gameTime);
            return true;
        }
        return false;
    }

    public void pruneTickCache(long currentGameTime) {
        lastTickedMap.entrySet().removeIf(e -> currentGameTime - e.getValue() > 200);
    }

    /**
     * Returns true if another mob can be spawned in the given world.
     * Uses a simple iteration count — avoids the broken spliterator chain.
     */
    public boolean canSpawnMore(ServerWorld world) {
        if (config.entityCap <= 0) return true;
        int count = 0;
        for (Entity ignored : world.iterateEntities()) {
            count++;
            if (count >= config.entityCap) return false;
        }
        return true;
    }

    public void reloadConfig(GauntletConfig newConfig) {
        this.config = newConfig;
        lastTickedMap.clear();
    }

    /** Called on world disconnect — flush the entity tick-time cache to free memory. */
    public void onWorldUnload() {
        int cleared = lastTickedMap.size();
        lastTickedMap.clear();
        if (cleared > 0) {
            RealityGauntlet.LOGGER.debug(
                "[Power Stone] World unload — cleared {} stale entity tick entries.", cleared
            );
        }
    }

    public int getEntityTickDistance() { return config.entityTickDistance; }
    public int getEntityCap()          { return config.entityCap;          }
}
