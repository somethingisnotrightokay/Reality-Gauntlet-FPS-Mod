package com.realitymod.modules;

import com.realitymod.RealityGauntlet;
import com.realitymod.config.GauntletConfig;
import com.realitymod.shader.ShaderDetector;

import java.util.List;

/**
 * ═══════════════════════════════════════════════════════════
 *  ⬡ Mind Stone — Intelligent Auto-Tuning
 *
 *  Coordinates mode switching and exposes the current
 *  performance mode to other components.
 *
 *  AutoTuner does the heavy number-crunching; FluxCrystal
 *  is the interface (mode cycle, suggestions, telemetry).
 * ═══════════════════════════════════════════════════════════
 */
public class FluxCrystal {

    private static final List<String> CYCLE_ORDER = List.of("low_end", "balanced", "ultra", "custom");

    private final ShaderDetector shaderDetector;

    public FluxCrystal(ShaderDetector shaderDetector) {
        this.shaderDetector = shaderDetector;
        RealityGauntlet.LOGGER.info("[Mind Stone] Init — shaders: {}",
            shaderDetector.getRenderStackSummary());
    }

    // ── Mode cycling (hotkey) ─────────────────────────────────────────────

    /**
     * Advance to the next performance mode in the cycle.
     * @return The name of the new mode (for HUD notification).
     */
    public String cycleMode() {
        GauntletConfig cfg = RealityGauntlet.getConfigManager().getConfig();
        String current = cfg.performanceMode;
        int idx = CYCLE_ORDER.indexOf(current);
        String next = CYCLE_ORDER.get((idx + 1) % CYCLE_ORDER.size());

        if (!next.equals("custom")) {
            RealityGauntlet.getConfigManager().applyPreset(next);
        } else {
            cfg.performanceMode = "custom";
            RealityGauntlet.getConfigManager().save();
        }

        RealityGauntlet.LOGGER.info("[Mind Stone] Mode cycled: {} → {}", current, next);
        return formatModeName(next);
    }

    /**
     * Directly set a mode by string key.
     * Used by the config GUI Apply button.
     */
    public void setMode(String mode) {
        if (!mode.equals("custom")) {
            RealityGauntlet.getConfigManager().applyPreset(mode);
        }
    }

    // ── Getters ───────────────────────────────────────────────────────────

    public String getCurrentMode() {
        return RealityGauntlet.getConfigManager().getConfig().performanceMode;
    }

    public String getCurrentModeDisplayName() {
        return formatModeName(getCurrentMode());
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private String formatModeName(String mode) {
        return switch (mode) {
            case "low_end"  -> "Low-End (Max FPS)";
            case "balanced" -> "Balanced";
            case "ultra"    -> "Ultra (High Visuals)";
            default         -> "Custom";
        };
    }

    public ShaderDetector getShaderDetector() { return shaderDetector; }
}
