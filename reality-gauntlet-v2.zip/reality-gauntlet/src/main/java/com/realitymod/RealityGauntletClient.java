package com.realitymod;

import com.realitymod.autotune.AutoTuner;
import com.realitymod.autotune.SystemDetector;
import com.realitymod.compat.DistantHorizonsCompat;
import com.realitymod.config.ConfigManager;
import com.realitymod.config.GauntletConfig;
import com.realitymod.modules.*;
import com.realitymod.shader.ShaderDetector;
import com.realitymod.shader.ShaderPresetManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class RealityGauntletClient implements ClientModInitializer {

    private static RealityGauntletClient instance;

    private ChronoCrystal        chronoCrystal;
    private FluxCrystal          fluxCrystal;
    private PrismaCrystal        prismaCrystal;
    private EchoCrystal          echoCrystal;
    private DynamicFpsModule     dynamicFpsModule;
    private AutoTuner            autoTuner;
    private ShaderDetector       shaderDetector;
    private ShaderPresetManager  shaderPresetManager;
    private DistantHorizonsCompat dhCompat;

    public static KeyBinding cycleModeKey;

    private int     tickCounter    = 0;
    private boolean lastShadersOn  = false;
    private String  lastShaderPack = "";

    private static final int AUTO_TUNE_INTERVAL = 100; // ticks ≈ 5 s

    @Override
    public void onInitializeClient() {
        instance = this;
        ConfigManager cfg = RealityGauntlet.getConfigManager();

        shaderDetector      = new ShaderDetector();
        shaderPresetManager = new ShaderPresetManager(shaderDetector);
        SystemDetector.detect();

        chronoCrystal    = new ChronoCrystal();  chronoCrystal.init(cfg.getConfig());
        fluxCrystal      = new FluxCrystal(shaderDetector);
        prismaCrystal    = new PrismaCrystal();  prismaCrystal.init(cfg.getConfig());
        echoCrystal      = new EchoCrystal();    echoCrystal.init(cfg.getConfig());
        dynamicFpsModule = new DynamicFpsModule();
        autoTuner        = new AutoTuner(fluxCrystal, shaderDetector);
        dhCompat         = new DistantHorizonsCompat();

        shaderPresetManager.logSupportedPacks();

        cycleModeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "reality.config.hotkeySwitchMode",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_K,
            "Reality Gauntlet"
        ));

        ClientLifecycleEvents.CLIENT_STARTED.register(client ->
            RealityGauntlet.LOGGER.info("[Reality] Client started. System: {}", SystemDetector.getSummary())
        );

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            GauntletConfig activeCfg = cfg.getConfig();
            if (dhCompat.isDhPresent() && activeCfg.dhCompatEnabled) {
                boolean changed = dhCompat.onWorldLoad(activeCfg);
                if (changed) { chronoCrystal.reloadConfig(activeCfg); cfg.forceSave(); }
            }
            if (activeCfg.shaderAutoPreset && shaderDetector.isShadersEnabled()) {
                applyShaderPreset(activeCfg);
            }
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            dhCompat.onWorldUnload();
            GauntletConfig activeCfg = cfg.getConfig();
            if (activeCfg.enableMemoryLeakFixes) {
                RealityGauntlet.getVoidCrystal().onWorldUnload();
                RealityGauntlet.getCoreCrystal().performMemoryCleanup();
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);

        RealityGauntlet.LOGGER.info("[Reality] Client online. DH={} | Shader={}",
            dhCompat.isDhPresent(), shaderDetector.getRenderStackSummary());
    }

    private void onClientTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;

        while (cycleModeKey.wasPressed()) {
            String newMode = fluxCrystal.cycleMode();
            client.player.sendMessage(Text.literal("[Reality] Mode: " + newMode), true);
        }

        boolean shadersNow  = shaderDetector.isShadersEnabled();
        String  packNow     = shadersNow ? shaderDetector.getActiveShaderPackName() : "";
        boolean toggled     = shadersNow != lastShadersOn;
        boolean packChanged = !packNow.equals(lastShaderPack) && !packNow.isBlank();

        if (toggled || (shadersNow && packChanged)) {
            lastShadersOn  = shadersNow;
            lastShaderPack = packNow;
            GauntletConfig cfg = RealityGauntlet.getConfigManager().getConfig();
            if (cfg.shaderAutoPreset) {
                if (shadersNow) {
                    applyShaderPreset(cfg);
                    chronoCrystal.reloadConfig(cfg);
                    RealityGauntlet.getConfigManager().forceSave();
                    if (client.player != null) {
                        client.player.sendMessage(
                            Text.literal("[Reality] Shader preset applied for: " + packNow), true);
                    }
                } else {
                    RealityGauntlet.getConfigManager().applyPreset(cfg.performanceMode);
                    chronoCrystal.reloadConfig(cfg);
                }
            }
        }

        dynamicFpsModule.tick(client);

        if (++tickCounter >= AUTO_TUNE_INTERVAL) {
            tickCounter = 0;
            if (RealityGauntlet.getConfigManager().getConfig().autoTuneEnabled) {
                autoTuner.evaluate(client);
            }
        }

        prismaCrystal.tick(client);
        echoCrystal.tick(client);
    }

    private void applyShaderPreset(GauntletConfig cfg) {
        ShaderPresetManager.ShaderPreset preset = shaderPresetManager.refreshAndGetPreset();
        if (preset == null) return;
        if (dhCompat.isDhPresent() && cfg.dhCompatEnabled) {
            int dhDist = cfg.dhVanillaRenderDist > 0 ? cfg.dhVanillaRenderDist : 6;
            shaderPresetManager.applyPresetToConfig(cfg, preset);
            if (cfg.renderDistance > dhDist) cfg.renderDistance = dhDist;
        } else {
            shaderPresetManager.applyPresetToConfig(cfg, preset);
        }
    }

    // ── Accessors ──────────────────────────────────────────────────────────
    public static RealityGauntletClient getInstance()            { return instance;                  }
    public static ChronoCrystal         getChronoCrystal()      { return instance.chronoCrystal;    }
    public static FluxCrystal           getFluxCrystal()        { return instance.fluxCrystal;      }
    public static PrismaCrystal         getPrismaCrystal()      { return instance.prismaCrystal;    }
    public static EchoCrystal           getEchoCrystal()        { return instance.echoCrystal;      }
    public static DynamicFpsModule      getDynamicFpsModule()   { return instance.dynamicFpsModule; }
    public static AutoTuner             getAutoTuner()          { return instance.autoTuner;        }
    public static ShaderDetector        getShaderDetector()     { return instance.shaderDetector;   }
    public static ShaderPresetManager   getShaderPresetManager(){ return instance.shaderPresetManager; }
    public static DistantHorizonsCompat getDhCompat()           { return instance.dhCompat;         }
}
