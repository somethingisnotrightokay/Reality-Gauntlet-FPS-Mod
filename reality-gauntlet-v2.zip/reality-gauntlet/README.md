# 🔮 Reality Gauntlet
### *Seven Crystals. One Gauntlet. Infinite FPS.*

[![Minecraft 1.21.1](https://img.shields.io/badge/Minecraft-1.21.1-brightgreen)](https://minecraft.net/)
[![Fabric Loader](https://img.shields.io/badge/Fabric%20Loader-0.16.9+-blue)](https://fabricmc.net/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow)](LICENSE)
[![Modrinth](https://img.shields.io/badge/Modrinth-Available-green)](https://modrinth.com/mod/reality-gauntlet)

> *The ultimate Fabric performance optimizer for Minecraft 1.21.1. Reads your hardware, auto-tunes FPS, entities, chunks, redstone, and shaders — works alongside Sodium + Iris.*

---

## What Does This Mod Do?

If Minecraft runs slowly, this mod fixes it automatically. It reads your CPU, RAM, and GPU, applies optimal settings, and monitors FPS live — adjusting in real-time with no restarts needed.

---

## Minecraft Version

| Version | Supported |
|---------|-----------|
| **1.21.1** | ✅ Target version |
| 1.21.2 / 1.21.3 / 1.21.4 | ⚠️ Untested |
| 1.20.x and below | ❌ No |
| Forge / NeoForge | ❌ No — Fabric only |

---

## The Seven Reality Crystals

| Crystal | Name | What It Does |
|---------|------|-------------|
| 🔵 | **Chrono Crystal** | Auto-adjusts render distance, chunk loading, leaf culling |
| 🔴 | **Void Crystal** | Skips AI ticks for distant mobs, entity caps |
| ⚫ | **Core Crystal** | Memory cleanup, block state deduplication, GPU leak detection |
| 🟣 | **Aether Crystal** | Throttles particles and distant redstone |
| 🟡 | **Flux Crystal** | Auto-tunes all settings live based on FPS and hardware |
| 🟠 | **Prisma Crystal** | HUD overlay, FPS warnings, unfocused volume reduction |
| 🌀 | **Echo Crystal** | Debug mode, Dream Mode (no particles), verbose logging |

---

## Installation

**Required:**
1. Install [Fabric Loader 0.16.9+](https://fabricmc.net/use/installer/) for MC 1.21.1
2. Place [Fabric API](https://modrinth.com/mod/fabric-api) in your `mods` folder
3. Place `reality-gauntlet-1.0.0.jar` in `mods`
4. Launch with the Fabric profile

**Optional (recommended):**
- [Sodium](https://modrinth.com/mod/sodium) — faster GPU rendering
- [Iris](https://modrinth.com/mod/iris) — shader support
- [Cloth Config](https://modrinth.com/mod/cloth-config) — in-game settings GUI
- [ModMenu](https://modrinth.com/mod/modmenu) — access settings from the Mods menu

> Mods folder: `%appdata%\.minecraft\mods`

---

## Performance Modes

Press **K** to cycle modes in-game:

| Mode | Best For | Settings |
|------|----------|---------|
| 🔴 Low-End | Old/slow PCs | Render 6, particles 30%, AI stops >16 blocks |
| 🟡 Balanced | Most PCs | Render 10, particles 70%, AI stops >32 blocks |
| 🟢 Ultra | High-end PCs | Render 16, full particles, minimal restrictions |
| ⚙️ Custom | Power users | Full manual control |

---

## Configuration GUI

Open via ModMenu → Reality Gauntlet → Config.

The GUI is **fully responsive**: works at any GUI scale (1x through 4x) and any resolution, including fullscreen.

Sections:
- **Overview** — live system stats, render stack, active features
- **Rendering** — chunks, simulation distance, culling options
- **Entities** — AI distance, entity caps, camera culling
- **Memory** — GC intervals, block state dedup, GPU leak fix
- **Performance** — auto-tune, particles, redstone, fast math
- **Dynamic FPS** — unfocused throttle, volume reduction
- **Stutter Fix** — render thread priority, chunk gen thread cap
- **Compat** — Distant Horizons, Iris shader presets
- **HUD/Debug** — overlay, warnings, dream mode, verbose log

---

## Known Resolved Issues (v1 Audit)

| Bug | Fix |
|-----|-----|
| `LeafCullMixin` crash on startup | `renderSmooth`/`renderFlat` return void — was using wrong `CallbackInfoReturnable` |
| `ServerChunkManagerMixin` crash on world load | `tick()` in 1.21.1 has 2 params `(BooleanSupplier, boolean)` — boolean was missing |
| `ChunkGenThreadLimitMixin` crash on world load | Same `tick()` signature mismatch — boolean param added |
| GL crash on startup (EXCEPTION_ACCESS_VIOLATION) | GL11 called before OpenGL context exists — replaced with OSHI hardware detection |
| GUI invisible at GUI scale 1 | Fixed 640×400 panel overflowed 480p screen — panel is now fully dynamic |
| Nav sidebar off-screen at small scales | Same root cause as above |
| Tab switching caused full widget rebuild | `mouseScrolled` called `clearAndInit()` — now calls lightweight `rebuildContentOnly()` |
| Option text missing / blurred | Emoji chars rendered as squares — replaced with plain ASCII |
| `debugEnabled` field missing | Renamed to `getDebugHud().shouldShowDebugHud()` in Yarn 1.21.1 |
| `getEntityCount()` missing on ClientWorld | Replaced with entity iteration loop |

---

## Mod Compatibility

| Mod | Status |
|-----|--------|
| Sodium | ✅ Auto-detected |
| Iris Shaders | ✅ Auto-budgeted |
| ModMenu | ✅ Config screen visible |
| Cloth Config | ✅ Optional |
| Lithium | ✅ Compatible |
| FerriteCore | ✅ Compatible |
| EntityCulling | ✅ Compatible |
| Distant Horizons | ✅ Detected, render distance adjusted |
| Optifine | ❌ Not compatible |
| Forge mods | ❌ Not compatible |

---

## Building from Source

**Requirements:** Java 21

```bash
git clone https://github.com/realitymod/reality-gauntlet
cd reality-gauntlet

# Windows
gradlew.bat build

# Mac / Linux
./gradlew build
```

Output: `build/libs/reality-gauntlet-1.0.0.jar`

To test in Minecraft directly: run the Gradle task `Tasks → fabric → runClient`.

---

## Project Structure

```
src/main/java/com/realitymod/
├── RealityGauntlet.java            # Common entrypoint
├── RealityGauntletClient.java      # Client entrypoint
├── config/
│   ├── GauntletConfig.java         # All settings
│   └── ConfigManager.java          # JSON read/write + presets
├── modules/
│   ├── ChronoCrystal.java          # Render distance control
│   ├── VoidCrystal.java            # Entity AI throttling
│   ├── CoreCrystal.java            # Memory cleanup
│   ├── AetherCrystal.java          # Redstone + particle throttle
│   ├── FluxCrystal.java            # Mode switching + auto-tune
│   ├── PrismaCrystal.java          # HUD overlay
│   ├── EchoCrystal.java            # Debug tools + dream mode
│   └── DynamicFpsModule.java       # Unfocused FPS + volume
├── mixin/                          # Minecraft hooks (all require=0)
├── autotune/                       # SystemDetector + AutoTuner
├── shader/                         # Sodium/Iris detection
└── gui/
    ├── GauntletConfigScreen.java   # In-game settings screen
    └── GauntletModMenuIntegration.java
```

---

## License

MIT — free to use, modify, and redistribute.

---

*"Reality can be whatever I want." — and I want 144 FPS.*
