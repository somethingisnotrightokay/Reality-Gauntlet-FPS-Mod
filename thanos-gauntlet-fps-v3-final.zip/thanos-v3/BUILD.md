# Building Thanos Gauntlet FPS

## Requirements
- Java 21 JDK (already installed if you're playing Minecraft 1.21.1)
- Internet connection (to download Gradle and Minecraft mappings on first build)

## One-Command Build

```bash
cd thanos-fixed
chmod +x gradlew
./gradlew build
```

The compiled `.jar` will be at:
```
build/libs/thanos-gauntlet-fps-1.0.0.jar
```

Copy that file to your `.minecraft/mods/` folder.

## If you get a Java version error

Make sure JAVA_HOME points to Java 21:
```bash
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
./gradlew build
```

## Troubleshooting

**"Could not resolve minecraft"** → Need internet on first build to download MC artifacts.

**"Mixin apply error"** → A Minecraft method was renamed. The mixin has `require=0` 
so it logs a warning and skips (won't crash). Open an issue with your MC/Fabric version.

**"Cannot find symbol: ThanosGauntletFPSClient"** → Make sure you're on Java 21, not Java 17.

## Installed Alongside
Recommended companion mods (install separately):
- **Sodium** — GPU renderer optimization
- **Iris** — Shader support (our shader presets auto-activate)
- **Lithium** — Server-side optimizations
- **FerriteCore** — Block state memory reduction
- **Distant Horizons** — LOD rendering (auto-configured by our DH compat system)
