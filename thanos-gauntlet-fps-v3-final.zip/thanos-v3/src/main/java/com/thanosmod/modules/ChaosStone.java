package com.thanosmod.modules;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.config.ThanosConfig;
import net.minecraft.client.MinecraftClient;

/**
 * ═══════════════════════════════════════════════════════════
 *  ⬡ Chaos Stone — Extra Features & Debug
 *
 *  Features:
 *  1. Debug overlay (entity count, FPS graph, memory).
 *     Rendered by SoulStone when debugMode flag is true.
 *  2. Dream Mode — all particle spawning suppressed,
 *     TimeStone.shouldSpawnParticle() returns false.
 *  3. Verbose logging — enables LOGGER.debug() calls across
 *     all stone modules.
 *  4. Tick-based feature polling (for future extensions).
 * ═══════════════════════════════════════════════════════════
 */
public class ChaosStone {

    private ThanosConfig config;

    /** Simple FPS history for an on-screen graph. */
    private final int[]  fpsHistory   = new int[60];
    private       int    historyIndex = 0;
    private       int    sampleTick   = 0;

    // ── Lifecycle ─────────────────────────────────────────────────────────

    public void init(ThanosConfig config) {
        this.config = config;
        ThanosGauntletFPS.LOGGER.info("[Chaos Stone] Init — debug={} dream={} verbose={}",
            config.debugMode, config.dreamMode, config.verboseLogging);
    }

    // ── Per-tick (called from ThanosGauntletFPSClient) ────────────────────

    public void tick(MinecraftClient client) {
        if (!config.debugMode) return;

        // Sample FPS every tick into the rolling graph array
        if (++sampleTick % 3 == 0) {   // sample every 3 ticks for smoothness
            fpsHistory[historyIndex] = client.getCurrentFps();
            historyIndex = (historyIndex + 1) % fpsHistory.length;
        }
    }

    // ── Flag accessors (used by other stones) ─────────────────────────────

    public boolean isDreamMode()      { return config.dreamMode;       }
    public boolean isDebugMode()      { return config.debugMode;       }
    public boolean isVerboseLogging() { return config.verboseLogging;  }

    /**
     * Return the rolling FPS history array for graph rendering.
     * Index 0 is the oldest sample; {@link #historyIndex} - 1 is newest.
     */
    public int[] getFpsHistory()   { return fpsHistory;   }
    public int   getHistoryIndex() { return historyIndex; }

    // ── Config reload ─────────────────────────────────────────────────────

    public void reloadConfig(ThanosConfig newConfig) {
        this.config = newConfig;
    }
}
