package com.thanosmod.modules;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.config.ThanosConfig;
import net.minecraft.client.MinecraftClient;

/**
 * ═══════════════════════════════════════════════════════════
 *  ⬡ Reality Stone — Chunk & Render Optimisation
 *
 *  Responsibilities:
 *  • Apply render distance from config to Minecraft options.
 *  • Apply simulation distance from config.
 *  • Toggle enhanced chunk loading (pre-queues neighbour chunks).
 *  • Async lighting is handled in the ServerChunkManagerMixin;
 *    this module just gates the flag.
 *
 *  The actual per-frame chunk render loop is intercepted in
 *  WorldRendererMixin.  This class is the coordinator.
 * ═══════════════════════════════════════════════════════════
 */
public class RealityStone {

    private ThanosConfig config;
    private boolean initialised = false;

    // Track last-applied values so we NEVER call setValue unless something changed.
    // Calling options.getViewDistance().setValue() every tick triggers a full
    // chunk reload in 1.21.1, causing the infinite chunk-reload loop.
    private int lastAppliedRender = -1;
    private int lastAppliedSim    = -1;

    // ── Lifecycle ─────────────────────────────────────────────────────────

    public void init(ThanosConfig config) {
        this.config = config;
        ThanosGauntletFPS.LOGGER.info("[Reality Stone] Init — renderDist={} simDist={} asyncLight={}",
            config.renderDistance, config.simulationDistance, config.asyncLighting);
    }

    /**
     * Apply settings to the live Minecraft client.
     * Safe to call after the client is fully booted.
     */
    public void apply() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.options == null) return;

        // Only call setValue when the value has actually changed.
        // In 1.21.1, calling getViewDistance().setValue() even with the same
        // value triggers a full chunk reload — doing this every tick was the
        // source of the infinite chunk-reload loop.
        boolean changed = false;

        if (config.renderDistance != lastAppliedRender) {
            client.options.getViewDistance().setValue(config.renderDistance);
            lastAppliedRender = config.renderDistance;
            changed = true;
        }

        if (config.simulationDistance != lastAppliedSim) {
            client.options.getSimulationDistance().setValue(config.simulationDistance);
            lastAppliedSim = config.simulationDistance;
            changed = true;
        }

        if (!initialised || changed) {
            ThanosGauntletFPS.LOGGER.info(
                "[Reality Stone] Applied: render={} sim={} asyncLight={} enhancedChunks={}",
                config.renderDistance, config.simulationDistance,
                config.asyncLighting, config.enhancedChunkLoading
            );
            initialised = true;
        }
    }

    // ── Mixin helpers (called from WorldRendererMixin) ────────────────────

    /**
     * Should async lighting updates be permitted?
     * Queried by ServerChunkManagerMixin.
     */
    public static boolean isAsyncLightingEnabled() {
        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
        return cfg.asyncLighting;
    }

    /**
     * Should we pre-queue neighbour chunks when a chunk loads?
     * Queried by the chunk scheduler mixin.
     */
    public static boolean isEnhancedChunkLoadingEnabled() {
        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
        return cfg.enhancedChunkLoading;
    }

    // ── Config hot-reload ─────────────────────────────────────────────────

    public void reloadConfig(ThanosConfig newConfig) {
        this.config = newConfig;
        this.initialised = false;
        // Reset cache so changed values are detected and applied on next apply() call
        this.lastAppliedRender = -1;
        this.lastAppliedSim    = -1;
        apply();
    }
}
