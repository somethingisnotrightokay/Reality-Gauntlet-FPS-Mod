package com.thanosmod.modules;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.config.ThanosConfig;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Space Stone — World / Memory Management
 */
public class SpaceStone {

    private ThanosConfig config;
    private ScheduledExecutorService scheduler;

    public void init(ThanosConfig config) {
        this.config = config;
        ThanosGauntletFPS.LOGGER.info(
            "[Space Stone] Init — lazyTE={} asyncBlocks={} cleanupInterval={}s",
            config.lazyTileEntities, config.asyncBlockUpdates, config.memoryCleanupInterval
        );
        startMemoryCleanup();
    }

    private void startMemoryCleanup() {
        stopMemoryCleanup();
        int interval = config.memoryCleanupInterval;
        if (interval <= 0) return;

        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "Thanos-SpaceStone-GC");
            t.setDaemon(true);
            return t;
        });

        scheduler.scheduleAtFixedRate(() -> {
            try {
                performMemoryCleanup();
            } catch (Exception e) {
                ThanosGauntletFPS.LOGGER.warn("[Space Stone] Cleanup error: {}", e.getMessage());
            }
        }, interval, interval, TimeUnit.SECONDS);

        ThanosGauntletFPS.LOGGER.info("[Space Stone] Memory cleanup scheduled every {}s.", interval);
    }

    private void stopMemoryCleanup() {
        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.shutdownNow();
        }
    }

    public void performMemoryCleanup() {
        long before = usedMemoryMB();
        System.gc();
        long after  = usedMemoryMB();
        long freed  = before - after;

        if (config.verboseLogging || freed > 50) {
            ThanosGauntletFPS.LOGGER.info(
                "[Space Stone] GC hint fired — freed ~{} MB ({}→{} MB used).",
                freed, before, after
            );
        }
    }

    private long usedMemoryMB() {
        Runtime rt = Runtime.getRuntime();
        return (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
    }

    public static boolean isLazyTileEntities() {
        return ThanosGauntletFPS.getConfigManager().getConfig().lazyTileEntities;
    }

    public static boolean isAsyncBlockUpdates() {
        return ThanosGauntletFPS.getConfigManager().getConfig().asyncBlockUpdates;
    }

    public void reloadConfig(ThanosConfig newConfig) {
        this.config = newConfig;
        startMemoryCleanup();
    }

    public void shutdown() {
        stopMemoryCleanup();
    }
}
