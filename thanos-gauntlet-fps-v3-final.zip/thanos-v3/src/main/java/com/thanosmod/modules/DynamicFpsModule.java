package com.thanosmod.modules;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.config.ThanosConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundCategory;

/**
 * ═══════════════════════════════════════════════════════════
 *  DynamicFpsModule — Inspired by the Dynamic FPS mod
 *
 *  What this does:
 *  1. Detects window focus/minimize state each client tick.
 *  2. When the window LOSES focus: records the saved master
 *     volume and lowers it to cfg.unfocusedVolumePct.
 *  3. When the window REGAINS focus: restores saved volume.
 *  4. FPS capping when unfocused is implemented in the mixin
 *     (DynamicFpsMixin) since it needs to run per-frame.
 *  5. "Pause when minimized" collapses unfocusedFpsCap to 1.
 *
 *  Volume notes: we only touch the MASTER channel to avoid
 *  interfering with per-category settings the user may have
 *  configured. We save/restore rather than multiply in-place
 *  to survive config reloads cleanly.
 * ═══════════════════════════════════════════════════════════
 */
@Environment(EnvType.CLIENT)
public class DynamicFpsModule {

    private boolean lastFocused   = true;
    private boolean lastMinimized = false;
    private double  savedVolume   = 1.0;
    private boolean volumeLowered = false;

    // ── Lifecycle ──────────────────────────────────────────────────────────

    public void tick(MinecraftClient client) {
        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
        if (!cfg.dynamicFpsEnabled) {
            // Ensure volume is restored if we toggled the feature off
            if (volumeLowered) restoreVolume(client);
            return;
        }

        boolean focused   = client.isWindowFocused();
        // Use GLFW iconified state for "minimized" - safe across all MC 1.21.x versions
        boolean minimized = !focused && (org.lwjgl.glfw.GLFW.glfwGetWindowAttrib(
            client.getWindow().getHandle(), org.lwjgl.glfw.GLFW.GLFW_ICONIFIED) != 0);

        // ── Volume management ──────────────────────────────────────────────
        if (cfg.reduceVolumeWhenUnfocused) {
            if (focused && !lastFocused) {
                // Regained focus — restore volume
                restoreVolume(client);
            } else if (!focused && lastFocused) {
                // Lost focus — lower volume
                lowerVolume(client, cfg);
            }
        }

        // ── Log focus transitions ──────────────────────────────────────────
        if (focused != lastFocused) {
            ThanosGauntletFPS.LOGGER.debug(
                "[DynamicFPS] Window focus: {} → {}  (FPS cap when unfocused: {})",
                lastFocused ? "focused" : "unfocused",
                focused     ? "focused" : "unfocused",
                cfg.unfocusedFpsCap
            );
        }

        lastFocused   = focused;
        lastMinimized = minimized;
    }

    /** Called when the mod config is hot-reloaded. */
    public void onConfigReloaded(MinecraftClient client) {
        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
        // If volume was lowered but the feature was just turned off, restore.
        if (volumeLowered && !cfg.reduceVolumeWhenUnfocused) {
            restoreVolume(client);
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private void lowerVolume(MinecraftClient client, ThanosConfig cfg) {
        try {
            var masterOption = client.options.getSoundVolumeOption(SoundCategory.MASTER);
            savedVolume = masterOption.getValue();
            double target = savedVolume * (cfg.unfocusedVolumePct / 100.0);
            masterOption.setValue(target);
            volumeLowered = true;
            ThanosGauntletFPS.LOGGER.debug(
                "[DynamicFPS] Volume lowered: {} → {}", String.format("%.2f", savedVolume), String.format("%.2f", target)
            );
        } catch (Exception e) {
            ThanosGauntletFPS.LOGGER.warn("[DynamicFPS] Could not lower volume: {}", e.getMessage());
        }
    }

    private void restoreVolume(MinecraftClient client) {
        if (!volumeLowered) return;
        try {
            client.options.getSoundVolumeOption(SoundCategory.MASTER).setValue(savedVolume);
            volumeLowered = false;
            ThanosGauntletFPS.LOGGER.debug("[DynamicFPS] Volume restored to {}", String.format("%.2f", savedVolume));
        } catch (Exception e) {
            ThanosGauntletFPS.LOGGER.warn("[DynamicFPS] Could not restore volume: {}", e.getMessage());
        }
    }

    // ── Accessors used by the mixin ────────────────────────────────────────

    /** True if the game window is minimized (no render needed). */
    public boolean isMinimized() { return lastMinimized; }

    /** True if the window currently lacks focus. */
    public boolean isUnfocused() { return !lastFocused; }
}
