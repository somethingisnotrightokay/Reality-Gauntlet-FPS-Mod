package com.thanosmod.shader;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.config.ThanosConfig;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * ═══════════════════════════════════════════════════════════
 *  ShaderPresetManager — Per-Pack Iris Performance Profiles
 *
 *  Maps active Iris shader pack names to tuned presets that
 *  adjust render distance, particle density, entity distances,
 *  and redstone culling based on each shader's real-world cost.
 *
 *  Supported packs (partial name match, case-insensitive):
 *  ┌ Extreme tier ─ SEUS PTGI HRR, Rethinking Voxels
 *  ├ Heavy tier   ─ SEUS Renewed, Kappa, Comp. Reimagined
 *  ├ Medium-Heavy ─ Comp. Unbound, BSL, AstraLex
 *  ├ Medium       ─ Sildur's Vibrant High/Med, Chocapic Ultra/High
 *  ├ Light        ─ Sildur's Vibrant Lite, Chocapic Medium/Low,
 *  │                Vanilla Plus, Super Duper Vanilla
 *  └ Performance  ─ MakeUp Ultra Fast, Potato Shaders, Lumi
 *
 *  Each preset also carries per-shader optimisation tips that
 *  the SoulStone HUD can display when that shader is active.
 * ═══════════════════════════════════════════════════════════
 */
public class ShaderPresetManager {

    // ── Tier enum ─────────────────────────────────────────────────────────

    public enum ShaderTier {
        /** Software ray-tracing or voxel GI. Needs minimum settings. */
        EXTREME,
        /** Full PBR + heavy post-processing (reflections, DOF, SSAO). */
        HEAVY,
        /** Feature-rich but contains perf options to dial in. */
        MEDIUM_HEAVY,
        /** Balanced quality/cost. Most mid-range GPUs handle this. */
        MEDIUM,
        /** Lightweight — mostly just colour grading + basic shadows. */
        LIGHT,
        /** Performance-first. Overhead is minimal. */
        PERFORMANCE,
        /** Unknown pack — apply a conservative budget. */
        UNKNOWN
    }

    // ── Preset record ──────────────────────────────────────────────────────

    public record ShaderPreset(
        String     displayName,
        ShaderTier tier,
        int        renderDistance,
        int        simulationDistance,
        int        entityTickDistance,
        int        entityCap,
        int        particleDensity,
        boolean    skipDistantRedstone,
        int        redstoneCutoff,
        boolean    entityCulling,
        String     inShaderTips   // advice shown in HUD / logs
    ) {}

    // ═════════════════════════════════════════════════════════════════════
    //  PRESET DEFINITIONS
    // ═════════════════════════════════════════════════════════════════════

    // ─── EXTREME tier ─────────────────────────────────────────────────────

    private static final ShaderPreset P_SEUS_PTGI = new ShaderPreset(
        "SEUS PTGI HRR", ShaderTier.EXTREME,
        /*render*/5, /*sim*/4, /*entityDist*/12, /*entityCap*/40,
        /*particles*/8, /*skipRedstone*/true, /*redstoneCutoff*/12,
        /*entityCulling*/true,
        "In SEUS PTGI: set Temporal Accumulation to 4–6, disable Volumetric Clouds. " +
        "Use JITTER_AMOUNT=0.5 for less blur."
    );

    private static final ShaderPreset P_RETHINKING_VOXELS = new ShaderPreset(
        "Rethinking Voxels", ShaderTier.EXTREME,
        5, 4, 12, 50,
        8, true, 12,
        true,
        "In Rethinking Voxels: lower 'Voxel Volume' setting to 48 or 64. " +
        "Disable 'Reflections' on glass if FPS is below 30."
    );

    // ─── HEAVY tier ───────────────────────────────────────────────────────

    private static final ShaderPreset P_SEUS_RENEWED = new ShaderPreset(
        "SEUS Renewed", ShaderTier.HEAVY,
        7, 5, 16, 70,
        20, true, 24,
        true,
        "In SEUS Renewed: reduce Shadow Distance to 80–100, disable PCSS for +15% FPS."
    );

    private static final ShaderPreset P_KAPPA = new ShaderPreset(
        "Kappa Shaders", ShaderTier.HEAVY,
        7, 5, 18, 80,
        22, true, 28,
        true,
        "In Kappa: enable TAA (looks better at lower render dist). " +
        "Set Shadow Resolution to 1024 for a significant perf boost."
    );

    private static final ShaderPreset P_COMP_REIMAGINED = new ShaderPreset(
        "Complementary Reimagined", ShaderTier.HEAVY,
        8, 6, 20, 90,
        30, true, 32,
        true,
        "In Complementary Reimagined: set Shadow Distance to 100–120. " +
        "Disable 'Water Waves' if underwater FPS is low. Enable 'Vanilla-Like Profile' for best balance."
    );

    // ─── MEDIUM-HEAVY tier ────────────────────────────────────────────────

    private static final ShaderPreset P_COMP_UNBOUND = new ShaderPreset(
        "Complementary Unbound", ShaderTier.MEDIUM_HEAVY,
        10, 7, 24, 130,
        45, true, 40,
        true,
        "In Comp. Unbound: Profile → 'Balanced'. Shadow Distance 120–140. " +
        "Disable 'Advanced Materials' if GPU is below RTX 2060 level."
    );

    private static final ShaderPreset P_BSL = new ShaderPreset(
        "BSL Shaders", ShaderTier.MEDIUM_HEAVY,
        10, 7, 24, 130,
        50, true, 40,
        true,
        "In BSL: disable 'Old Lighting' (it's slower). Shadow Distance 100. " +
        "Set Bloom Quality to Low if you use bloom."
    );

    private static final ShaderPreset P_ASTRALEX = new ShaderPreset(
        "AstraLex Shaders", ShaderTier.MEDIUM_HEAVY,
        10, 7, 24, 130,
        50, true, 40,
        true,
        "BSL-based. Same tuning applies: disable Old Lighting, Shadow Distance 100."
    );

    private static final ShaderPreset P_SUPER_DUPER_VANILLA = new ShaderPreset(
        "Super Duper Vanilla", ShaderTier.MEDIUM_HEAVY,
        11, 8, 28, 150,
        55, true, 44,
        true,
        "Enable 'Fast Mode' in shader options. Reduce shadow resolution to 1024."
    );

    // ─── MEDIUM tier ──────────────────────────────────────────────────────

    private static final ShaderPreset P_SILDURS_HIGH = new ShaderPreset(
        "Sildur's Vibrant High", ShaderTier.MEDIUM,
        12, 8, 28, 180,
        65, true, 48,
        false,
        "In Sildur's: disable SSAO for +8–10%. Shadow Distance 120. " +
        "Use 'Vibrant High' for best balance of looks and performance."
    );

    private static final ShaderPreset P_SILDURS_MEDIUM = new ShaderPreset(
        "Sildur's Vibrant Medium", ShaderTier.MEDIUM,
        13, 9, 32, 200,
        70, true, 48,
        false,
        "Good all-rounder. Disable Motion Blur if you find it distracting."
    );

    private static final ShaderPreset P_CHOCAPIC_ULTRA_HIGH = new ShaderPreset(
        "Chocapic13 Ultra/High", ShaderTier.MEDIUM,
        10, 7, 24, 140,
        50, true, 40,
        true,
        "In Chocapic: disable 'Godrays' for a large FPS boost. " +
        "Shadow Distance 100 is a good target."
    );

    private static final ShaderPreset P_CHOCAPIC_TOASTER = new ShaderPreset(
        "Chocapic13 Toaster/Low", ShaderTier.LIGHT,
        14, 10, 40, 280,
        80, false, 64,
        false,
        "Lightweight Chocapic variant. Almost no overhead."
    );

    // ─── LIGHT tier ───────────────────────────────────────────────────────

    private static final ShaderPreset P_SILDURS_LITE = new ShaderPreset(
        "Sildur's Vibrant Lite", ShaderTier.LIGHT,
        14, 10, 40, 280,
        82, false, 64,
        false,
        "Very lightweight. Safe on integrated graphics."
    );

    private static final ShaderPreset P_VANILLA_PLUS = new ShaderPreset(
        "Vanilla Plus", ShaderTier.LIGHT,
        14, 10, 44, 300,
        88, false, 64,
        false,
        "Subtle enhancement. Minimal performance cost."
    );

    private static final ShaderPreset P_LUMI = new ShaderPreset(
        "Lumi Lights", ShaderTier.LIGHT,
        13, 9, 40, 260,
        80, false, 60,
        false,
        "Canvas-based block light improvements. Minimal GPU overhead."
    );

    // ─── PERFORMANCE tier ─────────────────────────────────────────────────

    private static final ShaderPreset P_MAKEUP = new ShaderPreset(
        "MakeUp Ultra Fast", ShaderTier.PERFORMANCE,
        16, 12, 56, 450,
        100, false, 128,
        false,
        "Performance shader — near-zero overhead. No in-shader adjustments needed."
    );

    private static final ShaderPreset P_POTATO = new ShaderPreset(
        "Potato Shaders", ShaderTier.PERFORMANCE,
        16, 12, 56, 450,
        100, false, 128,
        false,
        "Minimal visual shader for very low-end hardware."
    );

    private static final ShaderPreset P_NOSTALGIA_VX = new ShaderPreset(
        "Nostalgia/NostalgiaVX", ShaderTier.HEAVY,
        8, 6, 20, 90,
        30, true, 32,
        true,
        "In Nostalgia: enable 'Low' profile. Disable 'Waving Leaves' for +5%."
    );

    /**
     * Conservative budget for packs we don't recognise.
     * Better to be slightly too conservative than to tank FPS.
     */
    private static final ShaderPreset P_UNKNOWN = new ShaderPreset(
        "Unknown Shader Pack", ShaderTier.UNKNOWN,
        8, 6, 20, 100,
        35, true, 32,
        true,
        "Unknown shader detected — applying conservative budget. " +
        "Check your shader's options for a 'Performance' or 'Low' profile."
    );

    // ═════════════════════════════════════════════════════════════════════
    //  PATTERN → PRESET MAP  (evaluated in order — put more-specific first)
    // ═════════════════════════════════════════════════════════════════════

    /**
     * Pattern map: key = substring to match (lowercased), value = preset.
     * Evaluation order matters — more-specific patterns are checked first.
     */
    private static final LinkedHashMap<String, ShaderPreset> PATTERN_MAP;
    static {
        PATTERN_MAP = new LinkedHashMap<>();

        // ─── Extreme ──────────────────────────────────────────────────────
        PATTERN_MAP.put("ptgi",                  P_SEUS_PTGI);
        PATTERN_MAP.put("rethinkingvoxels",       P_RETHINKING_VOXELS);
        PATTERN_MAP.put("rethinking_voxels",      P_RETHINKING_VOXELS);
        PATTERN_MAP.put("rethinking voxels",      P_RETHINKING_VOXELS);

        // ─── Heavy ────────────────────────────────────────────────────────
        PATTERN_MAP.put("seus_renewed",           P_SEUS_RENEWED);
        PATTERN_MAP.put("seusrenewed",            P_SEUS_RENEWED);
        PATTERN_MAP.put("seus renewed",           P_SEUS_RENEWED);
        PATTERN_MAP.put("kappa",                  P_KAPPA);
        PATTERN_MAP.put("reimagined",             P_COMP_REIMAGINED);
        PATTERN_MAP.put("nostalgiavx",            P_NOSTALGIA_VX);
        PATTERN_MAP.put("nostalgia_vx",           P_NOSTALGIA_VX);

        // ─── Medium-Heavy ─────────────────────────────────────────────────
        PATTERN_MAP.put("unbound",                P_COMP_UNBOUND);
        PATTERN_MAP.put("astralex",               P_ASTRALEX);
        PATTERN_MAP.put("astra_lex",              P_ASTRALEX);
        PATTERN_MAP.put("bsl",                    P_BSL);
        PATTERN_MAP.put("super duper vanilla",    P_SUPER_DUPER_VANILLA);
        PATTERN_MAP.put("superduper",             P_SUPER_DUPER_VANILLA);

        // ─── Sildur's (specific variants before general) ──────────────────
        PATTERN_MAP.put("sildurs_vibrant_lite",   P_SILDURS_LITE);
        PATTERN_MAP.put("sildur's vibrant lite",  P_SILDURS_LITE);
        PATTERN_MAP.put("sildur lite",            P_SILDURS_LITE);
        PATTERN_MAP.put("sildurs_vibrant_high",   P_SILDURS_HIGH);
        PATTERN_MAP.put("sildurs_vibrant_extreme",P_SILDURS_HIGH);
        PATTERN_MAP.put("sildur's vibrant high",  P_SILDURS_HIGH);
        PATTERN_MAP.put("sildur high",            P_SILDURS_HIGH);
        PATTERN_MAP.put("sildur extreme",         P_SILDURS_HIGH);
        PATTERN_MAP.put("sildur",                 P_SILDURS_MEDIUM); // generic fallback

        // ─── Chocapic (specific before generic) ───────────────────────────
        PATTERN_MAP.put("chocapic13_toaster",     P_CHOCAPIC_TOASTER);
        PATTERN_MAP.put("chocapic_toaster",       P_CHOCAPIC_TOASTER);
        PATTERN_MAP.put("chocapic_low",           P_CHOCAPIC_TOASTER);
        PATTERN_MAP.put("chocapic_medium",        P_CHOCAPIC_TOASTER);
        PATTERN_MAP.put("chocapic",               P_CHOCAPIC_ULTRA_HIGH); // generic = assume high

        // ─── Light ────────────────────────────────────────────────────────
        PATTERN_MAP.put("vanillaplus",            P_VANILLA_PLUS);
        PATTERN_MAP.put("vanilla_plus",           P_VANILLA_PLUS);
        PATTERN_MAP.put("vanilla plus",           P_VANILLA_PLUS);
        PATTERN_MAP.put("nostalgia",              P_VANILLA_PLUS); // non-VX Nostalgia
        PATTERN_MAP.put("lumi",                   P_LUMI);

        // ─── Performance ──────────────────────────────────────────────────
        PATTERN_MAP.put("makeup",                 P_MAKEUP);
        PATTERN_MAP.put("make_up",                P_MAKEUP);
        PATTERN_MAP.put("make up",                P_MAKEUP);
        PATTERN_MAP.put("potato",                 P_POTATO);

        // ─── Complementary generic (after reimagined/unbound checks) ──────
        PATTERN_MAP.put("complementary",          P_COMP_UNBOUND); // fallback
        PATTERN_MAP.put("seus",                   P_SEUS_RENEWED); // generic SEUS fallback
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Runtime state
    // ─────────────────────────────────────────────────────────────────────

    private final ShaderDetector detector;
    private ShaderPreset activePreset   = null;
    private String       activePackName = "";

    public ShaderPresetManager(ShaderDetector detector) {
        this.detector = detector;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Public API
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Query the active shader pack name (via ShaderDetector), match it
     * against the preset table, and return the matched preset.
     *
     * Returns null if Iris is not present or no shader is active.
     */
    public ShaderPreset refreshAndGetPreset() {
        if (!detector.isIrisPresent() || !detector.isShadersEnabled()) {
            activePreset   = null;
            activePackName = "";
            return null;
        }

        activePackName = detector.getActiveShaderPackName();
        activePreset   = matchPreset(activePackName);

        ThanosGauntletFPS.LOGGER.info(
            "[Thanos:ShaderPresets] Active pack='{}' → preset='{}' (tier: {})",
            activePackName.isBlank() ? "<unknown>" : activePackName,
            activePreset.displayName(),
            activePreset.tier()
        );

        return activePreset;
    }

    /**
     * Write the preset's performance values into cfg.
     * Only call this when shaders are confirmed active.
     *
     * @param cfg    The live ThanosConfig to mutate.
     * @param preset The preset to apply (from refreshAndGetPreset).
     */
    public void applyPresetToConfig(ThanosConfig cfg, ShaderPreset preset) {
        cfg.renderDistance      = preset.renderDistance();
        cfg.simulationDistance  = preset.simulationDistance();
        cfg.entityTickDistance  = preset.entityTickDistance();
        cfg.entityCap           = preset.entityCap();
        cfg.particleDensity     = preset.particleDensity();
        cfg.particleThrottle    = (preset.particleDensity() < 100);
        cfg.skipDistantRedstone = preset.skipDistantRedstone();
        cfg.redstoneCutoffDist  = preset.redstoneCutoff();
        cfg.skipDistantAI       = true;
        cfg.entityCulling       = preset.entityCulling();
        cfg.lastDetectedShaderPack = preset.displayName();

        ThanosGauntletFPS.LOGGER.info(
            "[Thanos:ShaderPresets] Applied '{}': render={}  sim={}  particles={}%  " +
            "entityDist={}  entityCap={}  skipRedstone={}",
            preset.displayName(),
            preset.renderDistance(), preset.simulationDistance(),
            preset.particleDensity(), preset.entityTickDistance(),
            preset.entityCap(), preset.skipDistantRedstone()
        );

        if (!preset.inShaderTips().isBlank()) {
            ThanosGauntletFPS.LOGGER.info(
                "[Thanos:ShaderPresets] In-shader tip → {}",
                preset.inShaderTips()
            );
        }
    }

    /**
     * Log a table of all supported packs to the game log.
     * Useful for users who want to see what's supported.
     */
    public void logSupportedPacks() {
        ThanosGauntletFPS.LOGGER.info(
            "[Thanos:ShaderPresets] Supported packs:\n" +
            "  EXTREME      : SEUS PTGI HRR, Rethinking Voxels\n" +
            "  HEAVY        : SEUS Renewed, Kappa Shaders, Comp. Reimagined, NostalgiaVX\n" +
            "  MEDIUM-HEAVY : Comp. Unbound, BSL Shaders, AstraLex, Super Duper Vanilla\n" +
            "  MEDIUM       : Sildur's High, Chocapic Ultra/High\n" +
            "  LIGHT        : Sildur's Medium/Lite, Chocapic Low, Vanilla Plus, Lumi Lights\n" +
            "  PERFORMANCE  : MakeUp Ultra Fast, Potato Shaders\n" +
            "  (any other pack → conservative UNKNOWN budget)"
        );
    }

    // ─────────────────────────────────────────────────────────────────────
    //  Name matching
    // ─────────────────────────────────────────────────────────────────────

    private ShaderPreset matchPreset(String packName) {
        if (packName == null || packName.isBlank()) return P_UNKNOWN;
        String lower = packName.toLowerCase().replace("-", "_");

        for (Map.Entry<String, ShaderPreset> entry : PATTERN_MAP.entrySet()) {
            if (lower.contains(entry.getKey())) {
                return entry.getValue();
            }
        }
        return P_UNKNOWN;
    }

    // ─────────────────────────────────────────────────────────────────────

    public ShaderPreset getActivePreset()   { return activePreset;   }
    public String       getActivePackName() { return activePackName; }
    public boolean      hasActivePreset()   { return activePreset != null; }
}
