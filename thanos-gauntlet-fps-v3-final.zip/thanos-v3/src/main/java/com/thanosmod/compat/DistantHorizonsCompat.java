package com.thanosmod.compat;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.config.ThanosConfig;
import net.fabricmc.loader.api.FabricLoader;

/**
 * ═══════════════════════════════════════════════════════════
 *  DistantHorizonsCompat — Distant Horizons LOD Integration
 *
 *  Distant Horizons (DH) renders the world beyond the vanilla
 *  render distance as LOD geometry — chunky but fast billboards
 *  that stretch out to 256–2048 chunks.
 *
 *  When DH is active, vanilla only needs to handle the inner
 *  6–8 chunks in full detail.  Leaving vanilla render distance
 *  at 10–16 while DH is running wastes GPU time rendering a
 *  mid-distance band that DH already covers.
 *
 *  What this module does:
 *  1. Detects whether DH is loaded via FabricLoader.
 *  2. On world join, reduces vanilla render distance to
 *     cfg.dhVanillaRenderDist (default 6, user-configurable).
 *  3. On world leave, resets the applied flag so the next
 *     world join triggers the reduction again.
 *  4. Exposes isDhPresent() so other modules (RealityStone,
 *     SoulStone HUD) can branch on DH presence.
 *
 *  No hard compile-time dependency — detection is mod-list
 *  only, with optional reflection for DH API queries.
 * ═══════════════════════════════════════════════════════════
 */
public class DistantHorizonsCompat {

    /** Fabric mod ID registered by Distant Horizons on Modrinth/CurseForge. */
    private static final String DH_MOD_ID = "distanthorizons";

    /**
     * Default vanilla render distance to use when DH is active.
     * 6 chunks matches the innermost LOD ring in DH's default config,
     * avoiding any visible seam between vanilla terrain and LODs.
     */
    private static final int DH_DEFAULT_VANILLA_DIST = 6;

    // ── State ─────────────────────────────────────────────────────────────

    private final boolean dhPresent;
    private final String  dhVersion;

    /**
     * True once the render-distance reduction has been applied for the
     * current world session.  Reset when the player leaves the world.
     */
    private boolean appliedThisSession = false;

    /**
     * The vanilla render distance that was in effect before DH override.
     * Stored so we can log the before/after and potentially restore it.
     */
    private int previousRenderDist = -1;

    // ── Constructor ───────────────────────────────────────────────────────

    public DistantHorizonsCompat() {
        FabricLoader loader = FabricLoader.getInstance();
        dhPresent = loader.isModLoaded(DH_MOD_ID);

        dhVersion = dhPresent
            ? loader.getModContainer(DH_MOD_ID)
                    .map(c -> c.getMetadata().getVersion().getFriendlyString())
                    .orElse("unknown")
            : "";

        if (dhPresent) {
            ThanosGauntletFPS.LOGGER.info(
                "[Thanos:DH] Distant Horizons v{} detected. " +
                "Vanilla render distance will be auto-reduced on world load.",
                dhVersion
            );
        } else {
            ThanosGauntletFPS.LOGGER.debug("[Thanos:DH] Distant Horizons not present.");
        }
    }

    // ── World lifecycle ───────────────────────────────────────────────────

    /**
     * Call when the player joins a world.
     *
     * If DH is present and the compat setting is enabled, this lowers
     * cfg.renderDistance to dhVanillaRenderDist so DH can take over the
     * horizon without vanilla wasting GPU budget on the same range.
     *
     * @param cfg  Live config reference — modified in-place.
     * @return     true if the render distance was actually changed.
     */
    public boolean onWorldLoad(ThanosConfig cfg) {
        if (!dhPresent || !cfg.dhCompatEnabled || appliedThisSession) return false;

        int target = (cfg.dhVanillaRenderDist > 0)
            ? cfg.dhVanillaRenderDist
            : DH_DEFAULT_VANILLA_DIST;

        if (cfg.renderDistance <= target) {
            // Already at or below the DH target — no change needed.
            appliedThisSession = true;
            return false;
        }

        previousRenderDist = cfg.renderDistance;
        cfg.renderDistance = target;
        // Also reduce simulation distance proportionally
        if (cfg.simulationDistance > target) {
            cfg.simulationDistance = Math.max(target - 1, 2);
        }

        appliedThisSession = true;

        ThanosGauntletFPS.LOGGER.info(
            "[Thanos:DH] Vanilla render distance reduced: {} → {} chunks " +
            "(DH v{} handles the horizon beyond that).",
            previousRenderDist, target, dhVersion
        );

        printDhTips(cfg);
        return true;
    }

    /**
     * Call when the player leaves a world (disconnect / return to menu).
     * Resets the applied flag so the next world join triggers the reduction.
     */
    public void onWorldUnload() {
        if (appliedThisSession) {
            ThanosGauntletFPS.LOGGER.debug("[Thanos:DH] World unload — DH compat flag reset.");
        }
        appliedThisSession = false;
        previousRenderDist = -1;
    }

    // ── DH API query (reflection, no compile dependency) ──────────────────

    /**
     * Attempt to query whether DH's LOD rendering is actually running.
     * Returns true if DH is loaded (we assume it's active unless the API
     * says otherwise, to be conservative).
     */
    public boolean isDhRenderingActive() {
        if (!dhPresent) return false;
        try {
            // DH 2.x API entry point
            Class.forName("com.seibel.distanthorizons.api.DhApi");
            return true; // class loaded → DH is functional
        } catch (ClassNotFoundException e) {
            // DH 1.x or different package — still present
            return true;
        } catch (Exception e) {
            return true; // assume active if present
        }
    }

    // ── Accessors ─────────────────────────────────────────────────────────

    /** True if Distant Horizons is in the active mod list. */
    public boolean isDhPresent() { return dhPresent; }

    /** DH mod version string, or empty if not present. */
    public String getDhVersion() { return dhVersion; }

    /** True if the render-distance reduction has been applied this session. */
    public boolean isAppliedThisSession() { return appliedThisSession; }

    // ── Helpers ───────────────────────────────────────────────────────────

    private void printDhTips(ThanosConfig cfg) {
        ThanosGauntletFPS.LOGGER.info(
            "[Thanos:DH] Tips for best DH performance:\n" +
            "  • In DH settings: set 'Quality' preset to 'Balanced' or 'Performance'\n" +
            "  • Set DH's 'Chunk Render Distance' to match your desired horizon (128+ chunks)\n" +
            "  • Enable 'Distance Fade' in DH to smooth the LOD transition\n" +
            "  • With shaders: use a DH-compatible shader (Complementary, BSL, etc.)\n" +
            "  • Vanilla render dist={} configured for seamless DH handoff.",
            cfg.renderDistance
        );
    }
}
