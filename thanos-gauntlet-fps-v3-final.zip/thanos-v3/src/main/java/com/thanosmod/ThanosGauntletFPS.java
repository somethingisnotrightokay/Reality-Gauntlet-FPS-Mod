package com.thanosmod;

import com.thanosmod.config.ConfigManager;
import com.thanosmod.modules.PowerStone;
import com.thanosmod.modules.SpaceStone;
import com.thanosmod.modules.TimeStone;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ═══════════════════════════════════════════════════════════
 *  Thanos Gauntlet FPS v3 — Common Entrypoint
 *  Runs on both client and server (shared logic only).
 *  Client-only rendering/shader logic lives in ThanosGauntletFPSClient.
 * ═══════════════════════════════════════════════════════════
 */
public class ThanosGauntletFPS implements ModInitializer {

    public static final String MOD_ID = "thanos-gauntlet-fps";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static ThanosGauntletFPS instance;

    private final ConfigManager configManager = new ConfigManager();
    private final PowerStone    powerStone    = new PowerStone();
    private final SpaceStone    spaceStone    = new SpaceStone();
    private final TimeStone     timeStone     = new TimeStone();

    @Override
    public void onInitialize() {
        instance = this;
        LOGGER.info("╔══════════════════════════════════════════════╗");
        LOGGER.info("║   Thanos Gauntlet FPS v3 — Initializing      ║");
        LOGGER.info("║   Six Stones. One Snap. Infinite FPS.        ║");
        LOGGER.info("║   v3: 13 bugs fixed. 100% stability target.  ║");
        LOGGER.info("╚══════════════════════════════════════════════╝");

        configManager.load();
        powerStone.init(configManager.getConfig());
        spaceStone.init(configManager.getConfig());
        timeStone.init(configManager.getConfig());

        LOGGER.info("[Thanos v3] Common modules online. Awaiting client boot...");
    }

    public static ThanosGauntletFPS getInstance()      { return instance;                }
    public static ConfigManager      getConfigManager() { return instance.configManager;  }
    public static PowerStone         getPowerStone()    { return instance.powerStone;     }
    public static SpaceStone         getSpaceStone()    { return instance.spaceStone;     }
    public static TimeStone          getTimeStone()     { return instance.timeStone;      }
}
