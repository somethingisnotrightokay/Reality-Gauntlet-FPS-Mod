package com.thanosmod.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.thanosmod.ThanosGauntletFPS;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

/**
 * ConfigManager — Reads/writes ThanosConfig to/from JSON.
 * Includes a dirty-flag save debounce: the AutoTuner calls save()
 * frequently, but we only write to disk at most once per 5 s.
 */
public class ConfigManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final long SAVE_DEBOUNCE_MS = 5_000L;

    private final Path configPath;
    private ThanosConfig config = new ThanosConfig();

    private boolean dirty = false;
    private long lastSaveTime = 0L;

    public ConfigManager() {
        this.configPath = FabricLoader.getInstance()
                .getConfigDir()
                .resolve("thanos-gauntlet-fps.json");
    }

    // ── Public API ────────────────────────────────────────────────────────

    public void load() {
        File file = configPath.toFile();
        if (!file.exists()) {
            ThanosGauntletFPS.LOGGER.info("[Thanos] No config found — writing defaults.");
            forceSave();
            return;
        }
        try (Reader reader = new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8)) {
            ThanosConfig loaded = GSON.fromJson(reader, ThanosConfig.class);
            if (loaded != null) {
                config = loaded;
                ThanosGauntletFPS.LOGGER.info("[Thanos] Config loaded.");
            }
        } catch (IOException e) {
            ThanosGauntletFPS.LOGGER.error("[Thanos] Failed to read config: {}", e.getMessage());
        }
    }

    /**
     * Mark config as dirty. Actual disk write is debounced by SAVE_DEBOUNCE_MS.
     * Call forceSave() for an immediate write (e.g. on screen close).
     */
    public void save() {
        dirty = true;
        long now = System.currentTimeMillis();
        if (now - lastSaveTime >= SAVE_DEBOUNCE_MS) {
            forceSave();
        }
    }

    /** Write to disk immediately regardless of debounce. */
    public void forceSave() {
        try {
            File file = configPath.toFile();
            //noinspection ResultOfMethodCallIgnored
            file.getParentFile().mkdirs();
            try (Writer writer = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
                GSON.toJson(config, writer);
            }
            dirty = false;
            lastSaveTime = System.currentTimeMillis();
            ThanosGauntletFPS.LOGGER.debug("[Thanos] Config saved to disk.");
        } catch (IOException e) {
            ThanosGauntletFPS.LOGGER.error("[Thanos] Failed to save config: {}", e.getMessage());
        }
    }

    public void applyPreset(String mode) {
        switch (mode.toLowerCase()) {

            case "low_end" -> {
                config.performanceMode       = "low_end";
                config.renderDistance        = 6;
                config.simulationDistance    = 5;
                config.entityTickDistance    = 16;
                config.entityCap             = 100;
                config.skipDistantAI         = true;
                config.redstoneCutoffDist    = 24;
                config.skipDistantRedstone   = true;
                config.particleDensity       = 30;
                config.particleThrottle      = true;
                config.asyncLighting         = true;
                config.lazyTileEntities      = true;
                config.dreamMode             = false;
                config.targetFPS             = 60;
                config.entityCulling         = true;
                config.blockEntityCulling    = true;
                config.blockEntityCullDist   = 32;
                config.stutterFixEnabled      = true;
                config.renderThreadBoost      = true;
                config.limitChunkGenThreads   = true;
                config.maxChunkGenThreads     = 0;
                config.smoothBootEnabled      = true;
                config.fastMathEnabled        = true;
                config.gpuLeakFixEnabled      = true;
                config.avoidRedundantFbSwitch = true;
                config.leafCulling            = true;
                config.blockStateDeduplication = true;
                config.enableMemoryLeakFixes  = true;
                config.dynamicFpsEnabled     = true;
                config.unfocusedFpsCap       = 10;
            }

            case "balanced" -> {
                config.performanceMode       = "balanced";
                config.renderDistance        = 10;
                config.simulationDistance    = 8;
                config.entityTickDistance    = 32;
                config.entityCap             = 200;
                config.skipDistantAI         = true;
                config.redstoneCutoffDist    = 48;
                config.skipDistantRedstone   = true;
                config.particleDensity       = 70;
                config.particleThrottle      = true;
                config.asyncLighting         = true;
                config.lazyTileEntities      = true;
                config.dreamMode             = false;
                config.targetFPS             = 60;
                config.entityCulling         = true;
                config.blockEntityCulling    = true;
                config.blockEntityCullDist   = 64;
                config.stutterFixEnabled      = true;
                config.renderThreadBoost      = true;
                config.limitChunkGenThreads   = true;
                config.maxChunkGenThreads     = 0;
                config.smoothBootEnabled      = true;
                config.fastMathEnabled        = true;
                config.gpuLeakFixEnabled      = true;
                config.avoidRedundantFbSwitch = true;
                config.leafCulling            = true;
                config.blockStateDeduplication = true;
                config.enableMemoryLeakFixes  = true;
                config.dynamicFpsEnabled     = true;
                config.unfocusedFpsCap       = 15;
            }

            case "ultra" -> {
                config.performanceMode       = "ultra";
                config.renderDistance        = 16;
                config.simulationDistance    = 12;
                config.entityTickDistance    = 64;
                config.entityCap             = 500;
                config.skipDistantAI         = false;
                config.redstoneCutoffDist    = 128;
                config.skipDistantRedstone   = false;
                config.particleDensity       = 100;
                config.particleThrottle      = false;
                config.asyncLighting         = true;
                config.lazyTileEntities      = false;
                config.dreamMode             = false;
                config.targetFPS             = 144;
                config.entityCulling         = false;
                config.blockEntityCulling    = false;
                config.blockEntityCullDist   = 128;
                config.stutterFixEnabled      = true;
                config.renderThreadBoost      = true;
                config.limitChunkGenThreads   = false;
                config.maxChunkGenThreads     = 0;
                config.smoothBootEnabled      = true;
                config.fastMathEnabled        = true;
                config.gpuLeakFixEnabled      = true;
                config.avoidRedundantFbSwitch = true;
                config.leafCulling            = false;
                config.blockStateDeduplication = true;
                config.enableMemoryLeakFixes  = true;
                config.dynamicFpsEnabled     = true;
                config.unfocusedFpsCap       = 30;
            }

            default -> ThanosGauntletFPS.LOGGER.warn("[Thanos] Unknown preset: {}", mode);
        }
        forceSave();
    }

    public ThanosConfig getConfig() { return config; }
}
