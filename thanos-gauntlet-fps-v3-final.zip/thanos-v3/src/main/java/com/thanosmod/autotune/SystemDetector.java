package com.thanosmod.autotune;

import com.thanosmod.ThanosGauntletFPS;

import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;

/**
 * ═══════════════════════════════════════════════════════════
 *  SystemDetector — Hardware Fingerprinting
 *
 *  BUG FIX (v2 → v3):
 *  v2 had top-level `import oshi.SystemInfo` etc. imports.
 *  If OSHI is absent from the classpath (alternative launchers,
 *  dedicated servers, CI), the JVM throws NoClassDefFoundError
 *  when loading the SystemDetector class — BEFORE any try/catch
 *  can run.  This crashed the entire mod on those environments.
 *
 *  Fix: Remove all OSHI imports. Use fully-qualified class names
 *  ONLY inside try/catch blocks so classloading failures are
 *  caught at runtime (not compile time or class-init time).
 *
 *  OSHI is bundled with the Minecraft launcher's authlib on
 *  most installations; this makes it a best-effort dependency.
 * ═══════════════════════════════════════════════════════════
 */
public final class SystemDetector {

    private static int    cpuCores     = 4;
    private static long   totalRamMB   = 4096;
    private static long   jvmMaxHeapMB = 2048;
    private static String gpuRenderer  = "Unknown GPU";
    private static String gpuVendor    = "Unknown";
    private static Tier   detectedTier = Tier.MID;

    public enum Tier { LOW, MID, HIGH }

    private SystemDetector() {}

    public static void detect() {
        detectCPUAndRAM();
        detectGPU();      // best-effort — OSHI may not be present
        classifyTier();
        ThanosGauntletFPS.LOGGER.info("[Thanos:SystemDetector] {}", getSummary());
    }

    private static void detectCPUAndRAM() {
        cpuCores     = Runtime.getRuntime().availableProcessors();
        jvmMaxHeapMB = Runtime.getRuntime().maxMemory() / (1024 * 1024);

        try {
            OperatingSystemMXBean osBean = ManagementFactory.getOperatingSystemMXBean();
            if (osBean instanceof com.sun.management.OperatingSystemMXBean sunBean) {
                totalRamMB = sunBean.getTotalMemorySize() / (1024 * 1024);
            } else {
                totalRamMB = jvmMaxHeapMB;
            }
        } catch (Exception e) {
            totalRamMB = jvmMaxHeapMB;
        }
    }

    /**
     * Detect GPU info via OSHI (if available).
     * All OSHI class references are fully-qualified and inside try/catch
     * so classloading failures are non-fatal.
     */
    private static void detectGPU() {
        try {
            // Fully-qualified: no import needed, ClassNotFoundException is caught
            oshi.SystemInfo si = new oshi.SystemInfo();
            oshi.hardware.HardwareAbstractionLayer hal = si.getHardware();
            java.util.List<oshi.hardware.GraphicsCard> gpus = hal.getGraphicsCards();

            if (!gpus.isEmpty()) {
                oshi.hardware.GraphicsCard chosen = gpus.get(0);
                for (oshi.hardware.GraphicsCard gpu : gpus) {
                    String name = gpu.getName().toLowerCase();
                    if (name.contains("nvidia") || name.contains("amd") || name.contains("radeon")) {
                        chosen = gpu;
                        break;
                    }
                }
                gpuRenderer = chosen.getName();
                gpuVendor   = chosen.getVendor();
                if (gpuVendor == null || gpuVendor.isBlank()) gpuVendor = "Unknown";
            }
        } catch (Throwable e) {
            // Throwable: catches both Exception and NoClassDefFoundError
            ThanosGauntletFPS.LOGGER.debug(
                "[Thanos:SystemDetector] GPU detection via OSHI unavailable: {}", e.getMessage());
        }
    }

    private static void classifyTier() {
        int score = 0;
        if (cpuCores >= 8) score += 3; else if (cpuCores >= 4) score += 2; else score += 1;
        if (totalRamMB >= 16384) score += 3; else if (totalRamMB >= 8192) score += 2; else score += 1;

        String gpu = gpuRenderer.toLowerCase();
        if (gpu.contains("rtx") || gpu.contains("rx 6") || gpu.contains("rx 7")
                || gpu.contains("arc") || gpu.contains("radeon rx")) score += 3;
        else if (gpu.contains("gtx") || gpu.contains("rx 5") || gpu.contains("vega")) score += 2;
        else score += 1;

        if      (score >= 8) detectedTier = Tier.HIGH;
        else if (score >= 5) detectedTier = Tier.MID;
        else                 detectedTier = Tier.LOW;
    }

    public static int    getCpuCores()     { return cpuCores;       }
    public static long   getTotalRamMB()   { return totalRamMB;     }
    public static long   getJvmHeapMB()    { return jvmMaxHeapMB;   }
    public static String getGpuRenderer()  { return gpuRenderer;    }
    public static String getGpuVendor()    { return gpuVendor;      }
    public static Tier   getDetectedTier() { return detectedTier;   }

    public static String getSummary() {
        return String.format(
            "CPU=%d cores | RAM=%d MB | JVM=%d MB | GPU=%s (%s) | Tier=%s",
            cpuCores, totalRamMB, jvmMaxHeapMB, gpuRenderer, gpuVendor, detectedTier
        );
    }

    public static String suggestMode() {
        return switch (detectedTier) {
            case LOW  -> "low_end";
            case MID  -> "balanced";
            case HIGH -> "ultra";
        };
    }
}
