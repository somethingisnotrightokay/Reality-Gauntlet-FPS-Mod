package com.thanosmod;

import com.thanosmod.autotune.AutoTuner;
import com.thanosmod.autotune.SystemDetector;
import com.thanosmod.compat.DistantHorizonsCompat;
import com.thanosmod.config.ConfigManager;
import com.thanosmod.config.ThanosConfig;
import com.thanosmod.modules.*;
import com.thanosmod.shader.ShaderDetector;
import com.thanosmod.shader.ShaderPresetManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class ThanosGauntletFPSClient implements ClientModInitializer {

    private static ThanosGauntletFPSClient instance;

    private RealityStone          realityStone;
    private MindStone             mindStone;
    private SoulStone             soulStone;
    private ChaosStone            chaosStone;
    private DynamicFpsModule      dynamicFpsModule;
    private AutoTuner             autoTuner;
    private ShaderDetector        shaderDetector;
    private ShaderPresetManager   shaderPresetManager;
    private DistantHorizonsCompat dhCompat;

    public static KeyBinding cycleModeKey;

    private int     tickCounter      = 0;
    private boolean lastShadersOn    = false;
    private String  lastShaderPack   = "";

    private static final int AUTO_TUNE_INTERVAL = 100; // ticks ≈ 5 s

    @Override
    public void onInitializeClient() {
        instance = this;
        ConfigManager cfg = ThanosGauntletFPS.getConfigManager();

        shaderDetector      = new ShaderDetector();
        shaderPresetManager = new ShaderPresetManager(shaderDetector);
        SystemDetector.detect();

        realityStone    = new RealityStone();  realityStone.init(cfg.getConfig());
        mindStone       = new MindStone(shaderDetector);
        soulStone       = new SoulStone();     soulStone.init(cfg.getConfig());
        chaosStone      = new ChaosStone();    chaosStone.init(cfg.getConfig());
        dynamicFpsModule = new DynamicFpsModule();
        autoTuner       = new AutoTuner(mindStone, shaderDetector);
        dhCompat        = new DistantHorizonsCompat();

        shaderPresetManager.logSupportedPacks();

        cycleModeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "thanos.config.hotkeySwitchMode",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_K,
            "Thanos Gauntlet FPS"
        ));

        ClientLifecycleEvents.CLIENT_STARTED.register(client ->
            ThanosGauntletFPS.LOGGER.info("[Thanos] Client started. System: {}", SystemDetector.getSummary())
        );

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            ThanosConfig activeCfg = cfg.getConfig();
            if (dhCompat.isDhPresent() && activeCfg.dhCompatEnabled) {
                boolean changed = dhCompat.onWorldLoad(activeCfg);
                if (changed) { realityStone.reloadConfig(activeCfg); cfg.forceSave(); }
            }
            if (activeCfg.shaderAutoPreset && shaderDetector.isShadersEnabled()) {
                applyShaderPreset(activeCfg);
            }
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            dhCompat.onWorldUnload();
            ThanosConfig activeCfg = cfg.getConfig();
            if (activeCfg.enableMemoryLeakFixes) {
                ThanosGauntletFPS.getPowerStone().onWorldUnload();
                ThanosGauntletFPS.getSpaceStone().performMemoryCleanup();
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);

        ThanosGauntletFPS.LOGGER.info("[Thanos] Client online. DH={} | Shader={}",
            dhCompat.isDhPresent(), shaderDetector.getRenderStackSummary());
    }

    private void onClientTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;

        while (cycleModeKey.wasPressed()) {
            String newMode = mindStone.cycleMode();
            client.player.sendMessage(Text.literal("§d[Thanos] Mode: §f" + newMode), true);
        }

        // Shader change detection
        boolean shadersNow  = shaderDetector.isShadersEnabled();
        String  packNow     = shadersNow ? shaderDetector.getActiveShaderPackName() : "";
        boolean toggled     = shadersNow != lastShadersOn;
        boolean packChanged = !packNow.equals(lastShaderPack) && !packNow.isBlank();

        if (toggled || (shadersNow && packChanged)) {
            lastShadersOn  = shadersNow;
            lastShaderPack = packNow;
            ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
            if (cfg.shaderAutoPreset) {
                if (shadersNow) {
                    applyShaderPreset(cfg);
                    realityStone.reloadConfig(cfg);
                    ThanosGauntletFPS.getConfigManager().forceSave();
                    if (client.player != null) {
                        client.player.sendMessage(
                            Text.literal("§d[Thanos] Shader preset applied for: §f" + packNow), true);
                    }
                } else {
                    ThanosGauntletFPS.getConfigManager().applyPreset(cfg.performanceMode);
                    realityStone.reloadConfig(cfg);
                }
            }
        }

        // Dynamic FPS volume management
        dynamicFpsModule.tick(client);

        // Periodic auto-tune
        if (++tickCounter >= AUTO_TUNE_INTERVAL) {
            tickCounter = 0;
            if (ThanosGauntletFPS.getConfigManager().getConfig().autoTuneEnabled) {
                autoTuner.evaluate(client);
            }
        }

        soulStone.tick(client);
        chaosStone.tick(client);
    }

    private void applyShaderPreset(ThanosConfig cfg) {
        ShaderPresetManager.ShaderPreset preset = shaderPresetManager.refreshAndGetPreset();
        if (preset == null) return;
        if (dhCompat.isDhPresent() && cfg.dhCompatEnabled) {
            int dhDist = cfg.dhVanillaRenderDist > 0 ? cfg.dhVanillaRenderDist : 6;
            shaderPresetManager.applyPresetToConfig(cfg, preset);
            if (cfg.renderDistance > dhDist) cfg.renderDistance = dhDist;
        } else {
            shaderPresetManager.applyPresetToConfig(cfg, preset);
        }
    }

    // ── Accessors ──────────────────────────────────────────────────────────
    public static ThanosGauntletFPSClient  getInstance()           { return instance;               }
    public static RealityStone             getRealityStone()        { return instance.realityStone;  }
    public static MindStone                getMindStone()           { return instance.mindStone;     }
    public static SoulStone                getSoulStone()           { return instance.soulStone;     }
    public static ChaosStone               getChaosStone()          { return instance.chaosStone;    }
    public static DynamicFpsModule         getDynamicFpsModule()    { return instance.dynamicFpsModule; }
    public static AutoTuner                getAutoTuner()           { return instance.autoTuner;     }
    public static ShaderDetector           getShaderDetector()      { return instance.shaderDetector;}
    public static ShaderPresetManager      getShaderPresetManager() { return instance.shaderPresetManager; }
    public static DistantHorizonsCompat    getDhCompat()            { return instance.dhCompat;      }
}
