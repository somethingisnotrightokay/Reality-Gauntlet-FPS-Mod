package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPSClient;
import com.thanosmod.modules.RealityStone;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ClientTickMixin — re-applies RealityStone render distance settings each tick.
 *
 * BUG FIX (v2 → v3):
 * Added null guard around ThanosGauntletFPSClient.getRealityStone().
 * In edge cases during first-world-join, the client initializer may
 * not have finished before the first tick fires, causing NPE.
 */
@Environment(EnvType.CLIENT)
@Mixin(MinecraftClient.class)
public class ClientTickMixin {

    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void thanos$onClientTickEnd(CallbackInfo ci) {
        ThanosGauntletFPSClient client = ThanosGauntletFPSClient.getInstance();
        if (client == null) return;  // not yet initialised — skip safely
        RealityStone rs = ThanosGauntletFPSClient.getRealityStone();
        if (rs != null) rs.apply();
    }
}
