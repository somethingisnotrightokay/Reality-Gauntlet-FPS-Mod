package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.config.ThanosConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * RainCullMixin — suppress weather rendering in Dream Mode or when unfocused.
 *
 * BUG FIX (v2 → v3):
 * Removed unused import of net.minecraft.client.render.WeatherRendering.
 * This class does not exist in 1.21.1 Yarn mappings — the import caused
 * a compile error that silently prevented the mixin from loading.
 */
@Environment(EnvType.CLIENT)
@Mixin(WorldRenderer.class)
public class RainCullMixin {

    @Inject(
        method      = "renderRainAndSnow",
        at          = @At("HEAD"),
        cancellable = true,
        require     = 0
    )
    private void thanos$maybeCullWeather(float tickDelta, CallbackInfo ci) {
        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();

        if (cfg.dreamMode || cfg.particleDensity == 0) {
            ci.cancel();
            return;
        }

        if (cfg.dynamicFpsEnabled) {
            net.minecraft.client.MinecraftClient client =
                net.minecraft.client.MinecraftClient.getInstance();
            if (client != null && !client.isWindowFocused()) {
                ci.cancel();
            }
        }
    }
}
