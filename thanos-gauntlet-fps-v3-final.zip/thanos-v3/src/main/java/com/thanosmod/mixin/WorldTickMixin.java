package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ═══════════════════════════════════════════════════════════
 *  WorldTickMixin — Time Stone + Power Stone per-tick hooks
 *
 *  BUG FIX (v2 → v3):
 *  The injected field `thanos$pruneCounter` was missing @Unique.
 *  Without @Unique, Mixin cannot distinguish this field from
 *  any identically-named field injected by another mixin into
 *  ServerWorld — causing a MixinApplyError at startup.
 *  Fixed: added @Unique annotation.
 *
 *  Also removed unused imports (SpaceStone, TimeStone stubs
 *  that were referenced but their methods were never called
 *  from this mixin — the calls go through the static accessors).
 * ═══════════════════════════════════════════════════════════
 */
@Mixin(ServerWorld.class)
public class WorldTickMixin {

    /** Tick counter for pruning the entity AI-skip cache. Must be @Unique. */
    @Unique
    private int thanos$pruneCounter = 0;

    @Inject(
        method  = "tick",
        at      = @At("TAIL"),
        require = 0
    )
    private void thanos$onTickEnd(
            java.util.function.BooleanSupplier shouldKeepTicking,
            CallbackInfo ci) {

        ServerWorld world = (ServerWorld)(Object) this;

        // Flush deferred block update batch (Time Stone)
        ThanosGauntletFPS.getTimeStone().flushBatch();

        // Prune stale entity AI-skip entries every ~10 s (Power Stone)
        if (++thanos$pruneCounter >= 200) {
            thanos$pruneCounter = 0;
            ThanosGauntletFPS.getPowerStone().pruneTickCache(world.getTime());
        }
    }
}
