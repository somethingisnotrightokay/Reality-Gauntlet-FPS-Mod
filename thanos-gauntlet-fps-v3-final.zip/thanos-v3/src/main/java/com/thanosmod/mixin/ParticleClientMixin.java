package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ParticleClientMixin — throttles client-side particle spawning.
 *
 * Targets the package-private addParticle overload that all public
 * spawn paths funnel through in 1.21.1. require=0 means a signature
 * mismatch is a logged warning rather than a hard build failure,
 * so the mod still loads if Mojang renames it in a patch.
 */
@Environment(EnvType.CLIENT)
@Mixin(value = ParticleManager.class, priority = 900)
public class ParticleClientMixin {

    // Primary target: the 6-double overload (no boolean) used in 1.21.1
    @Inject(
        method      = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)V",
        at          = @At("HEAD"),
        cancellable = true,
        require     = 0
    )
    private void thanos$throttleParticle6(
            ParticleEffect parameters,
            double x, double y, double z,
            double velocityX, double velocityY, double velocityZ,
            CallbackInfo ci) {

        if (!ThanosGauntletFPS.getTimeStone().shouldSpawnParticle()) {
            ci.cancel();
        }
    }

    // Fallback target: 7-arg overload with boolean alwaysSpawn present in some builds
    @Inject(
        method      = "addParticle(Lnet/minecraft/particle/ParticleEffect;ZDDDDDD)V",
        at          = @At("HEAD"),
        cancellable = true,
        require     = 0
    )
    private void thanos$throttleParticle7(
            ParticleEffect parameters,
            boolean shouldAlwaysSpawn,
            double x, double y, double z,
            double velocityX, double velocityY, double velocityZ,
            CallbackInfo ci) {

        if (!ThanosGauntletFPS.getTimeStone().shouldSpawnParticle()) {
            ci.cancel();
        }
    }
}
