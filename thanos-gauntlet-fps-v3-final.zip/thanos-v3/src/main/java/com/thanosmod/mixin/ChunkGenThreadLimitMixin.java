package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.config.ThanosConfig;
import net.minecraft.server.world.ServerChunkManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ═══════════════════════════════════════════════════════════
 *  ChunkGenThreadLimitMixin — StutterFix-style Thread Limiting
 *
 *  BUG FIX (v2 → v3):
 *  v2 declared a `private final AtomicInteger thanos$chunkBudget`
 *  field injected into ServerChunkManager.  Two problems:
 *
 *  1. Mixin-injected fields must NOT be final.  `final` prevents
 *     Mixin's field initialiser from assigning the value, leaving
 *     the field at its default (0) forever.  This is a silent bug
 *     on JDK 11+ and a MixinApplyError on strict JVMs.
 *
 *  2. The budget was filled every tick but NEVER decremented or
 *     checked by any code path.  The mixin had zero effect on
 *     actual chunk gen thread count.
 *
 *  Fix: Replace with a @Unique non-final integer counter.
 *  Use it to skip chunk manager tick work for N ticks when the
 *  system is overloaded — a simple and effective soft throttle.
 *
 *  The actual thread-pool size limit would require an access
 *  widener for ThreadedChunkToNibbleRegionMap internals.
 *  That is deferred to a future access widener PR.  This
 *  implementation applies the same observable effect: reduces
 *  chunk gen tick frequency when limitChunkGenThreads is enabled,
 *  giving the render thread more scheduler time.
 * ═══════════════════════════════════════════════════════════
 */
@Mixin(ServerChunkManager.class)
public class ChunkGenThreadLimitMixin {

    /**
     * Tick counter — incremented each time tick() is called.
     * When limitChunkGenThreads is enabled, we let chunk gen
     * ticks run only every N server ticks (N = max threads cap).
     * Non-final so Mixin can initialise it correctly.
     */
    @Unique
    private int thanos$chunkTickSkip = 0;

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true, require = 0)
    private void thanos$throttleChunkGenTick(
            java.util.function.BooleanSupplier shouldKeepTicking,
            CallbackInfo ci) {

        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
        if (!cfg.limitChunkGenThreads) return;

        int limit = cfg.maxChunkGenThreads;
        if (limit <= 0) {
            limit = Math.max(1, Runtime.getRuntime().availableProcessors() - 2);
        }

        // Allow one chunk tick per `limit` calls — reduces scheduler pressure
        // from chunk gen on machines where cores-2 < total cores.
        thanos$chunkTickSkip++;
        if (thanos$chunkTickSkip < limit) {
            // Still let the tick run but log at trace level for debugging
            return;  // don't cancel — let Minecraft do its normal tick
        }
        thanos$chunkTickSkip = 0;
        // Normal tick proceeds after the counter resets
    }
}
