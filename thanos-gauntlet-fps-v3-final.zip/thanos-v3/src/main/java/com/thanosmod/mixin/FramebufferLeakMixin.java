package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.config.ThanosConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.Framebuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.ref.Cleaner;

/**
 * ═══════════════════════════════════════════════════════════
 *  FramebufferLeakMixin — GpuTape-inspired VRAM leak detection
 *
 *  BUG FIX (v2 → v3):
 *  1. Removed unused imports of PhantomReference and ReferenceQueue.
 *     Cleaner handles phantom-reference bookkeeping internally.
 *     These dead imports caused -Xlint:all compilation errors.
 *
 *  2. Constructor target changed from `<init>` (ambiguous — picks
 *     first constructor found) to `<init>(IIZ)V` which is the
 *     standard Framebuffer(int width, int height, boolean useDepth)
 *     constructor used by all internal MC paths in 1.21.1.
 *     require=0 so a signature change just logs a warning.
 *
 *  3. Clarified that the Cleaner lambda MUST NOT close over 'this'
 *     (would prevent GC of the Framebuffer). ids[] is a local int[]
 *     — safe to capture. Added assertion comment for future maintainers.
 *
 *  4. The Cleaner fires on a daemon thread where GL calls are
 *     FORBIDDEN (GL context is render-thread-bound).  v2 and v3
 *     both correctly avoid GL calls — only log the leak.
 *     This is intentional: logging the leak helps root-cause it.
 * ═══════════════════════════════════════════════════════════
 */
@Environment(EnvType.CLIENT)
@Mixin(Framebuffer.class)
public class FramebufferLeakMixin {

    /** One JVM-wide Cleaner with one daemon thread — shared for all Framebuffers. */
    private static final Cleaner CLEANER = Cleaner.create();

    /**
     * Register a Cleaner action after the Framebuffer is fully constructed.
     * If it is GC'd without delete() being called, the Cleaner logs the leak.
     * Target: (IIZ)V = Framebuffer(int width, int height, boolean useDepth)
     */
    @Inject(method = "<init>(IIZ)V", at = @At("TAIL"), require = 0)
    private void thanos$registerGpuCleanup(int width, int height, boolean useDepth, CallbackInfo ci) {
        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
        if (!cfg.gpuLeakFixEnabled) return;

        // Read GL ids now via reflection — before the Framebuffer might be collected.
        // ids[] is a plain int[] allocated here; the lambda captures ids, NOT 'this'.
        // Capturing 'this' would keep the Framebuffer alive forever (defeating GC).
        final int[] ids = readGlIds((Framebuffer)(Object) this);

        CLEANER.register(this, () -> {
            // Runs on Cleaner daemon thread — GL calls are NOT allowed here.
            if (ids[0] != -1 && ids[0] != 0) {
                // Suppress logger null-safety: LOGGER is static final, always non-null
                ThanosGauntletFPS.LOGGER.warn(
                    "[Thanos:GpuTape] Framebuffer GC'd without delete() (fboId={}, {}x{}) " +
                    "— VRAM leak detected. Check the code that created this Framebuffer.",
                    ids[0], width, height
                );
            }
        });
    }

    /** Read {fboId, colorAttachment, depthAttachment} via reflection. Returns {-1,-1,-1} on failure. */
    private static int[] readGlIds(Framebuffer fb) {
        int[] out = {-1, -1, -1};
        readField(fb, out, 0, "fbo", "framebufferObject", "glId");
        readField(fb, out, 1, "colorAttachment", "colorAttachmentId", "textureId");
        readField(fb, out, 2, "depthAttachment", "depthAttachmentId", "depthTextureId");
        return out;
    }

    private static void readField(Framebuffer fb, int[] out, int idx, String... names) {
        for (String name : names) {
            try {
                java.lang.reflect.Field f = Framebuffer.class.getDeclaredField(name);
                f.setAccessible(true);
                out[idx] = f.getInt(fb);
                return;
            } catch (Exception ignored) {}
        }
        // Also search superclasses (SimpleFramebuffer extends Framebuffer)
        for (String name : names) {
            try {
                java.lang.reflect.Field f = fb.getClass().getDeclaredField(name);
                f.setAccessible(true);
                out[idx] = f.getInt(fb);
                return;
            } catch (Exception ignored) {}
        }
    }
}
