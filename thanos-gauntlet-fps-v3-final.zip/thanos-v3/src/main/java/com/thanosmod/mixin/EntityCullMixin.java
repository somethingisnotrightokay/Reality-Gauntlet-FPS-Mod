package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ═══════════════════════════════════════════════════════════
 *  EntityCullMixin — Client-Side Entity Render Culling
 *
 *  What this does:
 *  Minecraft renders every entity that is within the render
 *  distance and in a loaded chunk, regardless of whether it
 *  is visible to the player.  In a world with many mobs this
 *  wastes significant GPU time.
 *
 *  We inject into WorldRenderer.renderEntity() and perform
 *  two culling checks before the draw call:
 *
 *  1. Back-hemisphere cull — if the entity's center is more
 *     than 90° + an angular-size margin behind the camera,
 *     skip it entirely.  Unlike a pixel-exact frustum test
 *     this requires no access to private frustum state.
 *
 *  2. Distance-scaled threshold — entities right next to the
 *     player are never culled so there's no pop-in when the
 *     player turns quickly.
 *
 *  Exemptions (always rendered):
 *    • PlayerEntity (including self via 3rd-person camera)
 *    • Entities with custom name tags (visible from any angle)
 *    • Entities closer than MIN_CULL_DIST blocks
 *
 *  This is a simplified version of what EntityCulling mod
 *  does with ray-cast occlusion.  Pure geometry, no rays.
 *  Gains are most visible with large mob farms or busy servers.
 * ═══════════════════════════════════════════════════════════
 */
@Environment(EnvType.CLIENT)
@Mixin(WorldRenderer.class)
public class EntityCullMixin {

    /** Don't cull entities closer than this many blocks (prevents pop-in). */
    private static final double MIN_CULL_DIST    = 16.0;
    private static final double MIN_CULL_DIST_SQ = MIN_CULL_DIST * MIN_CULL_DIST;

    /**
     * Angular safety margin added to entity bounding-box half-angle
     * when computing the cull threshold.  Larger = more conservative
     * (fewer false culls, less gain).  ~15° in radians.
     */
    private static final double ANGULAR_MARGIN_RAD = Math.toRadians(15.0);

    @Inject(
        method      = "renderEntity",
        at          = @At("HEAD"),
        cancellable = true,
        require     = 0    // mixin fails silently if renderEntity is renamed
    )
    private void thanos$maybeSkipEntityRender(
            Entity entity,
            double cameraX, double cameraY, double cameraZ,
            float  tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            CallbackInfo ci) {

        if (!ThanosGauntletFPS.getConfigManager().getConfig().entityCulling) return;

        // ── Exemptions ────────────────────────────────────────────────────
        if (entity instanceof PlayerEntity) return;   // never cull players
        if (entity.hasCustomName())         return;   // name tags show from all angles
        if (entity.isGlowing())             return;   // glowing outline effect needs render

        // ── Distance guard ────────────────────────────────────────────────
        double dx = entity.getX() - cameraX;
        double dy = entity.getEyeY() - cameraY;
        double dz = entity.getZ() - cameraZ;
        double distSq = dx * dx + dy * dy + dz * dz;

        if (distSq < MIN_CULL_DIST_SQ) return;  // close entities always render

        // ── Get camera direction ───────────────────────────────────────────
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.gameRenderer == null) return;

        Camera camera = client.gameRenderer.getCamera();
        Vec3d forward = Vec3d.fromPolar(camera.getPitch(), camera.getYaw());

        // ── Angular test ──────────────────────────────────────────────────
        // Dot product of the (camera → entity) unit vector with the camera
        // forward direction.
        //   dot >  0.0  → entity is in front of the camera
        //   dot = -1.0  → entity is directly behind the camera
        double dist = Math.sqrt(distSq);
        double dot  = (dx * forward.x + dy * forward.y + dz * forward.z) / dist;

        // Estimate the angular half-size of the entity's bounding box at
        // this distance so we don't cull large nearby entities even if their
        // centre is technically behind us.
        Box    box      = entity.getVisibilityBoundingBox();
        double halfDiag = 0.5 * Math.sqrt(
            squaredLen(box.maxX - box.minX,
                       box.maxY - box.minY,
                       box.maxZ - box.minZ)
        );
        double angularHalf = Math.atan2(halfDiag, dist) + ANGULAR_MARGIN_RAD;

        // The cull threshold: cos( 90° + angularHalf )
        // Anything with dot < threshold has its centre more than
        // (90° + angularHalf) away from the camera direction → cull.
        double threshold = -Math.sin(angularHalf);   // cos(90°+x) = -sin(x)

        if (dot < threshold) {
            ci.cancel();
        }
    }

    private static double squaredLen(double x, double y, double z) {
        return x * x + y * y + z * z;
    }
}
