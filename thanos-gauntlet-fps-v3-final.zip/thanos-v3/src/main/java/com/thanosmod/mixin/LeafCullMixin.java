package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.config.ThanosConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeavesBlock;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.block.BlockModelRenderer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.RandomSource;
import net.minecraft.world.BlockRenderView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * ═══════════════════════════════════════════════════════════
 *  LeafCullMixin — MoreCulling-inspired interior leaf culling
 *
 *  BUG FIX (v2 → v3):
 *  v2 used `java.util.Random` in the inject method signature for
 *  renderSmooth/renderFlat.  In Minecraft 1.18+, the Random
 *  parameter type was changed to `net.minecraft.util.math.random.RandomSource`.
 *  Using java.util.Random produced a descriptor mismatch — the mixin
 *  applied to the wrong method or failed silently (require=0).
 *  Either way leaf culling was completely broken in v2.
 *
 *  Fix: Use RandomSource in all inject signatures.
 *
 *  Sodium compat note: Sodium replaces BlockModelRenderer entirely.
 *  When Sodium is present, these methods are never called — our
 *  mixin has zero effect.  This is safe (not a conflict) because
 *  Sodium implements its own, more aggressive culling.
 *  require=0 ensures no crash when Sodium is installed.
 * ═══════════════════════════════════════════════════════════
 */
@Environment(EnvType.CLIENT)
@Mixin(BlockModelRenderer.class)
public class LeafCullMixin {

    @Inject(
        method      = "renderSmooth",
        at          = @At("HEAD"),
        cancellable = true,
        require     = 0
    )
    private void thanos$cullLeafSmooth(
            BlockRenderView world,
            BakedModel model,
            BlockState state,
            BlockPos pos,
            MatrixStack matrices,
            VertexConsumer vertexConsumer,
            boolean cull,
            RandomSource random,
            long seed,
            int overlay,
            CallbackInfoReturnable<Boolean> cir) {

        if (shouldCullLeaf(world, state, pos)) {
            cir.setReturnValue(false);  // setReturnValue implies cancel for CIR
        }
    }

    @Inject(
        method      = "renderFlat",
        at          = @At("HEAD"),
        cancellable = true,
        require     = 0
    )
    private void thanos$cullLeafFlat(
            BlockRenderView world,
            BakedModel model,
            BlockState state,
            BlockPos pos,
            MatrixStack matrices,
            VertexConsumer vertexConsumer,
            boolean cull,
            RandomSource random,
            long seed,
            int overlay,
            CallbackInfoReturnable<Boolean> cir) {

        if (shouldCullLeaf(world, state, pos)) {
            cir.setReturnValue(false);
        }
    }

    /**
     * Cull only if the block is a leaf AND all 6 face-neighbors are the
     * same leaf block type (fully interior — every face is hidden).
     * Transparent/waterlogged leaves are not skipped — a different leaf
     * type neighbor means at least one face must render.
     */
    private boolean shouldCullLeaf(BlockRenderView world, BlockState state, BlockPos pos) {
        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
        if (!cfg.leafCulling) return false;
        if (!(state.getBlock() instanceof LeavesBlock)) return false;

        for (Direction dir : Direction.values()) {
            BlockState neighbor = world.getBlockState(pos.offset(dir));
            // Must be the exact same block type (not just any LeavesBlock)
            if (neighbor.getBlock() != state.getBlock()) return false;
        }
        return true;
    }
}
