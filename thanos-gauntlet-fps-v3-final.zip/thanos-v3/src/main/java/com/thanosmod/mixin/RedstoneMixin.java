package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.config.ThanosConfig;
import net.minecraft.block.BlockState;
import net.minecraft.block.RedstoneWireBlock;
import net.minecraft.block.Block;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ═══════════════════════════════════════════════════════════
 *  RedstoneMixin — skip distant redstone wire updates
 *
 *  BUG FIX (v2 → v3):
 *  v2 passed maxDistance=-1.0 to getClosestPlayer(), which means
 *  "no limit — scan all players in the world."  On busy servers
 *  with many players, this made every single redstone update
 *  trigger a full-world player scan — actually SLOWER than
 *  just running the redstone update.
 *
 *  Fix: Pass cfg.redstoneCutoffDist as the maxDistance bound.
 *  If no player is within cutoff distance, we already know the
 *  redstone is distant and can skip it — no need to scan further.
 *
 *  Also added the missing ThanosConfig import and safe
 *  instanceof pattern-match for the ServerWorld cast.
 * ═══════════════════════════════════════════════════════════
 */
@Mixin(RedstoneWireBlock.class)
public class RedstoneMixin {

    @Inject(
        method      = "neighborUpdate",
        at          = @At("HEAD"),
        cancellable = true,
        require     = 0
    )
    private void thanos$maybeSkipRedstoneUpdate(
            BlockState state,
            World world,
            BlockPos pos,
            Block sourceBlock,
            BlockPos sourcePos,
            boolean notify,
            CallbackInfo ci) {

        if (!(world instanceof ServerWorld sw)) return;

        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
        if (!cfg.skipDistantRedstone) return;

        // Use cutoffDist as the player scan radius — bounded scan, not full-world
        double scanRadius = cfg.redstoneCutoffDist;
        var nearestPlayer = sw.getClosestPlayer(
            pos.getX(), pos.getY(), pos.getZ(),
            scanRadius,
            false
        );

        if (nearestPlayer == null) {
            // No player within cutoff — definitely distant, skip update
            ci.cancel();
            return;
        }

        if (!ThanosGauntletFPS.getTimeStone().shouldEvaluateRedstone(
                world, pos, nearestPlayer.getX(), nearestPlayer.getZ())) {
            ci.cancel();
        }
    }
}
