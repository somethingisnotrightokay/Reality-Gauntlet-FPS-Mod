package com.thanosmod.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;

/**
 * GameRendererMixin — extension point for render budget profiling.
 * @Environment prevents server crashes.
 */
@Environment(EnvType.CLIENT)
@Mixin(GameRenderer.class)
public class GameRendererMixin {
    // Future: frame-time profiling → AutoTuner.recordFrameTime(long nanos)
}
