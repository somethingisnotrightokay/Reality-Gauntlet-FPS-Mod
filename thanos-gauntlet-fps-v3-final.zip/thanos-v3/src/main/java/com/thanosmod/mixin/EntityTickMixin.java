package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.modules.PowerStone;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ═══════════════════════════════════════════════════════════
 *  EntityTickMixin — AI goal suppression for distant mobs
 *
 *  BUG FIX (v2 → v3):
 *  v2 checked mob.getWorld().isClient() == false and then
 *  unconditionally cast to ServerWorld.  On integrated server /
 *  LAN worlds, a mob's getWorld() can return a ClientWorld even
 *  after the isClient() guard in edge cases during world transitions.
 *  This caused ClassCastException crashes on LAN servers.
 *
 *  Fix: Replace the two-step check+cast with a single
 *  `instanceof ServerWorld sw` pattern-match guard.
 *  If the world is not a ServerWorld, skip silently.
 * ═══════════════════════════════════════════════════════════
 */
@Mixin(MobEntity.class)
public class EntityTickMixin {

    @Inject(
        method      = "mobTick",
        at          = @At("HEAD"),
        cancellable = true,
        require     = 0
    )
    private void thanos$maybeSkipAiGoals(CallbackInfo ci) {
        MobEntity mob = (MobEntity)(Object) this;
        World world = mob.getWorld();

        // Safe cast: only proceed when we are definitely on the server side
        if (!(world instanceof ServerWorld sw)) return;

        PowerStone ps = ThanosGauntletFPS.getPowerStone();
        if (!ps.shouldSkipDistantAI()) return;

        var nearestPlayer = sw.getClosestPlayer(
            mob.getX(), mob.getY(), mob.getZ(),
            ps.getEntityTickDistance() * 2.0,
            false
        );

        double playerX, playerZ;
        if (nearestPlayer == null) {
            playerX = mob.getX() + ps.getEntityTickDistance() + 1.0;
            playerZ = mob.getZ();
        } else {
            playerX = nearestPlayer.getX();
            playerZ = nearestPlayer.getZ();
        }

        if (!ps.shouldTickEntityAI(mob, playerX, playerZ, sw.getTime())) {
            ci.cancel();
        }
    }
}
