package com.thanosmod.mixin;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.config.ThanosConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ═══════════════════════════════════════════════════════════
 *  ThreadPriorityMixin — StutterFix-style Thread Tuning
 *
 *  The Minecraft render thread (which is also the "main"
 *  thread on the client) runs at default JVM priority (5).
 *  On Windows and Linux, the OS can pre-empt it in favour of
 *  background threads, causing visible stutter.
 *
 *  StutterFix's MinecraftClientMixin raises the thread
 *  priority to MAX_PRIORITY (10) once the client is fully
 *  initialised, which tells the OS scheduler to prefer it.
 *
 *  We inject at the same point — immediately before the game
 *  tick loop starts — to match that behaviour.
 *
 *  Caution: MAX_PRIORITY can starve background threads.
 *  This is guarded by stutterFixEnabled so users can opt out.
 * ═══════════════════════════════════════════════════════════
 */
@Environment(EnvType.CLIENT)
@Mixin(MinecraftClient.class)
public class ThreadPriorityMixin {

    @Inject(
        method = "run",
        at     = @At(
            value  = "INVOKE",
            // Inject right after the tick duration monitor is created —
            // same hook point StutterFix uses. require=0 for safety.
            target = "Lnet/minecraft/util/TickDurationMonitor;create(Ljava/lang/String;)Lnet/minecraft/util/TickDurationMonitor;",
            shift  = At.Shift.AFTER
        ),
        require = 0
    )
    private void thanos$boostRenderThreadPriority(CallbackInfo ci) {
        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
        if (!cfg.stutterFixEnabled) return;

        Thread current = Thread.currentThread();
        if (current.getPriority() < Thread.MAX_PRIORITY) {
            try {
                current.setPriority(Thread.MAX_PRIORITY);
                ThanosGauntletFPS.LOGGER.info(
                    "[Thanos:StutterFix] Render thread '{}' priority raised to {} (was {}).",
                    current.getName(),
                    Thread.MAX_PRIORITY,
                    current.getPriority()
                );
            } catch (SecurityException e) {
                ThanosGauntletFPS.LOGGER.warn(
                    "[Thanos:StutterFix] Could not raise render thread priority: {}", e.getMessage()
                );
            }
        }
    }
}
