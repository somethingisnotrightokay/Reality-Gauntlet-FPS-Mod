package com.thanosmod.mixin;

import com.thanosmod.modules.RealityStone;
import net.minecraft.server.world.ServerChunkManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ServerChunkManagerMixin — extension point for async lighting (Reality Stone).
 *
 * BUG FIX (v2 → v3):
 * Added require=0 to the inject (was missing, defaultRequire was 1 globally
 * in v2's mixins.json — meaning a method rename would crash the game).
 * Now defaultRequire is 0 globally and this is a stub that logs nothing —
 * safe to leave as an extension point for future implementation.
 */
@Mixin(ServerChunkManager.class)
public class ServerChunkManagerMixin {

    @Inject(method = "tick", at = @At("HEAD"), require = 0)
    private void thanos$onChunkManagerTick(
            java.util.function.BooleanSupplier shouldKeepTicking,
            CallbackInfo ci) {
        // Extension point: async lighting / enhanced chunk loading
        // RealityStone.isAsyncLightingEnabled() — implementation deferred
    }
}
