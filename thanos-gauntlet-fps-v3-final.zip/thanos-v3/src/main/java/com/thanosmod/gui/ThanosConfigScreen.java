package com.thanosmod.gui;

import com.thanosmod.ThanosGauntletFPS;
import com.thanosmod.ThanosGauntletFPSClient;
import com.thanosmod.autotune.SystemDetector;
import com.thanosmod.config.ConfigManager;
import com.thanosmod.config.ThanosConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

/**
 * ═══════════════════════════════════════════════════════════
 *  ThanosConfigScreen — Completely rebuilt Config UI
 *
 *  Design: space-themed dark panel, left nav sidebar,
 *  scrollable content area, live stats bar.
 *
 *  Pages (sidebar nav):
 *    ⚡ Overview      — live stats dashboard
 *    🔭 Rendering     — chunks, culling, lighting
 *    👾 Entities      — AI, caps, culling
 *    💾 Memory        — GC, leak fixes, FerriteCore
 *    ⚙️ Performance   — particles, redstone, auto-tune
 *    🎮 Dynamic FPS   — unfocused throttle, volume
 *    🔧 Stutter Fix   — thread tuning, smooth boot
 *    🌌 Compat        — DH, shaders, presets
 *    📊 Debug/HUD     — overlay, logging
 *
 *  Features:
 *  • Scrollable row list with mouse wheel support
 *  • Live FPS bar at top
 *  • Toggle buttons with ON/OFF color coding
 *  • Integer sliders with live value display
 *  • Info rows (read-only text)
 *  • Preset bar (Low / Balanced / Ultra)
 *  • Auto-save on close (debounced)
 * ═══════════════════════════════════════════════════════════
 */
public class ThanosConfigScreen extends Screen {

    // ── Parent ────────────────────────────────────────────────────────────
    private final Screen parent;

    // ── Theme palette ──────────────────────────────────────────────────────
    private static final int COL_VOID        = 0xF0050510;  // very dark bg
    private static final int COL_PANEL       = 0xFF0E0B1C;  // main panel
    private static final int COL_PANEL_BD    = 0xFF3A2070;  // panel border
    private static final int COL_HEADER      = 0xFF160D2E;  // header bg
    private static final int COL_HEADER_GLOW = 0xFF5C20A8;  // header accent
    private static final int COL_NAV         = 0xFF100B22;  // sidebar
    private static final int COL_NAV_SEL     = 0xFF2A1550;  // selected item bg
    private static final int COL_NAV_SEL_BD  = 0xFF7030D0;  // selected item border
    private static final int COL_CONTENT     = 0xFF090614;  // content area
    private static final int COL_ROW_A       = 0x00000000;  // even rows transparent
    private static final int COL_ROW_B       = 0x12FFFFFF;  // odd rows slight tint
    private static final int COL_FOOTER      = 0xFF0A0818;
    private static final int COL_SEPARATOR   = 0x60604080;

    private static final int COL_WHITE       = 0xFFFFFFFF;
    private static final int COL_LIGHT       = 0xFFCCCCCC;
    private static final int COL_GRAY        = 0xFF888888;
    private static final int COL_GOLD        = 0xFFFFD700;
    private static final int COL_PURPLE      = 0xFFAA55FF;
    private static final int COL_GREEN       = 0xFF55FF55;
    private static final int COL_YELLOW      = 0xFFFFFF55;
    private static final int COL_RED         = 0xFFFF5555;
    private static final int COL_CYAN        = 0xFF55FFFF;
    private static final int COL_ORANGE      = 0xFFFF9922;

    // ── Layout constants ───────────────────────────────────────────────────
    private static final int PANEL_W     = 640;
    private static final int PANEL_H     = 400;
    private static final int HEADER_H    = 28;
    private static final int FOOTER_H    = 28;
    private static final int NAV_W       = 120;
    private static final int STATS_H     = 18;
    private static final int ROW_H       = 24;
    private static final int WIDGET_H    = 18;
    private static final int PAD         = 6;

    // ── Positions (computed in init) ──────────────────────────────────────
    private int px, py;          // panel top-left
    private int navX, navY;      // nav sidebar area
    private int navH;
    private int contentX, contentY, contentW, contentH;  // scrollable content

    // ── Navigation ────────────────────────────────────────────────────────
    private int activePage = 0;

    private static final String[] PAGE_ICONS = {
        "⚡", "🔭", "👾", "💾", "⚙️", "🎮", "🔧", "🌌", "📊"
    };
    private static final String[] PAGE_NAMES = {
        "Overview",  "Rendering",   "Entities",  "Memory",
        "Performance","Dynamic FPS", "Stutter",   "Compat",  "HUD/Debug"
    };

    // ── Row scroll ────────────────────────────────────────────────────────
    private int scrollOffset = 0;
    private int maxScroll    = 0;
    private int totalRows    = 0;

    // ── Row widgets (rebuilt per page) ────────────────────────────────────
    private final List<RowEntry>       rows       = new ArrayList<>();
    private final List<ButtonWidget>   navBtns    = new ArrayList<>();

    // ── Scroll bar dragging ────────────────────────────────────────────────
    private boolean draggingScroll   = false;
    private int     scrollBarX, scrollBarY, scrollBarH, scrollBarThumbH;

    // ── Builders ──────────────────────────────────────────────────────────
    public ThanosConfigScreen(Screen parent) {
        super(Text.literal("Thanos Gauntlet FPS"));
        this.parent = parent;
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Init
    // ═════════════════════════════════════════════════════════════════════

    @Override
    protected void init() {
        rows.clear();
        navBtns.clear();

        // Center panel
        px = (this.width  - PANEL_W) / 2;
        py = (this.height - PANEL_H) / 2;

        // Nav sidebar
        navX = px + 1;
        navY = py + HEADER_H + STATS_H;
        navH = PANEL_H - HEADER_H - STATS_H - FOOTER_H - 2;

        // Content area (right of nav)
        contentX = px + NAV_W + 2;
        contentY = navY;
        contentW = PANEL_W - NAV_W - 4;
        contentH = navH;

        // Build nav buttons
        int navBtnH = 22;
        int navBtnPad = 1;
        for (int i = 0; i < PAGE_NAMES.length; i++) {
            final int idx = i;
            String label = PAGE_ICONS[i] + " " + PAGE_NAMES[i];
            ButtonWidget btn = ButtonWidget.builder(
                Text.literal(label),
                b -> switchPage(idx)
            ).dimensions(navX + 1, navY + i * (navBtnH + navBtnPad) + 2, NAV_W - 3, navBtnH).build();
            navBtns.add(btn);
            addDrawableChild(btn);
        }

        // Preset buttons in header area
        buildPresetBar();

        // Footer buttons
        int footerY = py + PANEL_H - FOOTER_H + 4;
        addDrawableChild(ButtonWidget.builder(
            Text.literal("§aDone"),
            b -> close()
        ).dimensions(px + PANEL_W - 80 - PAD, footerY, 78, 20).build());

        addDrawableChild(ButtonWidget.builder(
            Text.literal("§eReset Page"),
            b -> rebuildWidgets()
        ).dimensions(px + PANEL_W - 166 - PAD, footerY, 82, 20).build());

        // Scroll bar position
        scrollBarX = px + PANEL_W - 9;
        scrollBarY = contentY;
        scrollBarH = contentH;

        buildPageContent();
    }

    private void buildPresetBar() {
        ConfigManager mgr = ThanosGauntletFPS.getConfigManager();
        int statsY = py + HEADER_H + 1;
        int bw = 72;
        int startX = px + NAV_W + 4;

        // Low End
        addDrawableChild(ButtonWidget.builder(
            Text.literal("§c◆ Low"),
            b -> { mgr.applyPreset("low_end"); rebuildWidgets(); }
        ).dimensions(startX, statsY, bw, STATS_H - 2).build());

        // Balanced
        addDrawableChild(ButtonWidget.builder(
            Text.literal("§e◆ Balanced"),
            b -> { mgr.applyPreset("balanced"); rebuildWidgets(); }
        ).dimensions(startX + bw + 2, statsY, bw + 10, STATS_H - 2).build());

        // Ultra
        addDrawableChild(ButtonWidget.builder(
            Text.literal("§a◆ Ultra"),
            b -> { mgr.applyPreset("ultra"); rebuildWidgets(); }
        ).dimensions(startX + bw * 2 + 14, statsY, bw, STATS_H - 2).build());

        // Cycle mode
        addDrawableChild(ButtonWidget.builder(
            Text.literal("§d[K] Cycle"),
            b -> {
                String m = ThanosGauntletFPSClient.getMindStone().cycleMode();
                if (client != null && client.player != null)
                    client.player.sendMessage(Text.literal("§d[Thanos] Mode: " + m), true);
            }
        ).dimensions(startX + bw * 3 + 18, statsY, 78, STATS_H - 2).build());
    }

    private void switchPage(int page) {
        this.activePage = page;
        this.scrollOffset = 0;
        rebuildWidgets();
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Page content builders
    // ═════════════════════════════════════════════════════════════════════

    private void buildPageContent() {
        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
        rows.clear();

        switch (activePage) {
            case 0 -> buildOverview(cfg);
            case 1 -> buildRendering(cfg);
            case 2 -> buildEntities(cfg);
            case 3 -> buildMemory(cfg);
            case 4 -> buildPerformance(cfg);
            case 5 -> buildDynamicFps(cfg);
            case 6 -> buildStutterFix(cfg);
            case 7 -> buildCompat(cfg);
            case 8 -> buildHudDebug(cfg);
        }

        totalRows = rows.size();
        int visibleRows = contentH / ROW_H;
        maxScroll = Math.max(0, totalRows - visibleRows);
        scrollOffset = MathHelper.clamp(scrollOffset, 0, maxScroll);

        // Place widgets for visible rows
        placeWidgets();
    }

    private void buildOverview(ThanosConfig cfg) {
        addSection("System Information");
        addInfo("CPU Cores",  "" + SystemDetector.getCpuCores());
        addInfo("System RAM", SystemDetector.getTotalRamMB() + " MB");
        addInfo("JVM Heap",   SystemDetector.getJvmHeapMB() + " MB max");
        addInfo("GPU",        truncate(SystemDetector.getGpuRenderer(), 30));
        addInfo("Tier",       SystemDetector.getDetectedTier().name());

        addSection("Render Stack");
        addInfo("Renderer", ThanosGauntletFPSClient.getShaderDetector().getRenderStackSummary());
        String pack = ThanosGauntletFPSClient.getShaderDetector().getActiveShaderPackName();
        addInfo("Shader Pack", pack.isBlank() ? "None" : pack);
        String dhVer = ThanosGauntletFPSClient.getDhCompat().isDhPresent()
            ? "v" + ThanosGauntletFPSClient.getDhCompat().getDhVersion() : "Not installed";
        addInfo("Distant Horizons", dhVer);

        addSection("Active Features");
        addFeatureStatus("Auto-Tune",      cfg.autoTuneEnabled);
        addFeatureStatus("Entity Culling", cfg.entityCulling);
        addFeatureStatus("BE Culling",     cfg.blockEntityCulling);
        addFeatureStatus("Leaf Culling",   cfg.leafCulling);
        addFeatureStatus("Dynamic FPS",    cfg.dynamicFpsEnabled);
        addFeatureStatus("Stutter Fix",    cfg.stutterFixEnabled);
        addFeatureStatus("Fast Math",      cfg.fastMathEnabled);
        addFeatureStatus("GPU Leak Fix",   cfg.gpuLeakFixEnabled);
        addFeatureStatus("Smooth Boot",    cfg.smoothBootEnabled);
        addFeatureStatus("DH Compat",      cfg.dhCompatEnabled);
        addFeatureStatus("Shader Presets", cfg.shaderAutoPreset);
    }

    private void buildRendering(ThanosConfig cfg) {
        addSection("Chunk Rendering");
        addSlider("Render Distance",   cfg.renderDistance, 2, 32,
            v -> { cfg.renderDistance = v; ThanosGauntletFPSClient.getRealityStone().reloadConfig(cfg); },
            "Full-detail chunk radius (2–32 chunks). Lower = faster.");
        addSlider("Simulation Distance", cfg.simulationDistance, 2, 32,
            v -> { cfg.simulationDistance = v; ThanosGauntletFPSClient.getRealityStone().reloadConfig(cfg); },
            "Server-side tick radius. Can be lower than render distance.");
        addToggle("Enhanced Chunk Loading", cfg.enhancedChunkLoading,
            v -> cfg.enhancedChunkLoading = v,
            "Pre-queues neighboring chunks to reduce pop-in at chunk boundaries.");
        addToggle("Async Lighting", cfg.asyncLighting,
            v -> cfg.asyncLighting = v,
            "Routes lighting recalculations off the main thread where possible.");

        addSection("Culling (MoreCulling-inspired)");
        addToggle("Leaf Face Culling", cfg.leafCulling,
            v -> cfg.leafCulling = v,
            "Skip rendering leaf block faces hidden by adjacent same-type leaves. " +
            "Significantly reduces vertex count in dense forests. (MoreCulling)");
        addToggle("Block Entity Culling", cfg.blockEntityCulling,
            v -> cfg.blockEntityCulling = v,
            "Skip rendering chests, signs, banners, beacons beyond the cutoff distance.");
        addSlider("BE Cull Distance", cfg.blockEntityCullDist, 16, 256,
            v -> cfg.blockEntityCullDist = v,
            "Block entities beyond this many blocks are not rendered (16–256).");
        addToggle("Entity Camera Culling", cfg.entityCulling,
            v -> cfg.entityCulling = v,
            "Angular cull for entities behind the camera. ~15-30% draw-call reduction.");
    }

    private void buildEntities(ThanosConfig cfg) {
        addSection("Entity AI (Power Stone)");
        addToggle("Skip Distant AI", cfg.skipDistantAI,
            v -> cfg.skipDistantAI = v,
            "Mobs beyond the AI distance skip goal selector and pathfinding ticks. " +
            "Physics, gravity, and despawning still work normally.");
        addSlider("AI Distance (blocks)", cfg.entityTickDistance, 8, 128,
            v -> cfg.entityTickDistance = v,
            "Mobs within this range get full AI. Beyond it = no pathfinding.");

        addSection("Entity Cap");
        addSlider("Entity Cap (per dim)", cfg.entityCap, 0, 1000,
            v -> cfg.entityCap = v,
            "Hard cap on entities per dimension. 0 = disabled. Kills excess mobs furthest away first.");

        addSection("Culling");
        addToggle("Entity Camera Culling", cfg.entityCulling,
            v -> cfg.entityCulling = v,
            "Don't render entities more than ~90° behind the camera viewport.");
        addToggle("Block Entity Culling", cfg.blockEntityCulling,
            v -> cfg.blockEntityCulling = v,
            "Skip rendering block entities (chests/signs/spawners) at distance.");
        addSlider("BE Cull Distance", cfg.blockEntityCullDist, 16, 256,
            v -> cfg.blockEntityCullDist = v,
            "Block entities beyond this distance won't render (blocks).");
    }

    private void buildMemory(ThanosConfig cfg) {
        addSection("GC / Cleanup (SpaceStone)");
        addSlider("GC Interval (sec)", cfg.memoryCleanupInterval, 0, 300,
            v -> cfg.memoryCleanupInterval = v,
            "Seconds between scheduled GC hint and cache eviction. 0 = disabled.");
        addToggle("Memory Leak Fixes", cfg.enableMemoryLeakFixes,
            v -> cfg.enableMemoryLeakFixes = v,
            "Clears entity tick-map and stale renderer references on world disconnect. (ModernFix)");

        addSection("Block State (FerriteCore-inspired)");
        addToggle("BlockState Deduplication", cfg.blockStateDeduplication,
            v -> cfg.blockStateDeduplication = v,
            "Deduplicate block state neighbor lookup tables to reduce RAM usage. " +
            "Effect: 200–400 MB less heap on a vanilla world load. (FerriteCore)");
        addToggle("Lazy Block Entities", cfg.lazyTileEntities,
            v -> cfg.lazyTileEntities = v,
            "Defer block entity initialization until first access. Reduces startup RAM.");

        addSection("GPU Memory (GpuTape-inspired)");
        addToggle("GPU Leak Fix", cfg.gpuLeakFixEnabled,
            v -> cfg.gpuLeakFixEnabled = v,
            "Register a JVM Cleaner on Framebuffer objects. If a framebuffer is GC'd " +
            "without being deleted, we log and handle the VRAM leak. (GpuTape)");
        addToggle("Avoid Redundant FB Switching", cfg.avoidRedundantFbSwitch,
            v -> cfg.avoidRedundantFbSwitch = v,
            "Skip redundant framebuffer bind/unbind calls during GUI rendering. (ImmediatelyFast)");
    }

    private void buildPerformance(ThanosConfig cfg) {
        addSection("Auto-Tune (Mind Stone)");
        addToggle("Auto-Tune Enabled", cfg.autoTuneEnabled,
            v -> cfg.autoTuneEnabled = v,
            "Automatically adjusts render distance and entity settings to maintain target FPS.");
        addSlider("Target FPS", cfg.targetFPS, 15, 240,
            v -> cfg.targetFPS = v,
            "FPS the auto-tuner aims for. It will reduce quality to stay above this.");
        addSlider("Aggressiveness (1-10)", cfg.autoTuneAggressiveness, 1, 10,
            v -> cfg.autoTuneAggressiveness = v,
            "How aggressively the auto-tuner reduces settings when FPS drops.");

        addSection("Particles (Time Stone)");
        addToggle("Particle Throttle", cfg.particleThrottle,
            v -> cfg.particleThrottle = v,
            "Automatically reduce particle density when FPS drops below target.");
        addSlider("Particle Density %", cfg.particleDensity, 0, 100,
            v -> cfg.particleDensity = v,
            "0 = no particles, 100 = full vanilla density. Applied to all particle spawns.");
        addToggle("Dream Mode", cfg.dreamMode,
            v -> cfg.dreamMode = v,
            "Suppresses ALL particle spawning and weather rendering. Max performance.");

        addSection("Redstone (Time Stone)");
        addToggle("Skip Distant Redstone", cfg.skipDistantRedstone,
            v -> cfg.skipDistantRedstone = v,
            "Skips redstone block updates beyond the cutoff distance.");
        addSlider("Redstone Cutoff (blocks)", cfg.redstoneCutoffDist, 16, 128,
            v -> cfg.redstoneCutoffDist = v,
            "Redstone blocks beyond this distance don't receive update signals.");

        addSection("Math (SuperFastMath-inspired)");
        addToggle("Fast Math", cfg.fastMathEnabled,
            v -> cfg.fastMathEnabled = v,
            "Replace Math.cos() calls with a lookup-table implementation (like SuperFastMath). " +
            "MC already has a table for sin(). This adds cos() to the table too.");
    }

    private void buildDynamicFps(ThanosConfig cfg) {
        addSection("Window Focus (Dynamic FPS mod)");
        addToggle("Dynamic FPS Enabled", cfg.dynamicFpsEnabled,
            v -> cfg.dynamicFpsEnabled = v,
            "Cap FPS and reduce resource usage when the game window is not focused.");
        addSlider("Unfocused FPS Cap", cfg.unfocusedFpsCap, 1, 60,
            v -> cfg.unfocusedFpsCap = v,
            "FPS limit applied when the window doesn't have focus. " +
            "Lower = less GPU/CPU usage in background. 1 = nearly idle.");
        addToggle("Pause When Minimized", cfg.pauseWhenMinimized,
            v -> cfg.pauseWhenMinimized = v,
            "Drop to 1 FPS and mute audio when the window is iconified/minimized.");

        addSection("Audio");
        addToggle("Reduce Volume When Unfocused", cfg.reduceVolumeWhenUnfocused,
            v -> cfg.reduceVolumeWhenUnfocused = v,
            "Lower master volume when the game window loses focus.");
        addSlider("Unfocused Volume %", cfg.unfocusedVolumePct, 0, 100,
            v -> cfg.unfocusedVolumePct = v,
            "Master volume percentage when unfocused. 0 = fully muted. 100 = unchanged.");
    }

    private void buildStutterFix(ThanosConfig cfg) {
        addSection("Render Thread (StutterFix-inspired)");
        addToggle("Stutter Fix: Remove yield()", cfg.stutterFixEnabled,
            v -> cfg.stutterFixEnabled = v,
            "Remove Thread.yield() from the render loop. Vanilla yields the thread " +
            "every frame as a polite gesture — on modern hardware this causes 1-15ms stutter spikes.");
        addToggle("Render Thread Priority Boost", cfg.renderThreadBoost,
            v -> cfg.renderThreadBoost = v,
            "Set the render thread to MAX_PRIORITY once the game starts. " +
            "Tells the OS scheduler to prefer it over background threads.");

        addSection("Chunk Generation Threads (StutterFix)");
        addToggle("Limit Chunk Gen Threads", cfg.limitChunkGenThreads,
            v -> cfg.limitChunkGenThreads = v,
            "Prevent chunk generation from using all CPU cores. " +
            "Leaves headroom for the render thread. Key StutterFix feature.");
        addSlider("Max Chunk Gen Threads", cfg.maxChunkGenThreads, 0, 16,
            v -> cfg.maxChunkGenThreads = v,
            "Maximum threads for chunk generation. 0 = auto (cores - 2, min 1). " +
            "Recommend 2 on 4-core, 3-4 on 8-core CPUs.");

        addSection("Startup (SmoothBoot-inspired)");
        addToggle("Smooth Boot", cfg.smoothBootEnabled,
            v -> cfg.smoothBootEnabled = v,
            "Lower ForkJoinPool worker thread priority during Bootstrap.initialize(). " +
            "Keeps the launcher UI responsive while heavy startup work runs in background. (SmoothBoot)");
    }

    private void buildCompat(ThanosConfig cfg) {
        addSection("Distant Horizons");
        String dhStatus = ThanosGauntletFPSClient.getDhCompat().isDhPresent()
            ? "§aInstalled v" + ThanosGauntletFPSClient.getDhCompat().getDhVersion()
            : "§cNot Installed";
        addInfo("DH Status", dhStatus);
        addToggle("DH Compatibility", cfg.dhCompatEnabled,
            v -> cfg.dhCompatEnabled = v,
            "When Distant Horizons is active, reduce vanilla render distance. " +
            "DH handles the horizon as LODs — having vanilla also render there is wasteful.");
        addSlider("DH Vanilla Render Dist", cfg.dhVanillaRenderDist, 2, 12,
            v -> cfg.dhVanillaRenderDist = v,
            "Vanilla chunk radius to render when DH is active (2–12). " +
            "DH renders the rest as LODs. 6 is ideal for seamless transition.");

        addSection("Iris Shaders");
        String packName = ThanosGauntletFPSClient.getShaderDetector().getActiveShaderPackName();
        addInfo("Active Pack", packName.isBlank() ? "§7None / Unknown" : "§d" + packName);
        addInfo("Iris Present", ThanosGauntletFPSClient.getShaderDetector().isIrisPresent() ? "§aYes" : "§cNo");
        addInfo("Shaders Active", ThanosGauntletFPSClient.getShaderDetector().isShadersEnabled() ? "§aYes" : "§7No");
        addToggle("Shader Auto Preset", cfg.shaderAutoPreset,
            v -> cfg.shaderAutoPreset = v,
            "Automatically detect the active Iris shader pack and apply a tuned " +
            "performance preset. Covers 20+ packs across 6 performance tiers.");

        addSection("Suggested Companion Mods");
        addInfo("Sodium", "§7For GPU rendering — install separately");
        addInfo("Iris", "§7For shader support — install separately");
        addInfo("Lithium", "§7For server-side perf — install separately");
        addInfo("FerriteCore", "§7For block state RAM reduction — install separately");
    }

    private void buildHudDebug(ThanosConfig cfg) {
        addSection("HUD (Soul Stone)");
        addToggle("Show FPS HUD", cfg.showHUD,
            v -> cfg.showHUD = v,
            "Display the FPS counter and active performance mode in the game overlay.");
        addCycleButton("HUD Position", cfg.hudPosition,
            new String[]{"TOP_LEFT","TOP_RIGHT","BOTTOM_LEFT","BOTTOM_RIGHT"},
            new String[]{"↖ Top-Left","↗ Top-Right","↙ Bottom-Left","↘ Bottom-Right"},
            v -> cfg.hudPosition = v,
            "Corner of the screen where the FPS HUD is drawn.");
        addToggle("FPS Warning Flash", cfg.fpsWarning,
            v -> cfg.fpsWarning = v,
            "Flash a red warning when FPS drops below the warning threshold.");
        addSlider("Warning Threshold FPS", cfg.fpsWarningThreshold, 10, 120,
            v -> cfg.fpsWarningThreshold = v,
            "FPS level that triggers the red warning flash on screen.");

        addSection("Debug / Logging (Chaos Stone)");
        addToggle("Debug Mode", cfg.debugMode,
            v -> cfg.debugMode = v,
            "Show extended debug overlay: entity count, frame time, memory usage.");
        addToggle("Dream Mode", cfg.dreamMode,
            v -> cfg.dreamMode = v,
            "Suppress all particles. Makes sparse, ethereal worlds.");
        addToggle("Verbose Logging", cfg.verboseLogging,
            v -> cfg.verboseLogging = v,
            "Log detailed per-stone activity to the Minecraft game log.");
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Row builders — add RowEntry descriptors, then placeWidgets() creates them
    // ═════════════════════════════════════════════════════════════════════

    private void addSection(String title) {
        rows.add(new RowEntry(RowEntry.Kind.SECTION, title, null, null));
    }

    private void addInfo(String label, String value) {
        rows.add(new RowEntry(RowEntry.Kind.INFO, label, value, null));
    }

    private void addFeatureStatus(String label, boolean enabled) {
        rows.add(new RowEntry(RowEntry.Kind.STATUS, label,
            enabled ? "§aON" : "§cOFF", null));
    }

    private void addToggle(String label, boolean value, Consumer<Boolean> onChange, String tip) {
        rows.add(new RowEntry(RowEntry.Kind.TOGGLE, label, tip,
            new WidgetSpec.Toggle(value, onChange)));
    }

    private void addSlider(String label, int value, int min, int max,
                           IntConsumer onChange, String tip) {
        rows.add(new RowEntry(RowEntry.Kind.SLIDER, label, tip,
            new WidgetSpec.Slider(value, min, max, onChange)));
    }

    private void addCycleButton(String label, String currentValue,
                                String[] values, String[] displayNames,
                                Consumer<String> onChange, String tip) {
        rows.add(new RowEntry(RowEntry.Kind.CYCLE, label, tip,
            new WidgetSpec.Cycle(currentValue, values, displayNames, onChange)));
    }

    // ── Place actual widgets for visible rows ─────────────────────────────

    private void placeWidgets() {
        int visibleStart = scrollOffset;
        int visibleEnd   = scrollOffset + contentH / ROW_H + 1;

        int ww = contentW / 2 - PAD;
        int wx = contentX + contentW - ww - 4;

        for (int i = visibleStart; i < Math.min(visibleEnd, rows.size()); i++) {
            RowEntry row = rows.get(i);
            if (row.spec == null) continue;

            int wy = contentY + (i - scrollOffset) * ROW_H + (ROW_H - WIDGET_H) / 2;
            if (wy < contentY || wy + WIDGET_H > contentY + contentH) continue;

            switch (row.spec) {
                case WidgetSpec.Toggle spec -> {
                    boolean[] cur = {spec.value};
                    ButtonWidget btn = ButtonWidget.builder(
                        Text.literal(cur[0] ? "§a■ ON" : "§c■ OFF"),
                        b -> {
                            cur[0] = !cur[0];
                            spec.onChange.accept(cur[0]);
                            b.setMessage(Text.literal(cur[0] ? "§a■ ON" : "§c■ OFF"));
                            ThanosGauntletFPS.getConfigManager().save();
                        }
                    ).dimensions(wx, wy, ww, WIDGET_H).build();
                    if (row.tooltip != null)
                        btn.setTooltip(Tooltip.of(Text.literal(row.tooltip)));
                    addDrawableChild(btn);
                }
                case WidgetSpec.Slider spec -> {
                    IntSlider slider = new IntSlider(wx, wy, ww, WIDGET_H,
                        row.label, spec.value, spec.min, spec.max, v -> {
                            spec.onChange.accept(v);
                            ThanosGauntletFPS.getConfigManager().save();
                        });
                    if (row.tooltip != null)
                        slider.setTooltip(Tooltip.of(Text.literal(row.tooltip)));
                    addDrawableChild(slider);
                }
                case WidgetSpec.Cycle spec -> {
                    int[] idx = {findIndex(spec.values, spec.currentValue)};
                    ButtonWidget btn = ButtonWidget.builder(
                        Text.literal("§7" + spec.displayNames[idx[0]]),
                        b -> {
                            idx[0] = (idx[0] + 1) % spec.values.length;
                            spec.onChange.accept(spec.values[idx[0]]);
                            b.setMessage(Text.literal("§7" + spec.displayNames[idx[0]]));
                            ThanosGauntletFPS.getConfigManager().save();
                        }
                    ).dimensions(wx, wy, ww, WIDGET_H).build();
                    if (row.tooltip != null)
                        btn.setTooltip(Tooltip.of(Text.literal(row.tooltip)));
                    addDrawableChild(btn);
                }
                default -> {}
            }
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Render
    // ═════════════════════════════════════════════════════════════════════

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // 1. Full-screen void background
        ctx.fill(0, 0, this.width, this.height, COL_VOID);

        // 2. Panel background + border
        ctx.fill(px, py, px + PANEL_W, py + PANEL_H, COL_PANEL);
        drawBorder(ctx, px, py, PANEL_W, PANEL_H, COL_PANEL_BD);

        // 3. Header bar
        renderHeader(ctx);

        // 4. Stats / preset bar
        renderStatsBar(ctx);

        // 5. Nav sidebar
        renderNav(ctx);

        // 6. Content area background
        ctx.fill(contentX, contentY, contentX + contentW, contentY + contentH, COL_CONTENT);

        // 7. Rows
        renderRows(ctx, mx, my);

        // 8. Scroll bar (if needed)
        if (maxScroll > 0) renderScrollBar(ctx, mx, my);

        // 9. Footer
        renderFooter(ctx);

        // 10. Widgets + tooltips
        super.render(ctx, mx, my, delta);
    }

    private void renderHeader(DrawContext ctx) {
        ctx.fill(px, py, px + PANEL_W, py + HEADER_H, COL_HEADER);
        // Glow strip
        ctx.fill(px, py + HEADER_H - 2, px + PANEL_W, py + HEADER_H, COL_HEADER_GLOW);

        // Title
        String title = "§l⬡ §6Thanos Gauntlet FPS §7| §dv1.0.0";
        ctx.drawText(textRenderer, title, px + PAD + 2, py + (HEADER_H - 8) / 2, COL_GOLD, false);

        // Live FPS indicator
        int fps = MinecraftClient.getInstance().getCurrentFps();
        int tgt = ThanosGauntletFPS.getConfigManager().getConfig().targetFPS;
        int fpsCol = fps >= tgt ? COL_GREEN : fps >= tgt / 2 ? COL_YELLOW : COL_RED;
        String fpsStr = fps + " FPS";
        ctx.drawText(textRenderer, fpsStr,
            px + PANEL_W - textRenderer.getWidth(fpsStr) - PAD, py + (HEADER_H - 8) / 2,
            fpsCol, false);
    }

    private void renderStatsBar(DrawContext ctx) {
        int sy = py + HEADER_H;
        ctx.fill(px, sy, px + PANEL_W, sy + STATS_H, COL_HEADER);

        // Nav area: just a shade
        ctx.fill(navX, sy, navX + NAV_W, sy + STATS_H, COL_NAV);

        // Mode display left of presets
        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
        String modeText = "§7Mode: §d" + cfg.performanceMode.toUpperCase();
        ctx.drawText(textRenderer, modeText, navX + 4, sy + 4, COL_LIGHT, false);

        // Separator
        ctx.fill(navX + NAV_W, sy, navX + NAV_W + 1, sy + STATS_H, COL_SEPARATOR);
    }

    private void renderNav(DrawContext ctx) {
        ctx.fill(navX, navY, navX + NAV_W, navY + navH, COL_NAV);
        ctx.fill(navX + NAV_W, navY, navX + NAV_W + 1, navY + navH, COL_SEPARATOR);

        // Highlight active nav item
        int navBtnH = 22;
        int selY = navY + activePage * (navBtnH + 1) + 2;
        ctx.fill(navX + 1, selY, navX + NAV_W - 2, selY + navBtnH, COL_NAV_SEL);
        ctx.fill(navX + 1, selY, navX + 3, selY + navBtnH, COL_NAV_SEL_BD);
    }

    private void renderRows(DrawContext ctx, int mx, int my) {
        int visibleRows = contentH / ROW_H;
        int leftX = contentX + PAD;
        int labelW = contentW / 2 - PAD * 2;

        // Enable scissor to clip content
        ctx.enableScissor(contentX, contentY, contentX + contentW, contentY + contentH);

        for (int i = scrollOffset; i < Math.min(scrollOffset + visibleRows + 1, rows.size()); i++) {
            RowEntry row = rows.get(i);
            int ry = contentY + (i - scrollOffset) * ROW_H;

            // Row background
            ctx.fill(contentX, ry, contentX + contentW, ry + ROW_H,
                i % 2 == 0 ? COL_ROW_A : COL_ROW_B);

            // Hover highlight
            if (mx >= contentX && mx < contentX + contentW && my >= ry && my < ry + ROW_H) {
                ctx.fill(contentX, ry, contentX + contentW, ry + ROW_H, 0x10FFFFFF);
            }

            int textY = ry + (ROW_H - 8) / 2;

            switch (row.kind) {
                case SECTION -> {
                    // Full-width section header
                    ctx.fill(contentX, ry, contentX + contentW, ry + ROW_H, 0x25A060FF);
                    ctx.fill(contentX, ry + ROW_H - 1, contentX + contentW, ry + ROW_H, COL_HEADER_GLOW);
                    ctx.drawText(textRenderer, "§l" + row.label,
                        leftX, textY, COL_PURPLE, false);
                }
                case INFO -> {
                    ctx.drawText(textRenderer, row.label, leftX, textY, COL_LIGHT, false);
                    // Value on right
                    int vx = contentX + contentW / 2;
                    ctx.drawText(textRenderer, row.tooltip, vx, textY, COL_CYAN, false);
                }
                case STATUS -> {
                    ctx.drawText(textRenderer, row.label, leftX, textY, COL_LIGHT, false);
                    int vx = contentX + contentW / 2;
                    ctx.drawText(textRenderer, row.tooltip, vx, textY, COL_WHITE, false);
                }
                case TOGGLE, SLIDER, CYCLE -> {
                    // Label on left (trimmed if needed)
                    String lbl = row.label;
                    if (textRenderer.getWidth(lbl) > labelW)
                        lbl = textRenderer.trimToWidth(lbl, labelW - 6) + "…";
                    ctx.drawText(textRenderer, lbl, leftX, textY, COL_WHITE, false);
                    // Widget is placed by placeWidgets() — no text needed here
                }
            }
        }

        ctx.disableScissor();
    }

    private void renderScrollBar(DrawContext ctx, int mx, int my) {
        int sbW = 5;
        int sbX = contentX + contentW - sbW - 1;
        int totalH = contentH;
        int visibleRows = contentH / ROW_H;

        float thumbRatio = (float) visibleRows / totalRows;
        scrollBarThumbH = Math.max(20, (int)(totalH * thumbRatio));
        float scrollRatio = maxScroll > 0 ? (float) scrollOffset / maxScroll : 0;
        int thumbY = scrollBarY + (int)((totalH - scrollBarThumbH) * scrollRatio);

        // Track
        ctx.fill(sbX, scrollBarY, sbX + sbW, scrollBarY + totalH, 0x40FFFFFF);
        // Thumb
        boolean hovering = mx >= sbX && mx < sbX + sbW && my >= thumbY && my < thumbY + scrollBarThumbH;
        ctx.fill(sbX, thumbY, sbX + sbW, thumbY + scrollBarThumbH,
            (hovering || draggingScroll) ? 0xCCAA88FF : 0x80AA88FF);
    }

    private void renderFooter(DrawContext ctx) {
        int fy = py + PANEL_H - FOOTER_H;
        ctx.fill(px, fy, px + PANEL_W, py + PANEL_H, COL_FOOTER);
        ctx.fill(px, fy, px + PANEL_W, fy + 1, COL_SEPARATOR);

        // Hardware summary
        String sys = String.format("§7%d cores  %d MB heap  GPU: %s",
            SystemDetector.getCpuCores(),
            Runtime.getRuntime().maxMemory() / 1024 / 1024,
            truncate(SystemDetector.getGpuRenderer(), 22));
        ctx.drawText(textRenderer, sys, px + PAD, fy + (FOOTER_H - 8) / 2, COL_GRAY, false);
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Input
    // ═════════════════════════════════════════════════════════════════════

    @Override
    public boolean mouseScrolled(double mx, double my, double hx, double amount) {
        if (mx >= contentX && mx < contentX + contentW &&
            my >= contentY && my < contentY + contentH) {
            scrollOffset = MathHelper.clamp(
                scrollOffset - (int) Math.signum(amount), 0, maxScroll);
            rebuildWidgets();
            return true;
        }
        return super.mouseScrolled(mx, my, hx, amount);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // Scroll bar thumb drag start
        if (button == 0 && maxScroll > 0) {
            int sbW = 5;
            int sbX = contentX + contentW - sbW - 1;
            int visibleRows = contentH / ROW_H;
            float thumbRatio = (float) visibleRows / Math.max(1, totalRows);
            scrollBarThumbH = Math.max(20, (int)(contentH * thumbRatio));
            float scrollRatio = maxScroll > 0 ? (float) scrollOffset / maxScroll : 0;
            int thumbY = scrollBarY + (int)((contentH - scrollBarThumbH) * scrollRatio);

            if (mx >= sbX && mx < sbX + sbW && my >= thumbY && my < thumbY + scrollBarThumbH) {
                draggingScroll = true;
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        draggingScroll = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (draggingScroll && maxScroll > 0) {
            double ratio = dy / Math.max(1, contentH);
            int delta = (int)(ratio * totalRows);
            if (delta != 0) {
                scrollOffset = MathHelper.clamp(scrollOffset + delta, 0, maxScroll);
                rebuildWidgets();
            }
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Screen lifecycle
    // ═════════════════════════════════════════════════════════════════════

    @Override
    public void close() {
        ThanosGauntletFPS.getConfigManager().forceSave();
        ThanosConfig cfg = ThanosGauntletFPS.getConfigManager().getConfig();
        // Reload all modules with the new config
        ThanosGauntletFPSClient.getRealityStone().reloadConfig(cfg);
        ThanosGauntletFPSClient.getSoulStone().reloadConfig(cfg);
        ThanosGauntletFPSClient.getChaosStone().reloadConfig(cfg);
        ThanosGauntletFPS.getPowerStone().reloadConfig(cfg);
        ThanosGauntletFPS.getTimeStone().reloadConfig(cfg);
        ThanosGauntletFPS.getSpaceStone().reloadConfig(cfg);
        this.client.setScreen(parent);
    }

    @Override
    public boolean shouldCloseOnEsc() { return true; }

    @Override
    public boolean shouldPause() { return false; }

    // ═════════════════════════════════════════════════════════════════════
    //  Helpers
    // ═════════════════════════════════════════════════════════════════════

    private void drawBorder(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }

    private String truncate(String s, int max) {
        return s.length() > max ? s.substring(0, max - 1) + "…" : s;
    }

    private int findIndex(String[] arr, String val) {
        for (int i = 0; i < arr.length; i++) if (arr[i].equals(val)) return i;
        return 0;
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Inner types
    // ═════════════════════════════════════════════════════════════════════

    private record RowEntry(Kind kind, String label, String tooltip, WidgetSpec spec) {
        enum Kind { SECTION, INFO, STATUS, TOGGLE, SLIDER, CYCLE }
    }

    private sealed interface WidgetSpec permits WidgetSpec.Toggle, WidgetSpec.Slider, WidgetSpec.Cycle {
        record Toggle(boolean value, Consumer<Boolean> onChange)   implements WidgetSpec {}
        record Slider(int value, int min, int max, IntConsumer onChange) implements WidgetSpec {}
        record Cycle(String currentValue, String[] values, String[] displayNames,
                     Consumer<String> onChange)                    implements WidgetSpec {}
    }

    // ── Integer slider widget ─────────────────────────────────────────────

    static final class IntSlider extends SliderWidget {
        private final String    label;
        private final int       min, max;
        private final IntConsumer onChange;

        IntSlider(int x, int y, int w, int h, String label,
                  int value, int min, int max, IntConsumer onChange) {
            super(x, y, w, h, Text.empty(), (double)(value - min) / Math.max(1, max - min));
            this.label    = label;
            this.min      = min;
            this.max      = max;
            this.onChange = onChange;
            updateMessage();
        }

        @Override protected void updateMessage() {
            setMessage(Text.literal("§7" + label + ": §e" + currentInt()));
        }

        @Override protected void applyValue() { onChange.accept(currentInt()); }

        int currentInt() { return (int) Math.round(min + this.value * (max - min)); }
    }
}
